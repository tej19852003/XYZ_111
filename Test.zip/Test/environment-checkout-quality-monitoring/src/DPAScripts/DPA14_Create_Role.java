package DPAScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;
import ScreenObjects.NewRoleScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DPA14_Create_Role {

	public static ExtentReports extent = ExtentReports.get(DPA14_Create_Role.class);
	
	public static boolean Create_Role_DPA_PredefinedRole() throws Exception {
		
		boolean flag = true;
		String HTMLReportName = "DPA14_Create_Role_DPA_PredefinedRole" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Create Role DPA Predefined Role");
		
		//Utilities.testCaseSetup("DPA14_Create_Role_DPA_PredefinedRole"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date()), "Create Role DPA Predefined Role");
		
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    
	    String ParentOrganization = Ws.getCell(7,11).getContents();	     
	    String RoleName = Ws.getCell(8,11).getContents();	
		
		try {
			LoginScreen.launchVerint(driver,Utilities.PROPERTIES.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver, "User Management", "Role Setup")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver, Utilities.PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver, Utilities.PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup")) {
					extent.log(LogStatus.WARNING, "Roles Setup section is not displayed. Please try again.");
					return flag = false;
				}
			}
				
			RolesSetupScreen.selectNodeFromLeftTreePane(driver,ParentOrganization);
			RolesSetupScreen.selectRightPaneView(driver);
			
			//verify role name already exist or not
			if (!RolesSetupScreen.verifyRoleName(driver, RoleName)) {
				if (!RolesSetupScreen.clickCreateNewRole(driver)) {
					return flag = false;
				}
				if (!NewRoleScreen.setTextInRolename(driver, RoleName)) {
					return flag=false;
				}
				NewRoleScreen.setTextInRoleDescription(driver, "AutomationPredefDesc");
				//NewRoleScreen.expandPrivilege(driver);
				NewRoleScreen.selectInteractionsAnalyticsPrivilege(driver, "Interactions and Analytics", "Assignment Manager;Caption Editor");
				if (!NewRoleScreen.clickSave(driver)) {
					return flag = false;
				}
				
				RolesSetupScreen.selectRightPaneView(driver);
				//validation- role created or not
				if (!RolesSetupScreen.selectRoleName(driver, RoleName)) {
					return flag=false;
				}
			}
		
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,11);
		}
		return flag;
	}
}
