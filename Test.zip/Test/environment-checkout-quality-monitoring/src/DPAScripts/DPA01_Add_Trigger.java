package DPAScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;


import jxl.Sheet;
import jxl.Workbook;

import ScreenObjects.LoginScreen;

import ScreenObjects.ScreenContentTriggers;
import ScreenObjects.VerintHomePageScreen;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.ie.InternetExplorerDriver;

import org.openqa.selenium.os.WindowsUtils;
import org.openqa.selenium.remote.DesiredCapabilities;


import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.sikuli.script.*;
public class DPA01_Add_Trigger {
	public static final Properties PROPERTIES = Utilities.PROPERTIES;
	public static final String SIKULI_IMAGES = PROPERTIES.getProperty("ImagesPath");
	
	public static ExtentReports extent = ExtentReports.get(DPA01_Add_Trigger.class);
	public static Screen sobj = new Screen ();
	public static boolean Add_Trigger() throws Exception {
		boolean flag = true;
		String HTMLReportName = "DPA01_Add_Trigger" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Add Trigger");
		
		File file = new File(PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(PROPERTIES.getProperty("TestDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    
	    String DPAValidatorVersion = Ws.getCell(18,6).getContents();	     
	    String screenName = Ws.getCell(13, 6).getContents();
	    String UniqueName = Ws.getCell(14, 6).getContents();
	    String DisplayName = Ws.getCell(15, 6).getContents();
	    String CommandToExecute = Ws.getCell(16, 6).getContents();
	    String DPAValidatorSettingsServer = Ws.getCell(19, 6).getContents();
		
		try {
			LoginScreen.launchVerint(driver, PROPERTIES.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}			
			VerintHomePageScreen.selectMenuItem(driver, "Tracking", "DesktopProcessAnalytics_Menu");
			
			if (sobj.exists(SIKULI_IMAGES + "\\DPA_Error.png") != null || sobj.exists(SIKULI_IMAGES + "\\DPA_AuthorisationError.png") != null) {
				extent.log(LogStatus.FAIL, "Application/Authorisation error is displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				return flag=false;
			}

			if (sobj.exists(SIKULI_IMAGES + "\\DPA_Administration_blue.png")!=null) {
				sobj.mouseMove(SIKULI_IMAGES + "\\DPA_Administration_blue.png");
			}
			if (sobj.exists(SIKULI_IMAGES + "\\DPA_Administration.png")!=null) {
				sobj.mouseMove(SIKULI_IMAGES + "\\DPA_Administration.png");
			}
			sobj.click(SIKULI_IMAGES + "\\Menu_Trigger.png");
			sobj.click(SIKULI_IMAGES + "\\Impact360_Text.png");
			Thread.sleep(3000);
			if (driver.findElements(By.linkText("Screen Content Trigger")).size() != 0) {
				if ( driver.findElements(By.linkText("Screen Name")).size() != 0) {
					extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");
				}
				else {
					extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
					return flag=false;
				}
			}

			//verify whether Trigger exist or not
			if (!ScreenContentTriggers.selectFind(driver,"Screen Name")) {
				return flag = false;
			}
			if (!ScreenContentTriggers.setSearchByName(driver, screenName)) {
				return flag = false;
			}
			if (!ScreenContentTriggers.clickSearch(driver)) {
				return flag = false;
			}
			ScreenContentTriggers.deleteTrigger(driver, screenName);
			//end of verification
			
			ScreenContentTriggers.clickAddNewScreen(driver);
			ScreenContentTriggers.selectDPAValidatorVersion(driver, DPAValidatorVersion); //select DPA validator version
			if (!Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\ValidatorVerison_Go_Button.png")) {
				extent.log(LogStatus.WARNING, "Not able to click on Go button. Please try again.");
				return flag = false;
			}
			if (!Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPAValidator_Run.png")) {
				extent.log(LogStatus.WARNING, "Not able to click on RUN button. Please try again.");
				return flag = false;
			}
			if (!Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPAValidator_Run.png")) {
				extent.log(LogStatus.WARNING, "Not able to click on RUN button. Please try again.");
				return flag = false;
			}
			if (!Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPAValidator_Setting_Button.png")) {
				extent.log(LogStatus.WARNING, "Not able to click on Settings button. Please try again.");
				return flag = false;
			}
			sobj.click(SIKULI_IMAGES + "\\DPAValidator_ServerName.png");
			sobj.type("a", KeyModifier.CTRL);  // select all text
			sobj.type(Key.BACKSPACE);  // delete selection
			sobj.type(DPAValidatorSettingsServer);  //server settings text
			Thread.sleep(1000);			
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPAValidator_Setting_OK_Button.png");  //server settings - Ok button
					
			Runtime.getRuntime().exec("calc");  //opening calculator
			Thread.sleep(1000);
			if (!Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPAValidator_Capture.png")) {
				extent.log(LogStatus.WARNING, "Not able to click on Capture button.Please try again.");
				return flag = false;
			}
			
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\calcplus.png");
			
			Thread.sleep(2000);
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\Trigger_OK.png");
			Thread.sleep(2000);
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\Trigger_OK_blue.png");
			Thread.sleep(4000);
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\calcMinimize.png");
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPAValidator_CapturedScreen.png");
			Thread.sleep(2000);
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\calcyelloplus.png");
			
			sobj.click(SIKULI_IMAGES + "\\FriendlyScreenName.png");
			sobj.type("a", KeyModifier.CTRL);  // select all text
			sobj.type(Key.BACKSPACE);  // delete selection
			sobj.type(screenName);
			sobj.click(SIKULI_IMAGES + "\\UploadToServer.png");
			Thread.sleep(4000);

			//verify upload successful message box
			if (sobj.exists(SIKULI_IMAGES+"\\UploadSuccessful.png") != null) {
				Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPAValidator_No_Button.png");
				extent.log(LogStatus.PASS, "Upload successful message is displayed");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Trigger"));
			}
			if (sobj.exists(SIKULI_IMAGES + "\\FileUpload_Failed.png") != null) {
				extent.log(LogStatus.FAIL, "File Upload Failed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				return flag = false;
			}
			Thread.sleep(3000);
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPAValidator_Exit_Button.png");
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPAValidatorVersion_Close_Button.png");
						
			if (!ScreenContentTriggers.selectFind(driver, "Screen Name")) {
				return flag = false;
			}
			if (!ScreenContentTriggers.setSearchByName(driver, screenName)) {
				return flag = false;
			}
			if (!ScreenContentTriggers.clickSearch(driver)) {
				return flag = false;
			}
			if (!ScreenContentTriggers.clickCapturedTrigger(driver, screenName)) {
				return flag = false;
			}
			Thread.sleep(4000);
			if (!ScreenContentTriggers.setUniqueName(driver, UniqueName)) {
				return flag = false;
			}
			if (!ScreenContentTriggers.setDisplayName(driver, DisplayName)) {
				return flag = false;
			}
			ScreenContentTriggers.selectCommandToExecute(driver, CommandToExecute);
			ScreenContentTriggers.setAdditionalParameters(driver, "Automation");
			
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPA_Verticalbar.png");
			boolean temp=false;
			for (int i=1;i <=4; i++) {
				Thread.sleep(2000);
				if (sobj.exists(SIKULI_IMAGES + "\\Trigger_Control.png") != null) {
					sobj.click(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					sobj.doubleClick(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.doubleClick(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.doubleClick(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\Trigger_Control.png");
				}
				Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPA_Verticalbar_half.png");
				Thread.sleep(3000);				
				if (sobj.exists(SIKULI_IMAGES + "\\Highlight.png") != null) {
					sobj.click(SIKULI_IMAGES + "\\Highlight.png");
					temp = true;
				} else {
					temp = false;
				}
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPA_Verticalbar.png");
				Thread.sleep(2000);
				if (temp == true) {
					break;
				}			
			}
			Thread.sleep(4000);	
			if (temp == false) {
				extent.log(LogStatus.FAIL, "High light checkbox is not displayed. Please try again.");
				return flag = false;
			}
			ScreenContentTriggers.clickSave(driver);
			Thread.sleep(5000);
			if (!ScreenContentTriggers.clickActivateChanges(driver)) {
				return flag = false;
			}
			//check trigger version and kill DCUApp.exe
			String triggerversion=ScreenContentTriggers.checkTriggerVersion(driver);  //trigger version
			for (int d=1; d<=5; d++) {
				WindowsUtils.tryToKillByName("DCUApp.exe");  //kill DCUApp
				Thread.sleep(15000);
				WindowsUtils.tryToKillByName("DCUApp.exe");  //kill DCUApp
				Thread.sleep(15000);
			}
			String filepathVersion=ScreenContentTriggers.filePathTriggerVersion(driver, PROPERTIES.getProperty("PcMontrig2Path"));
			
			if (triggerversion.contains(filepathVersion)) {
				extent.log(LogStatus.PASS, "Trigger version:" + triggerversion + " PcMonTrig2.def version:" + filepathVersion + " ;Version numbers are matched");
			}
			else {
				extent.log(LogStatus.FAIL, "Trigger version:" + triggerversion + " PcMonTrig2.def version:" + filepathVersion + " ; Version numbers are NOT matched");
				System.out.println("Trigger version:" + triggerversion + " PcMonTrig2.def version:" + filepathVersion + " ;Version Numbers are not matched");
				return flag = false;
			}
			//firing trigger
			Runtime.getRuntime().exec("calc");	
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\calcplus.png");
			Thread.sleep(3000);
				
			if (sobj.exists(SIKULI_IMAGES + "\\Trigger_OK.png") != null) {
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				Thread.sleep(2000);
				extent.log(LogStatus.PASS, "Trigger has been fired successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				sobj.click(SIKULI_IMAGES + "\\Trigger_OK.png");
			}
			else {
				extent.log(LogStatus.FAIL, "Trigger has not been fired");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				flag = false;
			}
			WindowsUtils.tryToKillByName("calc.exe");
		}
		catch(Exception e) {
			System.out.println(e);
		}
		finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "DPA", HTMLReportName, 4, 6);
		}
		return flag;
	}
}
