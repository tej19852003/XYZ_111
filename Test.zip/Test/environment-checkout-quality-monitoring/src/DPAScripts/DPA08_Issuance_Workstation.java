package DPAScripts;

import java.io.File;

import java.text.SimpleDateFormat;
import java.util.Date;


import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DPA08_Issuance_Workstation {
	
	public static ExtentReports extent = ExtentReports.get(DPA08_Issuance_Workstation.class);
	
	public static boolean Issuance_Workstation() throws Exception {
		String HTMLReportName="DPA08_IssuanceInTheWorkstation"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Issuance In The Workstation");
		
		boolean flag = true;
		try {
		    if (!Utilities.folderExist("C:\\Program Files","Folder")) {
		    	extent.log(LogStatus.FAIL, "C:\\Program Files folder is not displayed");
		    	return flag = false;
		    }
		    if (!Utilities.folderExist("C:\\Program Files\\I360","Folder")) {
		    	extent.log(LogStatus.FAIL, "C:\\Program Files\\I360 folder is not displayed");
		    	return flag = false;
		    }
		    if (!Utilities.folderExist("C:\\Program Files\\I360\\DPA","Folder")) {
		    	extent.log(LogStatus.FAIL, "C:\\Program Files\\I360\\DPA is not displayed");
		    	return flag = false;
		    }
		    File currentDir = new File("C:\\Program Files\\I360\\DPA" + "\\");
			Utilities.displayDirectoryContents(currentDir);
		}
		catch (Exception err) {
	        err.printStackTrace();
	    }
	    finally {
	    	Utilities.verintScriptStatus(flag, "DPA", HTMLReportName, 4, 5);
	    }
		return flag;
	}
}
