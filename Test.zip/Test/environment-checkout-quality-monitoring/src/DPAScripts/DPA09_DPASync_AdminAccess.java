package DPAScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.AccessRightsScreen;

import ScreenObjects.LoginScreen;
import ScreenObjects.NewRoleScreen;
import ScreenObjects.RolesSetupScreen;

import ScreenObjects.ProfilesScreen;

import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DPA09_DPASync_AdminAccess {

	public static final Properties PROPERTIES = Utilities.PROPERTIES;
	public static ExtentReports extent = ExtentReports.get(DPA09_DPASync_AdminAccess.class);

	public static boolean DPASynchronization_AdminAccess() throws Exception {
		
		boolean flag = true;
		String HTMLReportName = "DPA09_DPASynchronization_AdminAccess" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "DPA Synchronization AdminAccess");
		
		File file = new File(PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(PROPERTIES.getProperty("TestDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    String organizationParent = Ws.getCell(7,12).getContents();	
	    
	    String RoleName = Ws.getCell(8,12).getContents();
	    String RoleDesc = Ws.getCell(9,12).getContents();
	   		
		try {
			LoginScreen.launchVerint(driver,PROPERTIES.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver, Utilities.getPassword(driver, 0, 1));
			LoginScreen.setTextInPassword(driver, Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup");
			if (driver.findElements(By.linkText("Roles Setup")).size() == 0) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver, PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver, PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup");			
				if (driver.findElements(By.linkText("Roles Setup")).size() == 0) {
					extent.log(LogStatus.WARNING, "Roles Setup section is not displayed. Please try again.");
					return flag = false;
				}
			}
				
			RolesSetupScreen.selectNodeFromLeftTreePane(driver, organizationParent);
			RolesSetupScreen.selectRightPaneView(driver);
			// Verify role name already exist or not
			if (!RolesSetupScreen.verifyRoleName(driver, RoleName)) {
				RolesSetupScreen.clickCreateNewRole(driver);			
				NewRoleScreen.setTextInRolename(driver, RoleName);
				NewRoleScreen.setTextInRoleDescription(driver, RoleDesc);
				NewRoleScreen.selectDPAPrivilege(driver);
				NewRoleScreen.clickSave(driver);		
				
				RolesSetupScreen.selectRightPaneView(driver);
				// Validation- role created or not
				if (!RolesSetupScreen.selectRoleName(driver, RoleName)) {
					return flag = false;
				}
			}
			driver.switchTo().defaultContent();
			VerintHomePageScreen.selectMenuItem(driver, "User Management", "Access Rights");
			Thread.sleep(4000);
			if (driver.findElements(By.linkText("Access Rights")).size() == 0) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver, Utilities.PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver, Utilities.PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				VerintHomePageScreen.selectMenuItem(driver, "User Management", "Access Rights");
				if (driver.findElements(By.linkText("Access Rights")).size() == 0) {
					extent.log(LogStatus.WARNING, "Access Rights section is not displayed. Please try again");
					return flag = false;
				}
			}
			if (!ProfilesScreen.FindSelect(driver, Utilities.PROPERTIES.getProperty("DPATestId"))) {
				return flag = false;
			}
			if (!AccessRightsScreen.selectEmp_From_AccessRightsFrame(driver, Utilities.PROPERTIES.getProperty("DPATestId"))) {
				return flag = false;
			}
			Utilities.selectRightPaneView(driver);
			AccessRightsScreen.clickEditAccessRights(driver);
						
			AccessRightsScreen.select_RoleName_checkbox(driver,RoleName);
			AccessRightsScreen.clickSave(driver);
			Thread.sleep(5000);			
			Utilities.logout(driver);
			Robot r = new Robot();
			for (int i=1; i<=50; i++) {
				r.keyPress(KeyEvent.VK_TAB);
				Thread.sleep(5000);
			}
			if (!LoginScreen.setTextInUsername(driver, PROPERTIES.getProperty("DPATestId"))) {
				return flag = false;
			}
			LoginScreen.setTextInPassword(driver, PROPERTIES.getProperty("DPAPassword"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			VerintHomePageScreen.selectMenuItem(driver, "Tracking", "DesktopProcessAnalytics_Menu");
			if (driver.findElements(By.linkText("Reports")).size() != 0 & driver.findElements(By.linkText("Administration")).size() != 0 & driver.findElements(By.linkText("System")).size() != 0) {
				System.out.println("all tabs");
				extent.log(LogStatus.PASS, "Reports Administartion System tabs are displayed");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "DPAAdmin"));				
			} else {
				System.out.println("not all tabs");
				extent.log(LogStatus.FAIL, "Reports/Administartion/System tabs were not displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "DPAAdmin"));
				return flag = false;
			}
			Set<String> windowIds = driver.getWindowHandles();
			Iterator<String> itererator = windowIds.iterator(); 			
			String mainWinID2 = itererator.next();  //main window
			Thread.sleep(2000);
			String  popWindow2 = itererator.next();  //popup window
			driver.switchTo().window(popWindow2);  //Switch the driver to the popup window
			driver.close();
			Thread.sleep(2000);
			driver.switchTo().window(mainWinID2);
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "DPA", HTMLReportName, 4, 12);
		}
		return flag;
	}
}
