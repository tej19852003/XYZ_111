package DPAScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;

import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ProfilesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.sikuli.script.Screen;

public class ImportDomainNewUser {

	public static ExtentReports extent = ExtentReports.get(ImportDomainNewUser.class);
	
	public static boolean Import_Domain_NewUser() throws Exception {
		boolean flag = true;
		Screen sobj = new Screen ();
		String HTMLReportName="ImportDomainNewUser" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "ImportDomain New User");
		
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    String UserAlias = Ws.getCell(11, 3).getContents();
	    String UserLastName = Ws.getCell(12, 3).getContents();
		
		try {
			LoginScreen.launchVerint(driver, Utilities.PROPERTIES.getProperty("VerintURL"));
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver, Utilities.getPassword(driver, 0, 1));
			LoginScreen.setTextInPassword(driver, Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver, "User Management", "Profiles")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver, Utilities.PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver, Utilities.PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver, "User Management", "Profiles"))
				{
					extent.log(LogStatus.WARNING, "Profiles section is not displayed. Please try again");
					return flag = false;
				}
				
			}
			//verify User exist or not
			if (!ProfilesScreen.FindSelect(driver, UserLastName)) {
				Utilities.selectRightPaneView(driver);				
				if (!ProfilesScreen.clickImportDomainUsers(driver)) {
					return flag = false;
				}
				Thread.sleep(4000);				
				if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\SelectUsers_EnterObjNameToSelect.png") != null) {
					sobj.type(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\SelectUsers_EnterObjNameToSelect.png", UserAlias);
				} else {
					extent.log(LogStatus.FAIL, "Import Domain Users popup not displayed. Please try again");
					return flag = false;
				}
				Thread.sleep(1000);
				if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\SelectUsers_OK_Btn.png") != null) {
					sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\SelectUsers_OK_Btn.png");
				} else {
					extent.log(LogStatus.FAIL, "OK button is not displayed");
					return flag = false;
				}
				Thread.sleep(5000);
				Utilities.selectRightPaneView(driver);
				if (!ProfilesScreen.checkErrorMessage(driver)) {
						return flag = false;
				}
				Thread.sleep(2000);				
				if (!ProfilesScreen.FindSelect(driver, UserLastName)) {
					return flag = false;
				}
			}
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "DPA", HTMLReportName, 4, 3);
		}
		return flag;
	}
}
