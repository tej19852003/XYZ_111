package DPAScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import jxl.Sheet;
import jxl.Workbook;

import ScreenObjects.LoginScreen;

import ScreenObjects.ScreenContentTriggers;
import ScreenObjects.VerintHomePageScreen;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.sikuli.script.*;
public class DPA02_View_Modify_Trigger {
	public static final Properties PROPERTIES = Utilities.PROPERTIES;
	public static final String SIKULI_IMAGES = PROPERTIES.getProperty("ImagesPath");
	public static ExtentReports extent = ExtentReports.get(DPA02_View_Modify_Trigger.class);
	public static Screen sobj = new Screen ();
	public static boolean View_Modify_Trigger() throws Exception {
		String HTMLReportName="DPA02_View_Modify_Trigger"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		boolean flag = true;
		Utilities.testCaseSetup(HTMLReportName, "View Modify Trigger");
		
		File file = new File(PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(PROPERTIES.getProperty("TestDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    String ScreenName = Ws.getCell(13, 7).getContents();
	    String UniqueName = Ws.getCell(14, 7).getContents();
	    String DisplayName = Ws.getCell(15, 7).getContents();
	    String CommandToExecute = Ws.getCell(16, 7).getContents();

		try {
			LoginScreen.launchVerint(driver, PROPERTIES.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver, Utilities.getPassword(driver, 0, 1));
			LoginScreen.setTextInPassword(driver, Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu");
			if (sobj.exists(SIKULI_IMAGES + "\\DPA_Error.png") != null || sobj.exists(SIKULI_IMAGES + "\\DPA_AuthorisationError.png") != null) {
				extent.log(LogStatus.FAIL, "Application/Authorisation error is displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				return flag = false;
			}
			if (sobj.exists(SIKULI_IMAGES + "\\DPA_Administration_blue.png") != null) {
				sobj.mouseMove(SIKULI_IMAGES + "\\DPA_Administration_blue.png");
			}
			if (sobj.exists(SIKULI_IMAGES + "\\DPA_Administration.png") != null) {
				sobj.mouseMove(SIKULI_IMAGES + "\\DPA_Administration.png");
			}
			sobj.click(SIKULI_IMAGES + "\\Menu_Trigger.png");
			sobj.click(SIKULI_IMAGES + "\\Impact360_Text.png");
			Thread.sleep(3000);
			if (driver.findElements(By.linkText("Screen Content Trigger")).size() != 0) {
				if ( driver.findElements(By.linkText("Screen Name")).size() != 0) {
					extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");							
				}
				else {
					extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
					return flag = false;
				}
			}
			//verify trigger version
			String versionNumber=ScreenContentTriggers.checkTriggerVersion(driver);
			if (!ScreenContentTriggers.selectFind(driver, "Screen Name")) {
				return flag = false;
			}
			ScreenContentTriggers.setSearchByName(driver, ScreenName);
			ScreenContentTriggers.clickSearch(driver);
			if (!ScreenContentTriggers.clickCapturedTrigger(driver, ScreenName)) {
				return flag = false;
			}
			Thread.sleep(4000);
			if (!ScreenContentTriggers.setUniqueName(driver, UniqueName)) {
				return flag = false;
			}
			if (!ScreenContentTriggers.setDisplayName(driver, DisplayName)) {
				return flag = false;
			}
			ScreenContentTriggers.selectCommandToExecute(driver, CommandToExecute);
			Thread.sleep(4000);
			Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPA_Verticalbar.png");
			boolean temp=false;
			for (int i=1; i<=4; i++) {
				Thread.sleep(2000);
				if (sobj.exists(SIKULI_IMAGES + "\\Trigger_Control.png") != null) {
					sobj.click(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					sobj.doubleClick(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.doubleClick(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.doubleClick(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(SIKULI_IMAGES + "\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(SIKULI_IMAGES + "\\Trigger_Control.png");
				}
				Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPA_Verticalbar_half.png");
				Thread.sleep(3000);				
				if (sobj.exists(SIKULI_IMAGES + "\\Highlight.png") != null) {
					sobj.click(SIKULI_IMAGES + "\\Highlight.png");
					temp = true;
				} else {
					temp = false;
				}
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, SIKULI_IMAGES + "\\DPA_Verticalbar.png");
				Thread.sleep(2000);
				if (temp == true) {
					break;
				}			
			}
			Thread.sleep(4000);	
			if (temp == false) {
				extent.log(LogStatus.FAIL, "Highlight checkbox is not displayed. Please try again.");
				return flag = false;
			}
			Thread.sleep(4000);	
			ScreenContentTriggers.clickSave(driver);
			Thread.sleep(5000);
			if (!ScreenContentTriggers.clickActivateChanges(driver)) {
				return flag = false;
			}
			
			String versionNumberUpdated = ScreenContentTriggers.checkTriggerVersion(driver);
			
			if (Integer.parseInt(versionNumber)< Integer.parseInt(versionNumberUpdated)) {
				extent.log(LogStatus.PASS, "Trigger Version:" + versionNumber + " updated to :" + versionNumberUpdated);

			} else {
				extent.log(LogStatus.FAIL, "Trigger Version:" + versionNumber + " updated to :" + versionNumberUpdated);
				flag = false;
			}
		}
		catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "DPA", HTMLReportName, 4, 7);
		}
		return flag;
	}
}
