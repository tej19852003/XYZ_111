package DPAScripts;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import ScreenObjects.LoginScreen;

import ScreenObjects.ScreenContentTriggers;
import ScreenObjects.VerintHomePageScreen;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DPA06_Check_TriggerVersion {
	
	public static ExtentReports extent = ExtentReports.get(DPA06_Check_TriggerVersion.class);
	public static Screen sobj = new Screen ();
	
	public static boolean Check_Trigger_Version() throws Exception {
		boolean flag = true;
		String HTMLReportName = "DPA06_Check_Trigger_Version" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Check Trigger Version");
		
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
	    
		try {		   
			LoginScreen.launchVerint(driver,Utilities.PROPERTIES.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu");
			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\DPA_Error.png") != null || sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\DPA_AuthorisationError.png") != null) {
				extent.log(LogStatus.FAIL, "Application/Authorisation error is displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				return flag = false;
			}
			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\DPA_Administration_blue.png")!=null) {
				sobj.mouseMove(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\DPA_Administration_blue.png");
			}
			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\DPA_Administration.png")!=null) {
				sobj.mouseMove(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\DPA_Administration.png");
			}
			sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Menu_Trigger.png");
			sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Impact360_Text.png");
			if (driver.findElements(By.linkText("Screen Content Trigger")).size() != 0) {
				if ( driver.findElements(By.linkText("Screen Name")).size() != 0) {
					extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");							
				}
				else {
					extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
					return flag = false;
				}
			}
			ScreenContentTriggers.checkTriggerVersion(driver);			
		
		}
		catch(Exception e) {
			System.out.println(e);
		}
		finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag, "DPA", HTMLReportName, 4, 8);
		}
		return flag;
	}
}
