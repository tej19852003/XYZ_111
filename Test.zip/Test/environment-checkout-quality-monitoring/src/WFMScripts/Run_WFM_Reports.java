package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.RequestsResultsScreen;
import ScreenObjects.VerintHomePageScreen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Run_WFM_Reports {
	
	public static ExtentReports extent = ExtentReports.get(Run_WFM_Reports.class);
	
	public static boolean RunWFMReports() throws Exception {		
		boolean flag = true;
		String mainWinID1 = "";
		String htmlReportName="Run_WFM_Reports" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(htmlReportName, "Run WFM Reports");
		
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook workbook = Workbook.getWorkbook(fis);		
	    Sheet worksheet = workbook.getSheet("WFM_TestSet");
	    String ReportSelection = worksheet.getCell(11, 5).getContents();
	    String ReportName = worksheet.getCell(12, 5).getContents();
	    String ReportNote = worksheet.getCell(13, 5).getContents();
		
		try {				    
			LoginScreen.launchVerint(driver, Utilities.PROPERTIES.getProperty("VerintURL"));
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver, Utilities.getPassword(driver, 0, 1));
			LoginScreen.setTextInPassword(driver, Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management", "user_profiles")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
				LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles")) {
					extent.log(LogStatus.WARNING, "Not able to select Profiles menu. Please try again");
					return flag = false;
				}			
			}

			//Fetch emp count
			Utilities.selectLeftTreeFrame(driver);
			String 	allEmpCount = driver.findElement(By.xpath("//table[@id='selectionHdr_tbl_id']/tbody/tr/td[1]")).getText();
			System.out.println("profiles emp count:" + allEmpCount);
			int valrcProf = driver.findElements(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr")).size();
			if (valrcProf > 1) {
				driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr[1]/td/div/nobr/a/span")).click();
				Thread.sleep(2000);
			}
			
			driver.switchTo().defaultContent();
			if (!VerintHomePageScreen.selectMenuItem(driver, "Reports", "Instances")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
				LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver, "Reports", "Instances")) {
					extent.log(LogStatus.WARNING, "Not able to select Instances menu. Please try again");
					return flag = false;
				}			
			}
			if (!RequestsResultsScreen.selectReportSelection(driver, ReportSelection)) {
				return flag = false;
			}
			driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Parameters")).size() != 0) {
				driver.findElement(By.linkText("Parameters")).click();
			} else {
				extent.log(LogStatus.WARNING, "Parameters section is not displayed. Please try again");
				return flag = false;
			}
			Utilities.selectRightPaneView(driver);
			if (!RequestsResultsScreen.setReportName(driver, ReportName)) {
				return flag = false;
			}
			if (!RequestsResultsScreen.setReportNote(driver, ReportNote)) {
				return flag = false;
			}
			if (!RequestsResultsScreen.clickRunNow(driver)) {
				return flag = false;
			}
			
			//New window 
			Thread.sleep(10000);
			Set<String> windowIds1 = driver.getWindowHandles();
			Iterator<String> iterator = windowIds1.iterator();
			mainWinID1 = iterator.next();  //main window
			String  popWindow1 = iterator.next();  //report window
			driver.switchTo().window(popWindow1);
			Thread.sleep(2000);
			driver.manage().window().maximize();
			System.out.println(mainWinID1);
			System.out.println(popWindow1);
			if (popWindow1 == null) {
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "WFMReport"));
				return flag = false;
			}
			driver.switchTo().defaultContent();
			Thread.sleep(2000);
			driver.switchTo().frame("CVIFrame_THIS_");
			String empCount = "";
			String totalEmpCount = "";
			if (driver.findElements(By.xpath("//html/body/table[1]/tbody/tr[2]/td[1]/table[2]/tbody/tr[3]/td[2]/span")).size() != 0) {
				empCount = driver.findElement(By.xpath("//html/body/table[1]/tbody/tr[2]/td[1]/table[2]/tbody/tr[3]/td[2]/span")).getText();
			}
			if (empCount.contains(",")) {
				String[] count = empCount.split(",");
				System.out.println("length:" + count.length);
				if (count.length == 2) {
					totalEmpCount=count[0] + count[1];
				} else if (count.length == 3) {
					totalEmpCount=count[0]+count[1]+count[2];
				}					
			}
			else {
				totalEmpCount = empCount;
			}
			System.out.println("Report:" + totalEmpCount);
			if (allEmpCount.contains(totalEmpCount)) {
				extent.log(LogStatus.PASS, "User Management - Profiles: Total Employee Count :" + allEmpCount + "; Report Type :All Employess- Total Count :" + totalEmpCount + " both are matched");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "WFMReport"));
			} else {
				extent.log(LogStatus.FAIL, "User Management - Profiles:Total Employee Count: " + allEmpCount + "; Report Type :All Employess- Total Count :" + totalEmpCount + " both are NOT matched");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "WFMReport"));
				return flag = false;
			}
			driver.switchTo().defaultContent();
			driver.close();
			Thread.sleep(3000);
			driver.switchTo().window(mainWinID1);
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			workbook.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "WFM", htmlReportName, 4, 5);
		}
		return flag;
	}
}
