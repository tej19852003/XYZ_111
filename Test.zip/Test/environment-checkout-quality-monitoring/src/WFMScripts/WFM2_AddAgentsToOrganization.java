package WFMScripts;

import java.io.File;

import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ProfilesScreen;

import Utilities.Utilities;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM2_AddAgentsToOrganization {
	
	public static ExtentReports extent = ExtentReports.get(WFM2_AddAgentsToOrganization.class);
	
	public static boolean AddAgentsToOrganization() throws Exception {
		boolean flag = true;
		Screen sobj = new Screen();
		String windowName="";
		String htmlReportName="WFM2_AddAgentsToOrganization" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(htmlReportName, "Add Agents To Organization");
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook workbook = Workbook.getWorkbook(fis);
	    Sheet worksheet = workbook.getSheet("WFM_TestSet");
	    String userAlias = worksheet.getCell(8, 2).getContents();
	    String userLastName = worksheet.getCell(9, 2).getContents();
	    String organizatioName = worksheet.getCell(5, 2).getContents();
		
		try {
			LoginScreen.launchVerint(driver,Utilities.PROPERTIES.getProperty("VerintURL"));
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver, "User Management", "user_profiles")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles")) {
					extent.log(LogStatus.WARNING, "Not able to select Profiles menu. Please try again.");
					return flag = false;
				}
			}
			if (!ProfilesScreen.FindSelect(driver, userLastName)) {
				Utilities.selectRightPaneView(driver);				
				if (!ProfilesScreen.clickImportDomainUsers(driver)) {
					return flag = false;
				}
				Thread.sleep(2000);				
				if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\SelectUsers_EnterObjNameToSelect.png") != null) {
					sobj.type(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\SelectUsers_EnterObjNameToSelect.png", userAlias);
				}				
				Thread.sleep(1000);
				if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\SelectUsers_OK_Btn.png") != null) {
					sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\SelectUsers_OK_Btn.png");
				}				
				Thread.sleep(5000);
				Utilities.selectRightPaneView(driver);
				if (!ProfilesScreen.checkErrorMessage(driver)) {
						return flag = false;
				}
				Thread.sleep(2000);				
				if (!ProfilesScreen.FindSelect(driver, userLastName)) {
					return flag = false;
				}				
			}
			//End of user name

			//Verify whether profile name is already exist or not
			Utilities.selectLeftTreeFrame(driver);
			Boolean temp = false;
			try {
				int valrcProf=driver.findElements(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr")).size();
				System.out.println("valrcPriv:" + valrcProf);
				for (int j=1; j<=24; j++) {
					String profilenameApp=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr["+j+"]/td/div/nobr/a/span")).getText().trim();
					System.out.println("profilenameApp:"+profilenameApp);
					System.out.println("profilenameCreated:"+userLastName);
					
					if (profilenameApp.contains(userLastName)) {
						driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr["+j+"]/td/div/nobr/a/span")).click();
						temp = true;
						break;
					}
				}
				if (temp==true) {
					System.out.println(" profile exist");
					extent.log(LogStatus.INFO, "Name: " + userLastName + " Created/Selected/imported successfully");
				} else {
					Utilities.selectRightPaneView(driver);					
					ProfilesScreen.clickImportDomainUsers(driver);				
					Thread.sleep(2000);				 
					Utilities.sikuliType(driver, Utilities.PROPERTIES.getProperty("ImagesPath")+"\\SelectUsers_EnterObjNameToSelect.png", userAlias);
					Utilities.sikuliClick(driver, Utilities.PROPERTIES.getProperty("ImagesPath")+"\\SelectUsers_OK_Btn.png");
					Thread.sleep(5000);
					Utilities.selectRightPaneView(driver);
					if (!ProfilesScreen.checkErrorMessage(driver)) {
							return flag = false;
					}
					Thread.sleep(2000);					
					if (!ProfilesScreen.selectProfile(driver,userLastName)) {
						return flag = false;
					}
				}
				Utilities.selectRightPaneView(driver);
				Utilities.sikuliClick(driver, Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Scrollbar.png");

                //Click on organization edit icon
                if (!ProfilesScreen.clickOrganizationEdit(driver)) {
					return flag = false;
				}
				Thread.sleep(6000);			
				windowName=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver, organizatioName);
					
				driver.switchTo().window(windowName);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver)) {
					return flag = false;
				}
				ProfilesScreen.verifySuccessMessage(driver);
			} catch(Exception e){
					System.out.println(e);
			}
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			workbook.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "WFM", htmlReportName, 4, 2);
		}
		return flag;
	}
}
