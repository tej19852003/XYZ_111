package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.CampaignSettings;
import ScreenObjects.ForecastScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.PulseScreen;
import ScreenObjects.ServiceGoals;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkQueuesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM11_CreatingViewsInPulse {
	public static ExtentReports extent = ExtentReports.get(WFM10_Create_shift_bidding.class);
	
	public static boolean CreateViews_Pulse()throws Exception {
		boolean flag=true;
		String windowName="";
		String HTMLReportName="WFM11_CreatingViewsInPulse"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Create Views in pulse");
				
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 			
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook workbook = Workbook.getWorkbook(fis);
	    Sheet worksheet = workbook.getSheet("WFM_TestSet");
	    String campName = worksheet.getCell(10,9).getContents();
	    String StartDate = worksheet.getCell(18,9).getContents();
	    String OrgName = worksheet.getCell(5,9).getContents();
	    String Period = worksheet.getCell(14,9).getContents();
	    String wqname = worksheet.getCell(17,9).getContents();
	    String WqDesc = worksheet.getCell(23,9).getContents();
	    String organizationDesc = worksheet.getCell(6,9).getContents();
	    String parentOrganization = worksheet.getCell(7,9).getContents();

	    try {
	    	LoginScreen.launchVerint(driver,Utilities.PROPERTIES.getProperty("VerintURL"));
	    	if (!LoginScreen.verifyLoginPageLaunched(driver)) {
	    		return flag = false;
	    	}
	    	LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
	    	LoginScreen.clickLogin(driver);
	    	if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
	    		return flag = false;
	    	}
	    	String mainWindow = driver.getWindowHandle();
	    	VerintHomePageScreen.selectMenuItem(driver, "Forecasting and Scheduling","Compaign Settings");
	    	Utilities.selectLeftTreeFrame(driver);
	    	if (CampaignSettings.CampaignExist(driver, campName)) {
	    		CampaignSettings.deleteCampaign(driver);
		    	Utilities.sikuliClick(driver, Utilities.PROPERTIES.getProperty("ImagesPath")+"\\btnok_camp.png");
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
	    	} else {
	    		System.out.println("no campaign exist");
	    	}
	    	driver.switchTo().defaultContent();
	    	VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings");
	    	Utilities.selectLeftTreeFrame(driver);
			Boolean temp=false;
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			for (int i=1; i<=rc1; i++) {
				if (i <= 15) {
					String orgName = driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+i+"]/td/a")).getText();
					Thread.sleep(1000);
					if (orgName.contains(OrgName)) {
						driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+i+"]/td/a")).click();
						temp = true;
						break;
					}
				}
			}
			if (temp==true) {
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: "+OrgName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));								
			}			
			//End of verify organization

			//Create organization
			if (temp==false) {
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization)) {
					return flag = false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver)) {
					return flag = false;
				}
				OrganizationSettings.setOrganizationName(driver,OrgName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver)) {
					return flag = false;
				}
			}
			driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	VerintHomePageScreen.selectMenuItem(driver,"Organization Management", "Work Queues Settings");

			//Verify if work queue already exist
	    	Utilities.selectRightPaneView(driver);
	    	flag=false;
	    	int qrows=driver.findElements(By.xpath("//div[@id='workAreaWrapper']//table[@id='workpaneListWrapper']//tbody//tr")).size();
	    	System.out.println("no of rows in work queue are:" + qrows);
	    	for (int i=0; i<qrows; i++) {
	    		String qname=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr[@id='workpaneListr"+i+"']//th//a//span")).getAttribute("innerText");
	    		System.out.println("work queue name is" + qname);
	    		if (qname.contains(wqname)) {
	    			flag = true;
	    			break;
	    		}
	    	}
	    	if(flag==true) {
	    		extent.log(LogStatus.PASS,"work queue already exist");
	    	} else {
	    		WorkQueuesScreen.clickworkqueue(driver);
				WorkQueuesScreen.setWorkqueueName(driver, wqname);
				WorkQueuesScreen.setWorkqueueDescription(driver,WqDesc);
				WorkQueuesScreen.clickSave(driver);
	    	}
	    	driver.switchTo().defaultContent();
	    	if (!VerintHomePageScreen.selectMenuItem(driver, "Forecasting and Scheduling", "Compaign Settings")) {
	    		Utilities.logout(driver);
	    		LoginScreen.setTextInUsername(driver, Utilities.getPassword(driver, 0, 1));
				LoginScreen.setTextInPassword(driver, Utilities.getPassword(driver, 1, 1));
	    		LoginScreen.clickLogin(driver);
	    		if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
	    		driver.switchTo().defaultContent();
	    		
				if (!VerintHomePageScreen.selectMenuItem(driver, "Forecasting and Scheduling", "Compaign Settings")) {
					extent.log(LogStatus.WARNING, "Not able to select Compaign Settings menu. Please try again");
					return flag = false;
				}
	    	}
			//verify whether Compaign name is already exist or not
			Utilities.selectLeftTreeFrame(driver);

			if (CampaignSettings.CampaignExist(driver, campName)) {
				extent.log(LogStatus.PASS, "Compaign Name:" + campName + " already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			}
			//end of verify campaign

			//create campaign
			else {
				Utilities.selectRightPaneView(driver);
				if (!CampaignSettings.clickCreateCampaign(driver)) {
					return flag = false;
				}
				CampaignSettings.setCampaignName(driver,campName);
				CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");
				if (!CampaignSettings.clickSave(driver)) {
					return flag = false;
				}
				Utilities.selectLeftTreeFrame(driver);
				if (!CampaignSettings.selectCampaignFromLeftTreeFrame(driver,campName)) {
					return flag = false;
				}
	    	}
			Utilities.selectRightPaneView(driver);

			CampaignSettings.clickSave(driver);
			System.out.println("clicked on save");
			Thread.sleep(2000);
			Utilities.selectLeftTreeFrame(driver);
			Thread.sleep(2000);
			if (driver.findElements(By.xpath("//img[@id='campaignSPTreer0Norg']")).size() != 0) {
				driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
			}

			if (CampaignSettings.schedulePeriodExist(driver, Period)) {
				extent.log(LogStatus.INFO,"schedule period:" + Period + "already exist");
			} else {
				CampaignSettings.clickSchedulingPeriod(driver);
				Utilities.selectRightPaneView(driver);
				CampaignSettings.setSchedulingPeriodStartDate(driver, StartDate);
				if(!CampaignSettings.clickSchedulingPeriodPSave(driver)) {
					return flag = false;
				}
				CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");
				CampaignSettings.clickOrganizationSelector(driver);
				for(String winHandle :driver.getWindowHandles()) {
					driver.switchTo().window(winHandle);
					System.out.println("title:"+driver.getTitle());
					if(driver.getTitle().contains("Organization Selector")) {
						System.out.println("You are in organization selector window");
						driver.manage().window().maximize();
						break;
					}
				}
				CampaignSettings.selectOrganizationSelector(driver, OrgName);
				driver.switchTo().window(mainWindow);
				CampaignSettings.selectHoursOfOperation(driver);
			}

			Thread.sleep(2000);
			if (!CampaignSettings.clickCampaignSettingsSave(driver)) {
				return flag = false;
			}
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			CampaignSettings.clickQueue(driver);
			Thread.sleep(3000);

			CampaignSettings.selectSchedulePeriod(driver, Period);
			CampaignSettings.clickAddSP(driver);
			Thread.sleep(2000);
			for(String winHandle :driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
				System.out.println("title:"+driver.getTitle());
				if(driver.getTitle().contains("Add to SP")) {
					System.out.println("You are in Add to SP window");
					driver.manage().window().maximize();
					break;
				}
			}
			CampaignSettings.selectWorkQueue(driver);
			driver.switchTo().window(mainWindow);

			if (!CampaignSettings.clickCampaignSettingsSave(driver)) {
				return flag = false;
			}
			driver.switchTo().defaultContent();
			Thread.sleep(3000);

			//go to forecast menu and set the values
			VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Forecast");
			Thread.sleep(3000);
			ForecastScreen.selectCampaign(driver, campName);
			ForecastScreen.setPeriod(driver, Period);
			Thread.sleep(2000);
			ForecastScreen.selectworkQueue(driver, wqname);
			Thread.sleep(3000);
			driver.switchTo().defaultContent();
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\btn_clear.png");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Button_Scale.png");

			Utilities.sikuliType(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\value_total.png","15");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\value_sun.png");

			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\button_set.png");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Save_scale.png");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Save_popup.png");

			//Utilities.selectLeftTreeFrame(driver);
			Thread.sleep(5000);
			ForecastScreen.selectworkQueue(driver, wqname);
			Thread.sleep(3000);
			driver.switchTo().defaultContent();
			Thread.sleep(2000);

			VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","ServiceGoals");
			Thread.sleep(2000);

			ServiceGoals.setPeriod(driver, Period);
			ServiceGoals.selectworkQueue(driver, wqname);
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			Thread.sleep(3000);
			Utilities.sikuliType(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\ans.png","0");
			Utilities.sikuliType(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\seconds.png","0");
			Utilities.sikuliType(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\ans.png","60");

			Utilities.sikuliType(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\seconds.png","40");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Save_scale.png");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Save_popup.png");
			Thread.sleep(2000);
			ServiceGoals.selectworkQueue(driver, wqname);
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			Thread.sleep(2000);

			VerintHomePageScreen.selectMenuItem(driver,"Tracking","Pulse");
			PulseScreen.setcampaign(driver, campName);
			PulseScreen.selectqueue(driver, wqname);
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\CreateViewButton.png");
			System.out.println(RandomStringUtils.randomAlphabetic(2));
			Utilities.sikuliType(driver, Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Name.png", "test" + RandomStringUtils.randomAlphabetic(2));
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\AddStatisticsButton.png");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Statistics_actual.png");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Statistics_forecasted.png");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Statistics_forecasted.png");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Statistics_forecasted.png");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Save_statistics.png");
			extent.log(LogStatus.INFO,"view is created sucessfully");
			Thread.sleep(3000);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "views"));
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\EditViewbutton.png");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\DeleteView.png");
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\view_yes.png");
			System.out.println("view deleted sucessfully");
			Utilities.logout(driver);
			Thread.sleep(3000);
			driver.findElement(By.id("username")).clear();
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
			Utilities.selectLeftTreeFrame(driver);
			CampaignSettings.CampaignExist(driver, campName);
			CampaignSettings.deleteCampaign(driver);
			Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\btnok_camp.png");
			Thread.sleep(3000);
	    } catch(Exception e) {
	    	e.printStackTrace();
	    } finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			workbook.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,9);
		}
		return flag;
	}
}
