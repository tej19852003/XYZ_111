package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM1_CreateOrganization {
	
	public static ExtentReports extent = ExtentReports.get(WFM1_CreateOrganization.class);
	
	public static boolean CreateOrganization() throws Exception {
		boolean flag = true;
		String htmlReportName="WFM1_CreateOrganization" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(htmlReportName, "Create Organization");
				
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 			
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook workbook = Workbook.getWorkbook(fis);
	    Sheet worksheet = workbook.getSheet("WFM_TestSet");
	    String organizationName = worksheet.getCell(5,1).getContents();
	    String organizationDesc = worksheet.getCell(6,1).getContents();
	    String parentOrganization = worksheet.getCell(7,1).getContents();
		
		try {
			LoginScreen.launchVerint(driver,Utilities.PROPERTIES.getProperty("VerintURL"));
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}			
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver, "Organization Management", "Organization Settings")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver, Utilities.PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver, Utilities.PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag = false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver, "Organization Management", "Organization Settings")) {
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again.");
					return flag = false;
				}
			}
			
			//Verify whether Organization name is already exist or not
			Utilities.selectLeftTreeFrame(driver);
			Boolean temp = false;
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			for (int i=1; i<=rc1; i++) {
				if (i <= 15) {
					String orgName=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[" + i + "]/td/a")).getText();
					Thread.sleep(1000);
					if (orgName.contains(organizationName)) {
						driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[" + i + "]/td/a")).click();
						temp = true;
						break;
					}
				}
			}
			if (temp==true) {
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: " + organizationName + " already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));								
			}			
			//End of verify organization

			//Create organization
			if (temp==false) {
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver, parentOrganization)) {
					return flag = false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver)) {
					return flag = false;
				}
				OrganizationSettings.setOrganizationName(driver,organizationName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver)) {
					return flag = false;
				}
				//Validation
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver, organizationName)) {
					return flag = false;
				}
			}
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			workbook.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "WFM", htmlReportName, 4, 1);
		}
		return flag;
	}
}
