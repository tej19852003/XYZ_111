package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;


import ScreenObjects.AuctionScreen;
import ScreenObjects.CalendarScreen;
import ScreenObjects.CampaignSettings;
import ScreenObjects.FSEmployees;
import ScreenObjects.ForecastScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.ServiceGoals;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkPatternScreen;
import ScreenObjects.WorkQueuesScreen;
import ScreenObjects.WorkRulesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM10_Create_shift_bidding
{
	public static ExtentReports extent = ExtentReports.get(WFM10_Create_shift_bidding.class);
	
	public static boolean CreateshiftBidding()throws Exception
	{
		boolean flag=true;
		String HTMLReportName="WFM10_Create_shift_bidding"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Create shift Bidding");
				
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 			
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	    Sheet testID=Wb.getSheet("TestIds");
	    String wpname=Ws.getCell(15,8).getContents();
	    String EmpName = testID.getCell(0,5).getContents();
	    String auctionName = Ws.getCell(16,8).getContents();
	    String campName=Ws.getCell(10,8).getContents();
	    String Period=Ws.getCell(14,8).getContents();
	    String workQueue=Ws.getCell(17,8).getContents();
	    String ShiftName=Ws.getCell(19,8).getContents();
	    String deadline=Ws.getCell(20,8).getContents();
	    String StartDate=Ws.getCell(18,8).getContents();
	    String OrgName=Ws.getCell(5,8).getContents();
	    String wqname=Ws.getCell(17,8).getContents();
	    String WqDesc=Ws.getCell(23,8).getContents();	
	    String organizationDesc = Ws.getCell(6,8).getContents();
	    String parentOrganization = Ws.getCell(7,8).getContents();
	    String FirstName=testID.getCell(0,5).getContents();
	    String LastName=Ws.getCell(32,8).getContents();
	    String agentname=Ws.getCell(33,8).getContents();
	    
	   
	    
	    
	    
	    try
	    {
	    	LoginScreen.launchVerint(driver,Utilities.PROPERTIES.getProperty("VerintURL"));
	    	if(!LoginScreen.verifyLoginPageLaunched(driver))
	    	{
	    		return flag=false;
	    	}
	    	LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
	    	LoginScreen.clickLogin(driver);
	    	
	    	if(!VerintHomePageScreen.verifyVerintHomePage(driver))
	    	{
	    		return flag = false;
	    	}
	    	String mainwindow=driver.getWindowHandle();
	    	VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings");
	    	Utilities.selectLeftTreeFrame(driver);
			Boolean Temp1=false;			
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			//System.out.println("rc1:"+rc1);
			for (int j=1;j<=rc1;j++)
			{
				if (j<=15)
				{
				String orgName1=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();
				Thread.sleep(1000);
				if (orgName1.contains(OrgName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: "+OrgName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));								
			}			
			//end of verify organization
			//create organization
			if (Temp1==false)
			{
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization))
				{
					return flag=false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver))
				{
					return flag=false;
				}
				OrganizationSettings.setOrganizationName(driver,OrgName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver))
				{
					return flag=false;
				}
			}
			driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queues Settings");
	    	//verify if work queue already exist
	    	Utilities.selectRightPaneView(driver);
	    	boolean flag1=false;
	    	int qrows=driver.findElements(By.xpath("//div[@id='workAreaWrapper']//table[@id='workpaneListWrapper']//tbody//tr")).size();
	    	System.out.println("no of rows in work queue are:" + qrows);
	    	for(int j=0;j<qrows;j++)
	    	{
	    		String qname=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr[@id='workpaneListr"+j+"']//th//a//span")).getAttribute("innerText");
	    		System.out.println("work queue name is" + qname);
	    		if(qname.contains(wqname))
	    		{
	    			flag1=true;
	    			break;
	    		}
	    	}
	    	if(flag1==true)
	    	{
	    		extent.log(LogStatus.PASS,"work queue already exist");
	    	}
	    	//creation of new work queue
	    	else
	    	{
	    		WorkQueuesScreen.clickworkqueue(driver);
				WorkQueuesScreen.setWorkqueueName(driver, wqname);
				WorkQueuesScreen.setWorkqueueDescription(driver,WqDesc);
				WorkQueuesScreen.clickSave(driver);
	    	}
	    	driver.switchTo().defaultContent();
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
	    	Utilities.selectLeftTreeFrame(driver);
	    	if(CampaignSettings.CampaignExist(driver, campName))
	    	{
	    		CampaignSettings.deleteCampaign(driver);
		    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\btnok_camp.png");
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
	    	}
	    	else
	    	{
	    		System.out.println("no campaign exist");
	    	}
	    	driver.switchTo().defaultContent();
	    	VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles");
			if(!ProfilesScreen.FindSelect(driver,EmpName))
			{
				Utilities.selectRightPaneView(driver);
				ProfilesScreen.clickCreate(driver);
				ProfilesScreen.setProfilesLastName(driver, LastName);
				ProfilesScreen.setProfilesFirstName(driver, FirstName);
				Utilities.selectRightPaneView(driver);
				Utilities.sikuliClick(driver, Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);	
				for(String winHandle :driver.getWindowHandles()){
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().contains("Effective Dates"))
	                {                	
	                	System.out.println("You are in Effective Dates window");
	                	driver.manage().window().maximize();
	                    break;
	                }			
				}
//				String windowName=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
					
				driver.switchTo().window(mainwindow);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
				ProfilesScreen.verifySuccessMessage(driver);
			}
			else
			{
				System.out.println("user already exist");
			}
			driver.switchTo().defaultContent();
	    	if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Pattern"))
			{
				extent.log(LogStatus.WARNING, "Not able to select Work Pattern menu. Please try again");
				return flag=false;
			}	
	    	Utilities.selectRightPaneView(driver);
	    	Thread.sleep(5000);
	    	//verify if work pattern already exist or not
	    	boolean Temp=false;
	    	driver.findElement(By.name("itemToFind")).sendKeys(wpname);
	    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
	    	Thread.sleep(2000);
	    	List<WebElement> li=driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']"));
	    	System.out.println(li.size());
	    	for(WebElement elt:li)
	    	{
	    		//System.out.println("**************");
	    		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
	    		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
	    		if(wname.contains(wpname))
	    		{
	    			Temp=true;
	    			break;
	    		}
	    	}
	    	
	    	
	    	
	    	
	    	
	    	
			if (Temp==true)
			{					
				extent.log(LogStatus.PASS, "Work pattren Name:"+wpname+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Work Pattern"));
			}
			
			//end of verify work pattern
			//create a new work pattern
			if(Temp==false)
			{
				
			
	    	if(!WorkPatternScreen.clickworkpattern(driver))
	    	{
	    		return flag=false;
	    	}
	    	WorkPatternScreen.setWorkpatternName(driver, wpname);
	    	WorkPatternScreen.setWorkpatternDescription(driver,".AutomationDescWorkPattern");
	    	WorkPatternScreen.setpossibledaysOff(driver);
	    	WorkPatternScreen.clickAddshift(driver);
	    	for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Shift Details"))
                {                	
                	System.out.println("You are in Shift Details window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
//	    	String windowName=Utilities.setWindowFocus(driver);
	    	WorkPatternScreen.setshift(driver,ShiftName);
	    	driver.switchTo().window(mainwindow);
	    	
	    	if(!WorkPatternScreen.clickSave(driver))
	    	{
	    		return flag=false;
	    	}
			}
	    	driver.switchTo().defaultContent();
	    	//go to work rules Menu
	    	VerintHomePageScreen.selectMenuItem(driver,"User Management", "Work Rules");
	    	WorkRulesScreen.findEmployee(driver,EmpName);
	    	WorkRulesScreen.selectEmployee(driver, EmpName);
	    	//verification of existing work pattern is already added to work rules
	    	boolean temp2=false;
	    	Utilities.selectRightPaneView(driver);
	    	
	    	int row=driver.findElements(By.xpath("//div[@id='workPatternTableWrapper']//table[@id='workPatternTableRef']//tbody//tr//td")).size();
	    	System.out.println("no of row count  in work pattern iis: "+ row);
	    	if(row>5)
	    	{
	    	String workpname=driver.findElement(By.xpath("//table[@id='workPatternTableRef']//tbody//tr[@id='workPatternTabler0']//th[@id='workPatternTabler0c0']//a")).getAttribute("innerText");
	    	System.out.println("work pattern name is: "+ workpname);
	    	if(workpname.contains(wpname))
	    	{
	    		temp2 = true;
	    	}
	    	if(temp2==true)
	    	{
	    		extent.log(LogStatus.INFO,"work pattern:" +wpname+ " is already added to the work rules");
	    	}
	    	}
	    	//addition of created work pattern to Work rules 
	    	if(temp2==false)
	    	{
	    		WorkRulesScreen.clickAdd(driver);
	    		Thread.sleep(2000);
	    		for(String winHandle :driver.getWindowHandles()){
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().contains("Work Patterns"))
	                {                	
	                	System.out.println("You are in Work Patterns window");
	                	driver.manage().window().maximize();
	                    break;
	                }			
				}
//		    	String winhandle=Utilities.setWindowFocus(driver);
		    	WorkRulesScreen.clickAddWorkPattern(driver,wpname);
		    	driver.switchTo().window(mainwindow);
	    	}
	    	Thread.sleep(2000);
	    	WorkRulesScreen.clickSave(driver);
	    	
	    	
	    	driver.switchTo().defaultContent();
	    	if(!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
	    	{
	    		Utilities.logout(driver);
	    		LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
				LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
	    		LoginScreen.clickLogin(driver);
	    		if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Compaign Settings menu. Please try again");
					return flag=false;
				}
	    	}
	    	//VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
				//verify whether Compaign name is already exist or not		
				Utilities.selectLeftTreeFrame(driver);
				boolean Temp6=false;
				int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
				System.out.println("rc:"+rc);
				for (int i=1;i<=rc;i++)
				{
					if (i<=15)
					{
					String campNameApp=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).getText();
					System.out.println(i+":"+campNameApp);
					if (campNameApp.contains(campName))
					{
						driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).click();
						//driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
						Thread.sleep(3000);
						Temp6=true;
						break;
					}}
				}
				if (Temp6==true)
				{					
					extent.log(LogStatus.PASS, "Compaign Name:"+campName+" already exist");
					extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				}
				//end of verify campaign
				//create campaign
				if (Temp6==false)
				{
					Utilities.selectRightPaneView(driver);
					
					if (!CampaignSettings.clickCreateCampaign(driver))
					{
						return flag=false;
					}
					CampaignSettings.setCampaignName(driver,campName);
					CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");				
					if (!CampaignSettings.clickSave(driver))
					{
						return flag=false;
					}
					//validation
					Utilities.selectLeftTreeFrame(driver);
					if (!CampaignSettings.selectCampaignFromLeftTreeFrame(driver,campName))
					{
						return flag=false;
					}
	    	}
				
				Utilities.selectLeftTreeFrame(driver);
				boolean Temp8=false;
				int rc4=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
				System.out.println("rc1:"+rc4);
				for (int i=1;i<=rc4;i++)
				{
					if (i<=15)
					{
					String campNameApp=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).getText();
					System.out.println(i+":"+campNameApp);
					if (campNameApp.contains(campName))
					{
						driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).click();
						Thread.sleep(3000);
						Temp8=true;
						break;
					}}
				}
				if (Temp8==true)
				{					
					extent.log(LogStatus.PASS, " clciked on the Compaign Name:"+campName);
					//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				}
				if(Temp8==false)
				{
					extent.log(LogStatus.FAIL,"campaign name: "+campName+" does not exist");
				}
				
				Utilities.selectRightPaneView(driver);
				
				
				CampaignSettings.clickSave(driver);
				System.out.println("clicked on save");
				Thread.sleep(2000);
				Utilities.selectLeftTreeFrame(driver);
				Thread.sleep(2000);
				if(driver.findElements(By.xpath("//img[@id='campaignSPTreer0Norg']")).size()!=0)
				{
					driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
				}
				
				//verify if schedule period exist
				boolean Temp3=false;
				int rc2=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table//tr[starts-with(@id,'campaignSPTreer0r')]")).size();
				System.out.println("rc2:"+rc2);
				if (rc2>0)
				{
					driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[1]/td/a")).click();
				}
				for (int i=0;i<rc2;i++)
				{
					
					
					
					String queuename=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer0r"+i+"']/td/a")).getText();
					System.out.println(i+":"+queuename);
					if (queuename.contains(Period))
					{
						System.out.println("schedule period exist");
						driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer0r"+i+"']/td/a")).click();
						Temp3=true;
						break;
						
					}
				}
				if(Temp3==true)
				{
					extent.log(LogStatus.INFO,"schedule period:" + Period + "already exist");
				}
				//create a new scheduling period
				if(Temp3==false)
				{
					
					CampaignSettings.clickSchedulingPeriod(driver);
					Utilities.selectRightPaneView(driver);
					CampaignSettings.setSchedulingPeriodStartDate(driver, StartDate);
					
					if(!CampaignSettings.clickSchedulingPeriodPSave(driver))
					{
						return flag=false;
					}
					CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");
					CampaignSettings.clickOrganizationSelector(driver);
					for(String winHandle :driver.getWindowHandles())
					{
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().contains("Organization Selector"))
		                {                	
		                	System.out.println("You are in organization selector window");
		                	driver.manage().window().maximize();
		                    break;
		                }	
					}
//					String windowName=Utilities.setWindowFocus(driver);
					CampaignSettings.selectOrganizationSelector(driver, OrgName);
					driver.switchTo().window(mainwindow);
					CampaignSettings.selectHoursOfOperation(driver);
					CampaignSettings.clickCampaignSettingsSave(driver);
				}
				
				Thread.sleep(2000);
				if(!CampaignSettings.clickCampaignSettingsSave(driver))
				{
					return flag=false;
				}
				Thread.sleep(2000);
				driver.switchTo().defaultContent();
				Thread.sleep(2000);
				driver.switchTo().defaultContent();
				//verify if queue is laready linked to campaign
				CampaignSettings.clickQueue(driver);
				Thread.sleep(3000);
				
				boolean temp8=false;
		    	Utilities.selectRightPaneView(driver);
		    	
		    	int row6=driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr//td")).size();
		    	System.out.println("no of row count  in work pattern iis: "+ row6);
		    	if(row6>0)
		    	{
		    	String workqname=driver.findElement(By.xpath("//table[@id='tableRef']//tbody//tr[@id='tabler0']//th[@id='tabler0c0']//a")).getAttribute("innerText");
		    	System.out.println("work pattern name is: "+ workqname);
		    	if(workqname.contains(wqname))
		    	{
		    		temp8 = true;
		    	}
		    	if(temp8==true)
		    	{
		    		extent.log(LogStatus.INFO,"work Queue:" +wqname+ " is already added to the campaign queues");
		    	}
		    	}
		    	//link created queue to campaign
		    	
				CampaignSettings.clickAddSP(driver);
				Thread.sleep(2000);
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().contains("Add to SP"))
	                {                	
	                	System.out.println("You are in Add to SP window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
//				String winhandle=Utilities.setWindowFocus(driver);
				CampaignSettings.selectWorkQueue(driver);
				driver.switchTo().window(mainwindow);
		    	
				if(!CampaignSettings.clickCampaignSettingsSave(driver))
				{
					return flag=false;
				}
				driver.switchTo().defaultContent();
				Thread.sleep(3000);
				VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","FS_Profiles");
				Thread.sleep(3000);
				if (! FSEmployees.selectCampaign(driver,campName))
				{
					return flag=false;
				}
				if (! FSEmployees.selectPeriod(driver,Period))
				{
					return flag=false;
				}
				if(FSEmployees.Empexist(driver,EmpName))
				{
					extent.log(LogStatus.INFO,"employee Name:" +EmpName+"is allready added");
				}
				//addition of agent1 to campaign
				else
				{
					FSEmployees.clickAddEmployeeToSP(driver);
					for(String winHandle :driver.getWindowHandles()){
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().contains("Add to Scheduling Period"))
		                {                	
		                	System.out.println("You are in Add Scheduling period window");
		                	driver.manage().window().maximize();
		                    break;
		                }			
					}
//					String win=Utilities.setWindowFocus(driver);
					FSEmployees.addEmployeeToSP(driver,EmpName);
					FSEmployees.clickAdd(driver);
					driver.switchTo().window(mainwindow);
					FSEmployees.SelectEmployee(driver,EmpName);
					FSEmployees.ClickSave(driver);
				}
				
				
				driver.switchTo().defaultContent();
				Thread.sleep(2000);
	    	//Go to auction menu
	    	VerintHomePageScreen.selectMenuItem(driver,"Request Management","Auction");
	    	//verify that auction already exist
	    	boolean flag4=false;
	    	Utilities.selectLeftTreeFrame(driver);
	    	int rows=driver.findElements(By.xpath("//div[@id='listWrapper']//table[@id='listLIST_TBL_NAME']//tbody//tr")).size();
	    	System.out.println("no of rows in auction table is:"+ rows);
	    	if(rows>0)
	    	{
	    		for(int i=1;i<=rows;i++)
	    		{
	    			String aname=driver.findElement(By.xpath("//div[@id='listWrapper']//table[@id='listLIST_TBL_NAME']//tbody//tr["+i+"]//td//div[@class='treeNode']//nobr//a")).getAttribute("innerText");
			    	System.out.println("auction name is: " + aname);
			    	if(aname.contains(auctionName))
			    	{
			    		flag4=true;
			    		break;
			    	}
	    		}
	    		
		    	if(flag4==true)
		    	{
		    		extent.log(LogStatus.INFO,"auction:"+auctionName+" already exist");
		    	}
	    	}
	    
	    	//creation of new auction
	    	if(flag4==false)
	    	{
	    	AuctionScreen.clickSchedulePeriod(driver);
	    	Thread.sleep(2000);
	    	for(String winHandle :driver.getWindowHandles())
			{
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Scheduling Period Selector"))
                {                	
                	System.out.println("You are in Scheduling Period Selector window");
                	driver.manage().window().maximize();
                    break;
                }	
			}
//	    	String win1=Utilities.setWindowFocus(driver);
	    	AuctionScreen.setPeriod(driver, campName, Period);
	    	driver.switchTo().window(mainwindow);
	    	AuctionScreen.setAuctionName(driver, auctionName);
	    	AuctionScreen.setdeadline_auction(driver, deadline);
	    	if(!AuctionScreen.clickSave(driver))
	    	{
	    		return flag=false;
	    	}
	    	}
	    	driver.switchTo().defaultContent();
	    	// go to calendar menu and schedule the shift
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Calendar");
	    	
	    	CalendarScreen.selectPeriod(driver, Period);
	    	Thread.sleep(2000);
	    	CalendarScreen.SelectEmployee(driver,EmpName);
	    	Thread.sleep(3000);
	    	driver.switchTo().defaultContent();
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\button_runengine.png");
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\button_chkbox1.png");
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\button_chkbox2.png");
	    	VerintHomePageScreen.clickCalOK();
	    	Thread.sleep(40000);
	    	extent.log(LogStatus.INFO,"shift is scheduled sucessfully");
	    	Thread.sleep(3000);
	    	//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "shiftSchedule"));
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\buuton_publishschedule.png");
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\btnok_schedule.png");
	    	VerintHomePageScreen.clickyes();
	    	extent.log(LogStatus.INFO,"shift is published sucessfully");
	    	Thread.sleep(3000);
	    	//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "shiftpublished"));
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\OK.png");
	    	
	    	
	    	// go to forecast menu and set the values
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Forecast");
	    	Thread.sleep(2000);
	    	ForecastScreen.selectCampaign(driver,campName);
	    	//ForecastScreen.selectPeriod(driver, Period);
	    	ForecastScreen.setPeriod(driver, Period);
	    	Thread.sleep(2000);
	    	ForecastScreen.selectworkQueue(driver, workQueue);
	    	driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\btn_clear.png");
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Button_Scale.png");
	    	Utilities.sikuliType(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\value_total.png","15");
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\value_sun.png");
	       
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\button_set.png");
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Save_scale.png");
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Save_popup.png");
	    	Thread.sleep(5000);
	    	ForecastScreen.selectworkQueue(driver, workQueue);
	    	Thread.sleep(3000);
	    	driver.switchTo().defaultContent();
	    
	    	//Go to Service goals Menu and set the values
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","ServiceGoals");
	    	
	    	Thread.sleep(3000);
	    	//ServiceGoals.selectCampaign(driver,campName);
//	    	ServiceGoals.selectPeriod(driver, Period);
	    	ServiceGoals.setPeriod(driver, Period);
	    	ServiceGoals.selectworkQueue(driver, workQueue);
	    	driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	Utilities.sikuliType(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\ans.png","0");
	    	Utilities.sikuliType(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\seconds.png","0");
	    	Utilities.sikuliType(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\ans.png","80");
	    	//Thread.sleep(1000);
	    	Utilities.sikuliType(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\seconds.png","20");
	    	//Utilities.sikuliType(driver,Utilities.PROPERTIES.getProperty("imagesPath")+"\\seconds.png","10");
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Save_scale.png");
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\Save_popup.png");
	    	Thread.sleep(3000);
	    	ServiceGoals.selectworkQueue(driver, workQueue);
	    	Thread.sleep(2000);
	    	driver.switchTo().defaultContent();
	    	
	    	
	    	
	    	// Go to Calendar menu again and create phantom shift
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Calendar");
	    	Thread.sleep(5000);
	    	CalendarScreen.SelectEmployee(driver,EmpName);
	    	Thread.sleep(5000);
	    	Utilities.sikuliRightClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\agent2_shift.png");
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\phantom_shift.png");
	    	Thread.sleep(5000);
	    	//CalendarScreen.clickPhantomIcon(driver);
	    	//verification if the phantom is created or not
	    	Utilities.selectLeftTreeFrame(driver);
	    	int rcount=driver.findElements(By.xpath("//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr")).size();
	    	System.out.println(" rows in phantom" + rcount);
	    	Thread.sleep(2000);
	    	driver.switchTo().defaultContent();
	    	//Thread.sleep(3000);
	    	//go to auction schedule Menu
	    	
	    	
						
			
	    	VerintHomePageScreen.selectMenuItem(driver,"Request Management","Auction");
	    	
	    	Thread.sleep(3000);
	    	AuctionScreen.SelectAuction(driver,auctionName);
	    	Thread.sleep(5000);
	    	driver.switchTo().defaultContent();
	    	AuctionScreen.clickScheduleTab(driver);
	    	Thread.sleep(3000);
	    	AuctionScreen.clickSettingsTab(driver);
	    	Thread.sleep(3000);
	    	AuctionScreen.clickScheduleTab(driver);
	    	Thread.sleep(3000);
	    	
	    	Utilities.selectRightPaneView(driver);
	    	String name=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr//th[@id='workpaneListr0c0']//span//a")).getAttribute("innerText");
	    	System.out.println("phantom shift name is:" + name);
	    	if(name.contains(wpname))
	    	{
	    		extent.log(LogStatus.INFO,"phantom shift"+name+" exist" );
	    	}
	    	driver.switchTo().defaultContent();
	    	// Go to auction employee Menu to add them in auction
	    	AuctionScreen.clickEmpTab(driver);
	    	Thread.sleep(2000);
	    	Utilities.selectRightPaneView(driver);
	    	int rowscount=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr")).size();
	    	for(int i=0;i<=rowscount;i++)
	    	{
	    		String status=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr[contains(@id,'workpaneListr"+i+"')]//td[contains(@id,'workpaneListr"+i+"c1')]")).getText();
	    		System.out.println("status is:" + status);
	    		if(status.contains("Waiting"))
	    		{
	    			System.out.println("in if codition");
	    			AuctionScreen.clickAddtoAuction(driver);
	    			for(String winHandle :driver.getWindowHandles())
					{
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().contains("Add to Auction"))
		                {                	
		                	System.out.println("You are in Add to Auction window");
		                	driver.manage().window().maximize();
		                    break;
		                }	
					}
//			    	String windowName=Utilities.setWindowFocus(driver);
			    	Thread.sleep(1000);
			    	AuctionScreen.setDeadlline(driver, deadline);
			    	AuctionScreen.clickSaveAuction(driver);
			    	Thread.sleep(2000);
			    	driver.switchTo().window(mainwindow);
			    	Thread.sleep(2000);
			    	driver.switchTo().defaultContent();
			    	// go to bidding option tab and check the employees for bidding
			    	AuctionScreen.clickBidTab(driver);
			    	//AuctionScreen.SelectAuction(driver);
			    	AuctionScreen.SelectEmployee(driver, agentname);
			    	String ename=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr//th[@id='workpaneListr0c0']//a//span//span//a")).getAttribute("innerText");
			    	System.out.println("phantom shift name is:" + ename);
			    	if(ename.contains(wpname))
			    	{
			    		extent.log(LogStatus.INFO,"phantom shift"+ename+" exist" );
			    	}
			    	
			    	break;
	    		}
	    		else if(status.contains("0 Bids"))
	    		{
	    			System.out.println("in else if condition");
	    			driver.switchTo().defaultContent();
	    			AuctionScreen.clickBidTab(driver);
	    	    	//AuctionScreen.SelectAuction(driver);
	    	    	AuctionScreen.SelectEmployee(driver, EmpName);
	    	    	String ename=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr//th[@id='workpaneListr0c0']//a//span//span//a")).getAttribute("innerText");
			    	System.out.println("phantom shift name is:" + ename);
			    	if(ename.contains(wpname))
			    	{
			    		extent.log(LogStatus.INFO,"phantom shift"+ename+" exist" );
			    	}
	    	    	break;
	    		}
	    	}																							
	    	Utilities.logout(driver);
	    	Thread.sleep(3000);
	    	driver.findElement(By.id("username")).clear();
	    	LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
	    	LoginScreen.clickLogin(driver);
	    	driver.switchTo().defaultContent();
	    	VerintHomePageScreen.selectMenuItem(driver,"Request Management","Auction");
	    	
	    	Thread.sleep(3000);
	    	AuctionScreen.SelectAuction(driver,auctionName);
	    	Thread.sleep(5000);
	    	AuctionScreen.clickcloseauction(driver);
	    	AuctionScreen.clickdeleteauction(driver);
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\btndelete_ok.png");
	    	Thread.sleep(3000);
	    	driver.switchTo().defaultContent();
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
	    	Utilities.selectLeftTreeFrame(driver);
	    	CampaignSettings.CampaignExist(driver, campName);
	    	CampaignSettings.deleteCampaign(driver);
	    	Utilities.sikuliClick(driver,Utilities.PROPERTIES.getProperty("ImagesPath")+"\\btnok_camp.png");
	    	Thread.sleep(3000);
	    	
	    	
	    	
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	    finally{
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,8);
		}
	    return flag;
	}
}
