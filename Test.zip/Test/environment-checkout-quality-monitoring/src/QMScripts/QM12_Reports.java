package QMScripts;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;

import Utilities.Utilities;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

public class QM12_Reports {
	
	public static boolean QM12Reports() throws Exception {
		ExtentReports extent = ExtentReports.get(AccessRightsScreen.class);
		boolean flag=true;
		Screen sobj = new Screen ();
		String mainWinID="";
		
		String HTMLReportName="QM12_Reports" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Quality Monitoring - Reports");
		

		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		try {
			LoginScreen.launchVerint(driver, Utilities.PROPERTIES.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver, Utilities.getPassword(driver, 0, 1));
			LoginScreen.setTextInPassword(driver, Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			Thread.sleep(5000);
			VerintHomePageScreen.selectMenuItem(driver, "Interactions", "Quality Monitoring");
			Thread.sleep(5000);
			
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:" + windowIds.size());
			if (windowIds.size() ==1) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver, Utilities.PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver, Utilities.PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver, "Interactions", "Quality Monitoring");
				Thread.sleep(5000);
			}
			
			mainWinID = Utilities.setWindowFocus(driver);
			System.out.println(mainWinID);
			
			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\EvaluationFlag_OK.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\EvaluationFlag_OK.png");
			}

			Thread.sleep(15000);
			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QM_Reports.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QM_Reports.png");
			} else {
				extent.log(LogStatus.WARNING, "Not able to click on Reports. Please try again");
				return flag = false;
			}
			
			for (int r=1; r<=20; r++) {
				if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath")+"\\QM_Reports_PublicFolder.png") != null) {
					break;
				} else {
					Thread.sleep(4000);
				}
			}

			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QM_Reports_PublicFolder.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QM_Reports_PublicFolder.png");
				extent.log(LogStatus.PASS, "Public Folder selected successfully");
				Thread.sleep(5000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to select Public Folder. Please try again");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMReport"));
				return flag = false;
			}
			
			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath")+"\\QM_Reports_ReportsEnglish.png") != null) {
				extent.log(LogStatus.PASS, "Reports (English) item is selected");
				sobj.doubleClick(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QM_Reports_ReportsEnglish.png");
				Thread.sleep(5000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to select Reports (English) item. Please try again");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMReport"));
				return flag = false;
			}
			
			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath")+"\\QM_Reports_ActivityReports.png") != null) {
				extent.log(LogStatus.PASS, "Activity Report is selected");
				sobj.doubleClick(Utilities.PROPERTIES.getProperty("ImagesPath")+"\\QM_Reports_ActivityReports.png");
				Thread.sleep(5000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to select Activity Report. Please try again");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMReport"));
				return flag = false;
			}
			
			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QM_Reports_EvalActAgent.png") != null) {
				extent.log(LogStatus.PASS, "Evaluation Activity per Agent selected");
				sobj.doubleClick(Utilities.PROPERTIES.getProperty("ImagesPath")+"\\QM_Reports_EvalActAgent.png");
				Thread.sleep(8000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to select Evaluation Activity per Agent. Please try again");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMReport"));
				return flag=false;
			}

			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QM_Reports_GenerareReport.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QM_Reports_GenerareReport.png");
				extent.log(LogStatus.PASS, "QM Report: clicked on Generate Report button");
			} else {
				extent.log(LogStatus.WARNING, "QM Report: Not able to click on Generate Report button");
				return flag = false;
			}
			Thread.sleep(4000);
			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QM_Reports_GenerareReport.png") != null) {
				sobj.doubleClick(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QM_Reports_GenerareReport.png");
			}

			Thread.sleep(10000);
			boolean key = false;
			for (int g=1; g<=2; g++) {
				if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QM_EvalAct.png") != null) {
					key = true;
					break;
				}
				if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QMReports_Eval_Agent.png")!=null) {
					key = true;
					break;
				}
				if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QMReports_Eval_AgentBlue.png") != null) {
					key = true;
					break;
				}
				if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\QMReports_EvalAct_Agent.png") != null) {
					key = true;
					break;
				}
			}
			if (key == true) {
				extent.log(LogStatus.PASS, "QM Report: Evaluation Activity per Agent is displayed successfully");
				extent.log(LogStatus.PASS, "", "", screenshot());
			} else {
				extent.log(LogStatus.FAIL, "QM Report: Evaluation Activity per Agent is NOT displayed");
				extent.log(LogStatus.FAIL, "", "", screenshot());
				return flag = false;
			}
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag, "QM", HTMLReportName, 4, 7);
		}
		return flag;
	}

	public static String screenshot() throws Exception {
		Robot robot = new Robot(); 
        String format = "png";
        String fileName = Utilities.PROPERTIES.getProperty("ScreenShotPath") + "QMReport" + System.currentTimeMillis() + "." + format;
        Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
        BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
        ImageIO.write(screenFullImage, format, new File(fileName));
		return fileName;
	}
}
