package QMScripts;

import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;


import jxl.Sheet;
import jxl.Workbook;


import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;


import ScreenObjects.DataSourceScreen;

import Utilities.Utilities;

public class QM02_SFCTI_Login {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	
	public static boolean QM02_SFCTILogin() throws Exception {
		boolean flag = true;
		Screen sobj = new Screen ();
		String HTMLReportName = "QM02_SFCTI_Login" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "SFCTI Login");
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook workbook = Workbook.getWorkbook(fis);
	    Sheet worksheet = workbook.getSheet("QM_TestSet");
		
		try {
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Windows_Start.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Windows_Start.png");
				Thread.sleep(1000);
			} else {
				return flag = false;
			}

			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\SFCTI.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\SFCTI.png");
				Thread.sleep(3000);
			} else {
				return flag = false;
			}
			Thread.sleep(10000);
			java.lang.Runtime.getRuntime().exec("C:\\DEV\\SFCTI.exe");
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.verintScriptStatus(flag, "QM", HTMLReportName, 4, 9);
		}
		return flag;
	}
}
