package QMScripts;

import java.io.IOException;
import java.util.Properties;

import Utilities.Utilities;

public class readEmails {

	public static final Properties PROPERTIES = Utilities.PROPERTIES;

	public static void OutlookReadEmail() throws Exception {
		try {
            String deleteCookiesPath = PROPERTIES.getProperty("DeleteCookiesPath");
            String deleteCookiesCMD = "wscript " + deleteCookiesPath;
            Runtime.getRuntime().exec( deleteCookiesCMD );
	    } catch (IOException e) {
		    System.out.println(e);
		    System.exit(0);
	    }
	}
}