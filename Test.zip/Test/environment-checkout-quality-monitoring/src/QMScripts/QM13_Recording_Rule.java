package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.RuleSettingsScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

public class QM13_Recording_Rule {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	public static boolean QM13_RecordingRule() throws Exception {
		boolean flag = true;
		String HTMLReportName="QM13_Recording Rule" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Recording Rule");
		
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook wb = Workbook.getWorkbook(fis);
	    Sheet ws = wb.getSheet("QM_TestSet");
	    
	    String ruleName = ws.getCell(5, 2).getContents();
	   		
		try {
			LoginScreen.launchVerint(driver,Utilities.PROPERTIES.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			Thread.sleep(5000);		
			
			if (!VerintHomePageScreen.selectMenuItem(driver, "System Management", "RecordingRules Settings")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver, Utilities.PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver, Utilities.PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag = false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver, "System Management", "RecordingRules Settings")) {
					extent.log(LogStatus.WARNING, "Not able to select RecordingRules Settings menu. Please try again.");
					return flag = false;
				}
			}
			
			Utilities.selectLeftTreeFrame(driver);
			int valrcRule=driver.findElements(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr")).size();
			if (valrcRule > 0) {
				driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr[1]/td/div/nobr/a/span")).click();
				Thread.sleep(4000);
			}
			
			if (RuleSettingsScreen.verifyRule(driver, ruleName)) {
				extent.log(LogStatus.INFO, "Rule Name:" + ruleName + " already exist.");
				return flag = false;
			}
			
			Utilities.selectRightPaneView(driver);
			if (!RuleSettingsScreen.clickCreate(driver)) {
				return flag = false;
			}
			RuleSettingsScreen.setTextInRulename(driver, ruleName);
			RuleSettingsScreen.setTextInRuleDescription(driver, "Rule Description");
			if (!RuleSettingsScreen.clickRuleSave(driver)) {
				return flag = false;
			}
			if (!RuleSettingsScreen.clickYes(driver)) {
				return flag = false;
			}
			if (!RuleSettingsScreen.verifySuccessMessage(driver)) {
				return flag=false;
			}
			if (!RuleSettingsScreen.clickSchedulelnk(driver)) {
				return flag = false;
			}
			if (!RuleSettingsScreen.clickScheduleSave(driver)) {
				return flag = false;
			}
			if (!RuleSettingsScreen.verifySuccessMessage(driver)) {
				return flag = false;
			}
			if (!RuleSettingsScreen.clickSettinglnk(driver)) {
				return flag=false;
			}
			if (!RuleSettingsScreen.selectRule(driver, ruleName)) {
				return flag=false;
			}
			if (!RuleSettingsScreen.clickDelete(driver)) {
				return flag=false;
			}
			Utilities.sikuliClick(driver, Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Delete_OK.png");
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Thread.sleep(2000);			
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag, "QM", HTMLReportName, 4, 2);
		}
		
		return flag;
	}
}
