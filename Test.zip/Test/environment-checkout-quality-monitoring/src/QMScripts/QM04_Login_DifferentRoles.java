package QMScripts;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;
import ScreenObjects.CampaignSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QM04_Login_DifferentRoles {

	public static ExtentReports extent = ExtentReports.get(CampaignSettings.class);
	
	public static boolean QM04_Login_With_DifferentRoles() throws Exception {
		boolean flag = true;
		String HTMLReportName = "QM04_Login_With_DifferentRoles" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Login With Different Roles");
		
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());

		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		WebDriver driver = new InternetExplorerDriver(capabilities);
		
		try {
			if (!loginWithDifferentRoles(driver, Utilities.getPassword(driver, 0, 3), Utilities.getPassword(driver, 1, 3), "Evaluator")) {
				flag = false;
			}
			if (!loginWithDifferentRoles(driver, Utilities.getPassword(driver, 0, 4), Utilities.getPassword(driver, 1, 4), "Agent")) {
				flag = false;
			}
			
			if (!loginWithDifferentRoles(driver, Utilities.getPassword(driver, 0, 2), Utilities.getPassword(driver, 1, 2), "Supervisor")) {
				flag = false;
			}
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName, 4,6);
		}
		return flag;
	}
	
	public static boolean loginWithDifferentRoles(WebDriver driver, String userName, String password, String roleType) throws Exception {
		boolean temp = true;
		try {
			LoginScreen.launchVerint(driver, Utilities.PROPERTIES.getProperty("VerintURL"));
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return temp = false;
			}
			LoginScreen.setTextInUsername(driver, userName);
			LoginScreen.setTextInPassword(driver, password);
			LoginScreen.clickLogin(driver);
			Thread.sleep(4000);
			driver.switchTo().defaultContent();
			if (driver.findElements(By.id("utilityPanePC_LOGOUT_spn_id")).size() == 0) {
				extent.log(LogStatus.FAIL, "Login into Impact 360 with " + roleType + " role is unsuccessful");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
				return temp = false;
			}
			else {
				extent.log(LogStatus.PASS, "Login into Impact 360 with " + roleType + " role is Successful");
			}
			if (roleType == "Agent") {
				if (driver.findElements(By.linkText("My Home")).size() != 0 & driver.findElements(By.linkText("Interactions")).size() != 0) {
					extent.log(LogStatus.PASS, "My Home & Interactions tabs are displayed");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
				}
				else {
					extent.log(LogStatus.FAIL, "My Home & Interactions tabs are not displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
					temp = false;
				}
				if ( driver.findElements(By.linkText("System Management")).size() != 0 |
						driver.findElements(By.linkText("Organization Management")).size() != 0 |
                        driver.findElements(By.linkText("User Management")).size() != 0 |
                        driver.findElements(By.linkText("Forecasting and Scheduling")).size() != 0 |
                        driver.findElements(By.linkText("Tracking")).size() != 0 |
                        driver.findElements(By.linkText("Performance Management")).size() != 0 |
                        driver.findElements(By.linkText("eLearning")).size() != 0 |
                        driver.findElements(By.linkText("Coaching")).size() != 0 |
                        driver.findElements(By.linkText("Customer Feedback")).size() != 0 |
                        driver.findElements(By.linkText("Request Management")).size() != 0 |
                        driver.findElements(By.linkText("Reports")).size() != 0 |
                        driver.findElements(By.linkText("Analytics")).size() != 0) {
					extent.log(LogStatus.FAIL, "Apart from My Home & Interactions, other tabs were also displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
					temp = false;
				}
				else {
					extent.log(LogStatus.PASS, "Apart from My Home & Interactions, other tabs were NOT displayed");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
				}
			}
			if (roleType == "Evaluator") {
				if (driver.findElements(By.linkText("Interactions")).size() != 0) {
					extent.log(LogStatus.PASS, "Interactions tab is displayed");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
				}
				else {
					extent.log(LogStatus.FAIL, "Interactions tab is not displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
					temp = false;
				}
				if (driver.findElements(By.linkText("My Home")).size()!=0 || driver.findElements(By.linkText("System Management")).size()!=0 || driver.findElements(By.linkText("Organization Management")).size()!=0 || driver.findElements(By.linkText("User Management")).size()!=0 || driver.findElements(By.linkText("Forecasting and Scheduling")).size()!=0 || driver.findElements(By.linkText("Tracking")).size()!=0 || driver.findElements(By.linkText("Performance Management")).size()!=0 || driver.findElements(By.linkText("eLearning")).size()!=0 || driver.findElements(By.linkText("Coaching")).size()!=0 || driver.findElements(By.linkText("Customer Feedback")).size()!=0 || driver.findElements(By.linkText("Request Management")).size()!=0 || driver.findElements(By.linkText("Reports")).size()!=0 || driver.findElements(By.linkText("Analytics")).size()!=0) {
					extent.log(LogStatus.FAIL, "Apart from Interactions, other tabs were also displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
					temp = false;
				}
				else {
					extent.log(LogStatus.PASS, "Apart from Interactions, other tabs were NOT displayed");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
				}
			}
			if (roleType == "Supervisor") {
				if (driver.findElements(By.linkText("Interactions")).size()!=0) {
					extent.log(LogStatus.PASS, "Interactions tab is displayed");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
				}
				else {
					extent.log(LogStatus.FAIL, "Interactions tab is not displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
					temp = false;
				}
				
				if (driver.findElements(By.linkText("My Home")).size() != 0 ||
                        driver.findElements(By.linkText("System Management")).size() != 0 ||
                        driver.findElements(By.linkText("Organization Management")).size() != 0 ||
                        driver.findElements(By.linkText("User Management")).size() != 0 ||
                        driver.findElements(By.linkText("Forecasting and Scheduling")).size() != 0 ||
                        driver.findElements(By.linkText("Tracking")).size()!=0 ||
                        driver.findElements(By.linkText("Performance Management")).size() != 0 ||
                        driver.findElements(By.linkText("eLearning")).size() != 0 ||
                        driver.findElements(By.linkText("Coaching")).size() != 0 ||
                        driver.findElements(By.linkText("Customer Feedback")).size() != 0 ||
                        driver.findElements(By.linkText("Request Management")).size() != 0 ||
                        driver.findElements(By.linkText("Reports")).size() != 0 ||
                        driver.findElements(By.linkText("Analytics")).size() != 0) {
					extent.log(LogStatus.FAIL, "Apart from Interactions, other tabs were also displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
					temp = false;
				}
				else {
					extent.log(LogStatus.PASS, "Apart from Interactions, other tabs were NOT displayed");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Login_Roles"));
				}
			}
			Utilities.logout(driver);
		} catch(Exception e) {
			System.out.println(e);
		}
		return temp;
	}
}
