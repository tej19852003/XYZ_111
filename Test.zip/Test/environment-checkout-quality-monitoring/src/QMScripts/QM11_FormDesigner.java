package QMScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import Utilities.Utilities;

public class QM11_FormDesigner {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	
	public static boolean QM11_From_Designer() throws Exception {
		boolean flag = true;
		Screen sobj = new Screen ();
			
		String HTMLReportName="QM11_From_Designer" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Form Designer");
		
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook workbook = Workbook.getWorkbook(fis);
	    Sheet worksheet = workbook.getSheet("QM_TestSet");
		
		try {
			Process p = Runtime.getRuntime().exec("C:\\Program Files (x86)\\I360\\FormDesigner\\Verint.EvaluationPackage.FormManagement.FormManagementUI.exe");
			Thread.sleep(6000);
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Username.png") != null) {
				sobj.type(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Username.png",Utilities.getPassword(driver, 0, 1));
				Thread.sleep(1000);
			} else {
				return flag = false;
			}
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Password.png") != null) {
				sobj.type(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Password.png", Utilities.getPassword(driver, 1, 1));
				Thread.sleep(1000);
			} else {
				return flag = false;
			}
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Login.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Login.png");
				Thread.sleep(1000);
			} else {
				return flag = false;
			}
			Thread.sleep(30000);

			//New form icon
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath")+"\\FormDesigner_NewForm.png") != null) {
				extent.log(LogStatus.PASS, "Form Designer Page is displayed");				
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath")+"\\FormDesigner_NewForm.png");
				Thread.sleep(3000);
			} else {
				extent.log(LogStatus.FAIL, "Form Designer Page is NOT displayed");
				return flag = false;
			}

			//new form name
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_NewFormName.png") != null) {
				sobj.type(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_NewFormName.png",".AutomationForm");
				extent.log(LogStatus.PASS, "New Form Name: .AutomationForm entered successfully");	
				Thread.sleep(3000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to enter New Form Name: .AutomationForm");
				return flag = false;
			}
			//new form OK button
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_NewFormOK_button.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_NewFormOK_button.png");
				extent.log(LogStatus.PASS, "Clicked on OK button successful");
				Thread.sleep(3000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to click on OK button");
				return flag=false;
			}

			//check for form name already exist or not
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_OK.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_OK.png");
				extent.log(LogStatus.WARNING, "New Form - This name already exist is displayed");
				Thread.sleep(1000);
				return flag = false;
			}

			//new component icon - section
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_NewComponent.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_NewComponent.png");
				Thread.sleep(3000);
			} else {
				return flag = false;
			}

			//section1
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Section1.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Section1.png");
				Thread.sleep(3000);
			} else {
				return flag = false;
			}

			//section1 Name
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Section1_Name.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Section1_Name.png");
				sobj.type("a", KeyModifier.CTRL);  // select all text
				sobj.type(Key.BACKSPACE);  // delete selection
				sobj.type(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Section1_Name.png", ".AutomationSection");
				extent.log(LogStatus.PASS, "Section Name:.AutomationSection entered successfully");
				Thread.sleep(3000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to enter Section Name:.AutomationSection");
				return flag = false;
			}
			//section1 view - enable comment
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Section_View.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Section_View.png");
				extent.log(LogStatus.INFO, "Section View: Enable commnets selected");
				Thread.sleep(3000);
			} else {
				extent.log(LogStatus.WARNING, "Section View: Enable commnets NOT selected");
				//return flag=false;
			}

			//new component icon - category
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_NewComponent.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_NewComponent.png");
				Thread.sleep(3000);
			} else {
				return flag = false;
			}

			//select category1
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Category1.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Category1.png");
				Thread.sleep(3000);
			} else {
				return flag = false;
			}

			//category1 name
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Category1_Name.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Category1_Name.png");
				sobj.type("a", KeyModifier.CTRL);  //select all text
				sobj.type(Key.BACKSPACE);  //delete selection
				sobj.type(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Category1_Name.png", ".AutomationCategory");
				extent.log(LogStatus.PASS, "Category Name: .AutomationCategory entered successfully");
				Thread.sleep(3000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to enter Category Name: .AutomationCategory");
				return flag = false;
			}

			//category view - enable comment
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Section_View.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Section_View.png");
				Thread.sleep(3000);
			} else {
				return flag = false;
			}

			//new component icon - question
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_NewComponent.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_NewComponent.png");
				Thread.sleep(3000);
			} else {
				return flag = false;
			}

			//select Question1
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Question1.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Question1.png");
				Thread.sleep(3000);
			} else {
				return flag = false;
			}

			//question1 name
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Question1_Name.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Question1_Name.png");
				sobj.type("a", KeyModifier.CTRL);  //select all text
				sobj.type(Key.BACKSPACE);  //delete selection
				sobj.type(".AutomationQuestion");
				extent.log(LogStatus.PASS, "Question Name: .AutomationQuestion entered successfully");
				Thread.sleep(3000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to enter Question Name: .AutomationQuestion");
				return flag=false;
			}

			//Save
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Save.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Save.png");
				extent.log(LogStatus.PASS, "Clicked on Save button");
				Thread.sleep(3000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to click on Save button");
				return flag = false;
			}

			//Back to List
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_BackToList.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_BackToList.png");
				Thread.sleep(6000);
			} else {
				return flag = false;
			}

			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Delete.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Delete.png");
				extent.log(LogStatus.PASS, "Clicked on Delete button");
				Thread.sleep(3000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to click on Delete button");
				return flag = false;
			}

			//Delete AutomationForm Name - Yes
			if (sobj.exists( Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Delete_Yes.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\FormDesigner_Delete_Yes.png");
				Thread.sleep(3000);
			} else {
				return flag = false;
			}
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			String KILL = "taskkill /IM ";
		    String processName = "Verint.EvaluationPackage.FormManagement.FormManagementUI.exe";  //IE process
		    Runtime.getRuntime().exec(KILL + processName);			
		    Thread.sleep(3000);			
			Utilities.verintScriptStatus(flag, "QM", HTMLReportName, 4, 8);
		}
		return flag;
	}
}
