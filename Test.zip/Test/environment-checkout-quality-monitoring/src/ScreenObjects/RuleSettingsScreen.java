package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class RuleSettingsScreen {

	public static ExtentReports extent = ExtentReports.get(Impact360Screen.class);
	public static String btnCreate="//button[@id='toolbar_CREATE_RULELabel']";
	public static String txtRulename="ruleName";
	public static String txtRuledesc="ruleDescription";
	public static String btnRuleSave="toolbar_SAVE_RULELabel";
	public static String btnYes="toolbar_CREATE_RULE_YES_DIALOGLabel";
	public static String lnkSchedule="Schedule";
	public static String lnkCondition="Condition";
	public static String lnkSettings="Settings";
	public static String btnScheduleSave="toolbar_SAVE_RULE_SCHEDULELabel";
	public static String btnAdd="FREE_EXP_DYNAMIC_LIST_toolbar_ADD_ACTIONLabel";
	public static String imgSelectAttribute="//img[@id='freeExpAttributeID_0_IMGID_img_id']";
	public static String imgConditionValue="//img[@id='freeExpInputValue_0_IMGID'][@alt='Select']";
	public static String btnSet="//button[@id='workpaneMediator_toolbar_POPUP_JSFUNCTIONLabel']";
	public static String btnConditionSave="//button[@id='toolbar_SAVE_RULE_CONDITIONLabel']";
	public static String labelTxtMsg="//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[1]/div";
	public static String btnDelete="//button[@id='toolbar_DELETE_RULELabel']";

	public static boolean clickSettinglnk(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			driver.switchTo().defaultContent();
			By settingslnk = By.linkText(lnkSettings);
			Utilities.waitForPageLoad(driver, settingslnk);
			if (driver.findElements(settingslnk).size() != 0) {
				driver.findElement(settingslnk).click();
				extent.log(LogStatus.PASS, "Clicked on Settings link is successful");
				Thread.sleep(8000);
			} else {
				extent.log(LogStatus.INFO, "Clicked on Settings link is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickDelete(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By delbtn = By.xpath(btnDelete);
			Utilities.waitForPageLoad(driver,delbtn);
			if (driver.findElements(delbtn).size() != 0) {
				driver.findElement(delbtn).click();
				extent.log(LogStatus.PASS, "Clicked on Delete button is successful");
				Thread.sleep(6000);
			} else {
				extent.log(LogStatus.INFO, "Clicked on Delete button is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectRule(WebDriver driver, String ruleName) throws Exception {
		driver.switchTo().defaultContent();		
		Utilities.selectLeftTreeFrame(driver);
		Boolean temp = false;
		try {
			int valrcRule=driver.findElements(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr")).size();
			for (int i=1; i<=valrcRule; i++) {
				if (i <= 15) {
					String rulenameApp = driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr[" + i + "]/td/div/nobr/a/span")).getText().trim();
					if (rulenameApp.contains(ruleName)) {
						driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr[" + i + "]/td/div/nobr/a/span")).click();
						temp = true;
						break;
					}
				}
			}
			if (temp == true) {
				//System.out.println("pass");
				extent.log(LogStatus.PASS, "Name: " + ruleName + " Created/Selected successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));				
			} else {
				extent.log(LogStatus.FAIL, "Unable to Create/Select Ruler Name: " + ruleName);
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
				return temp =false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return temp;
	}
	
	public static boolean verifyRule(WebDriver driver, String ruleName) throws Exception {
		driver.switchTo().defaultContent();		
		Utilities.selectLeftTreeFrame(driver);
		Boolean temp=false;
		try {
			int valrcRule = driver.findElements(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr")).size();

			for (int i=1; i<=valrcRule; i++) {
				if (i <= 15) {
					String rulenameApp = driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr[" + i + "]/td/div/nobr/a/span")).getText().trim();
					if (rulenameApp.contains(ruleName)) {
						driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr[" + i + "]/td/div/nobr/a/span")).click();
						temp=true;
						break;
					}
				}
			}
			if (temp == true) {
				//System.out.println("pass");
				extent.log(LogStatus.INFO, "Name: " + ruleName + " already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));				
			} else {
				extent.log(LogStatus.INFO, "RuleName:" + ruleName + " does not exist. Please create.");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
				return temp =false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return temp;
	}
	
	public static boolean verifySuccessMessage(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			By messageTxt = By.xpath(labelTxtMsg);
			Thread.sleep(6000);
			if (driver.findElements(messageTxt).size() != 0) {
				String msg = driver.findElement(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[1]/div")).getText();
				if (msg.contains("Successfully")) {
					extent.log(LogStatus.PASS, "Message:" + msg + " is displayed");
					Thread.sleep(3000);
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
				} else {
					extent.log(LogStatus.FAIL, "Message:" + msg + " is displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
					return flag = false;
				}
			} else {
				extent.log(LogStatus.WARNING, "Success message is not displayed");
				return flag=false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean clickConditionSave(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By condSavebtn=By.xpath(btnConditionSave);
			Utilities.waitForPageLoad(driver,condSavebtn);
			if (driver.findElements(condSavebtn).size()!=0) {
				driver.findElement(condSavebtn).click();
				extent.log(LogStatus.PASS, "Clicked on Condition - Save button is successful");
				Thread.sleep(6000);
			} else {
				extent.log(LogStatus.INFO, "Clicked on Condition - Save button is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectConditionValue(WebDriver driver, String conditionValue) throws Exception {
		boolean flag = true;
		boolean temp = false;
		String mainWind = "";
		try {
			By condValImg = By.xpath(imgConditionValue);
			Utilities.waitForPageLoad(driver, condValImg);
			if (driver.findElements(condValImg).size() != 0) {
				driver.findElement(condValImg).click();
				extent.log(LogStatus.PASS, "Clicked on Condition Value Selection icon is successful");
				Thread.sleep(6000);
				mainWind=Utilities.setWindowFocus(driver);
				Thread.sleep(2000);
				if (driver.findElements(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr")).size() != 0) {
					int rcOrg=driver.findElements(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr")).size();
					for (int i=1; i<=rcOrg; i++) {
						String orgApp=driver.findElement(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr[" + i + "]/td[2]/label/span")).getText().trim();
						Thread.sleep(1000);
						if (orgApp.contains(conditionValue)) {
							driver.findElement(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr[" + i + "]/td[1]/span/input[@name='checkedOrgID'][@type='radio']")).click();
							temp = true;
							break;
						}
					}
					if (temp == true) {
						extent.log(LogStatus.PASS, "Condition Value : " + conditionValue+" Selected successfully");
						if (driver.findElements(By.xpath(btnSet)).size() != 0) {
							driver.findElement(By.xpath(btnSet)).click();
							Thread.sleep(3000);
							extent.log(LogStatus.INFO, "Clicked on Set button in Condition Value Selection popup window");
						}
						else {
							extent.log(LogStatus.WARNING, "Not able to Clicked on Set button in Condition Value Selection popup window");
							return flag=false;
						}
					}
					else {
						extent.log(LogStatus.FAIL, "Unable to Select Condition Value : "+conditionValue);
						return flag =false;
					}
				}
				else {
					extent.log(LogStatus.FAIL, "Condition Value Selection popup window is not displayed");
				}			
			} else {
				extent.log(LogStatus.FAIL, "Clicked on Condition Value Selection is un successful");
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		driver.switchTo().window(mainWind);
		return flag;
	}
	
	public static boolean selectAttribute(WebDriver driver, String attributeName) throws Exception {
		boolean flag = true;
		boolean temp = false;
		try {
			By attributeImg=By.xpath(imgSelectAttribute);
			Utilities.waitForPageLoad(driver, attributeImg);
			if (driver.findElements(attributeImg).size() != 0) {
				driver.findElement(attributeImg).click();
				extent.log(LogStatus.PASS, "Clicked on Add button is successful");
				Thread.sleep(2000);
				int rulerc=driver.findElements(By.xpath("//table[@id='AttributeTree_id']/tbody/tr")).size();
				for (int i=1; i<=rulerc; i++) {
					String attributName = driver.findElement(By.xpath("//table[@id='AttributeTree_id']/tbody/tr[" + i + "]/th/a/span")).getText().trim();
					Thread.sleep(1000);
					if (attributName.contains(attributeName)) {
						driver.findElement(By.xpath("//table[@id='AttributeTree_id']/tbody/tr[" + i + "]/th/a/span")).click();
						temp = true;
						break;
					}
				}
				if (temp == false) {
					return flag=false;
				}
			} else {
				extent.log(LogStatus.INFO, "Clicked on Select Attribute is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickAdd(WebDriver driver) throws Exception {
		boolean flag = true;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By addBtn = By.id(btnAdd);
			Utilities.waitForPageLoad(driver, addBtn);
			if (driver.findElements(addBtn).size() != 0) {
				driver.findElement(addBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Add button is successful");
				Thread.sleep(6000);
			} else {
				extent.log(LogStatus.INFO, "Clicked on Add button is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickConditionlnk(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			driver.switchTo().defaultContent();
			By conditionLink = By.linkText(lnkCondition);
			Utilities.waitForPageLoad(driver, conditionLink);
			if (driver.findElements(conditionLink).size() != 0) {
				driver.findElement(conditionLink).click();
				extent.log(LogStatus.PASS, "Clicked on Condition link is successful");
				Thread.sleep(15000);
			} else {
				extent.log(LogStatus.INFO, "Clicked on Condition link is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickScheduleSave(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By scheduleSaveBtn = By.id(btnScheduleSave);
			Utilities.waitForPageLoad(driver, scheduleSaveBtn);
			if (driver.findElements(scheduleSaveBtn).size() != 0) {
				driver.findElement(scheduleSaveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Schedule - Save button is successful");
				Thread.sleep(4000);
			} else {
				extent.log(LogStatus.INFO, "Clicked on Schedule Save button is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSchedulelnk(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			driver.switchTo().defaultContent();
			By scheduleLink = By.linkText(lnkSchedule);
			Utilities.waitForPageLoad(driver,scheduleLink);
			if (driver.findElements(scheduleLink).size() != 0) {
				driver.findElement(scheduleLink).click();
				extent.log(LogStatus.PASS, "Clicked on Schedule link is successful");
				Thread.sleep(8000);
			} else {
				driver.findElement(scheduleLink).click();
				extent.log(LogStatus.INFO, "Clicked on Schedule link is unsuccessful");
				flag=false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean clickYes(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			By yesBtn = By.id(btnYes);
			Utilities.waitForPageLoad(driver, yesBtn);
			if (driver.findElements(yesBtn).size() != 0) {
				driver.findElement(yesBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Yes button is successful");
				Thread.sleep(4000);
			} else {
				extent.log(LogStatus.INFO, "Yes button is not displayed");
				flag=false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void setTextInRuleDescription(WebDriver driver, String ruleDesc) throws Exception {
		try {
			By ruleDescTxt = By.name(txtRuledesc);
			Utilities.waitForPageLoad(driver, ruleDescTxt);
			if (driver.findElements(ruleDescTxt).size() != 0) {
				driver.findElement(ruleDescTxt).clear();
				driver.findElement(ruleDescTxt).sendKeys(ruleDesc);
				extent.log(LogStatus.PASS, "Rule Description: " + ruleDesc + " is entered successfully");
			} else {
				extent.log(LogStatus.FAIL, "Rule Description: " + ruleDesc + " is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void setTextInRulename(WebDriver driver, String ruleName) throws Exception {
		try {
			By ruleNameTxt = By.name(txtRulename);
			Utilities.waitForPageLoad(driver, ruleNameTxt);
			if (driver.findElements(ruleNameTxt).size() != 0) {
				driver.findElement(ruleNameTxt).clear();
				driver.findElement(ruleNameTxt).sendKeys(ruleName);
				extent.log(LogStatus.PASS, "Rule Name: " + ruleName + " is entered successfully");
			} else {
				extent.log(LogStatus.FAIL, "Rule Name: " + ruleName + " is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean clickRuleSave(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			By ruleSaveBtn = By.id(btnRuleSave);
			Utilities.waitForPageLoad(driver,ruleSaveBtn);
			if (driver.findElements(ruleSaveBtn).size() != 0) {
				driver.findElement(ruleSaveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Rule - Save button is successful");
				Thread.sleep(4000);
			} else {
				extent.log(LogStatus.FAIL, "Clicked on Rule - Save button is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCreate(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			By createBtn = By.xpath(btnCreate);
			Utilities.waitForPageLoad(driver, createBtn);
			if (driver.findElements(createBtn).size() != 0) {
				driver.findElement(createBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Rule Settings - Create button is successful");
				Thread.sleep(4000);
			} else {
				extent.log(LogStatus.FAIL, "Clicked onRule Settings - Create button is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
