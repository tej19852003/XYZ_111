package ScreenObjects;

import java.io.BufferedReader;
import java.io.FileReader;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;

import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ScreenContentTriggers {
	
	public static Screen sobj = new Screen ();
	public static ExtentReports extent = ExtentReports.get(ScreenContentTriggers.class);
	public static String txtUniqueName = "ctl00_MidPanelContentHolder_dockTriggerProperties_C_txtTriggerName";
	public static String txtDisplayName = "ctl00_MidPanelContentHolder_dockTriggerProperties_C_txtDisplayName";
	public static String txtAdditionalParameters = "ctl00_MidPanelContentHolder_dockTriggerProperties_C_txtAdditionalParameters";
	public static String lstCommandToExecute = "ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_Input";
	public static String txtEventCode = "ctl00_MidPanelContentHolder_dockTriggerProperties_C_txtEventCode";
	public static String txtUserGroup = "ctl00_MidPanelContentHolder_dockTriggerProperties_C_cbUserGroups_Input";
	public static String txtComputerGroup = "ctl00_MidPanelContentHolder_dockTriggerProperties_C_cbComputerGroups_Input";
	public static String txtWindowBehaviourcriteria = "ctl00_MidPanelContentHolder_dockTriggerProperties_C_dlWindowOpenEvents";
	public static String labelSelectedCriteria = "//div[@id='ctl00_MidPanelContentHolder_dockSelectedCriteria']/table/tbody/tr/td[2]/div[@id='ctl00_MidPanelContentHolder_dockSelectedCriteria_T']";
	public static String btnAddNewScreen = "//input[@id='ctl00_MidPanelContentHolder_btnAddScreen']";
	public static String lstDPAValidatorVersion = "//input[@id='dlVersion_Input']";
	public static String btnGo = "btnGo";
	public static String lstFind = "//input[@id='ctl00_MidPanelContentHolder_lstTriggerNameSearch_lstSearchBy_Input']";
	public static String btnSearch = "ctl00_MidPanelContentHolder_lstTriggerNameSearch_btnSearch";
	public static String txtSearchName = "//input[@id='ctl00_MidPanelContentHolder_lstTriggerNameSearch_lstSearch_Input']";
	public static String btnSave="ctl00_MidPanelContentHolder_btnSave";
	public static String txtCriteriaValue = "ctl00_MidPanelContentHolder_dockSelectedCriteria_C_rptItems_ctl01_criteria_txtValue";
	public static String chkHighlight = "//input[@id='ctl00_MidPanelContentHolder_dockSelectedCriteria_C_rptItems_ctl01_criteria_cbHighlight'][@type='checkbox']";
	public static String btnActivateChanges = "ctl00_MidPanelContentHolder_btnActivateChanges";
	public static String labelTriggerVersion = "//span[@id='ctl00_MidPanelContentHolder_lblTriggerVersion']";


	public static boolean setAdditionalParameters(WebDriver driver, String additionalParameters) {
		boolean flag = false;
		try {
			By addParamTxt = By.id(txtAdditionalParameters);
			Utilities.waitForPageLoad(driver, addParamTxt);
			if (driver.findElements(addParamTxt).size() != 0) {
				driver.findElement(addParamTxt).clear();
				driver.findElement(addParamTxt).sendKeys(additionalParameters);
				Thread.sleep(2000);
					extent.log(LogStatus.PASS, "Additional Parameters: " + additionalParameters + " is entered successfully");
					flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Additional Parameters: " + additionalParameters + " is NOT entered");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean deleteTrigger(WebDriver driver, String screenName) throws Exception {
		Boolean flag = false;
		try {
			int rcTrigger = driver.findElements(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr")).size();
			System.out.println("rcTrigger:" + rcTrigger);
			if (rcTrigger > 0) {
				for (int j=1; j<=rcTrigger; j++) {
					String screenNameApp = driver.findElement(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr[1]/td[2]")).getText().trim();
					System.out.println("ScreenNameApp:" + screenNameApp);
					System.out.println("ScreenNameApp:" + screenName);
					if (screenNameApp.contains(screenName)) {
						System.out.println("match");
						if (driver.findElements(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr[1]/td[8]/input[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00_ctl04_gbcbtnDelete']")).size()!=0) {
							driver.findElement(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr[1]/td[8]/input[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00_ctl04_gbcbtnDelete']")).click();
							if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Delete_OK.png")!=null) {
								sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Delete_OK.png");
								flag = true;
							}
						}
						Thread.sleep(3000);						
						break;
					}
				}
				if (flag==true) {
					System.out.println("deletetrigger - pass");
					extent.log(LogStatus.PASS, "Trigger/Screen Name:" + screenName + " deleted Successfully");
					flag = true;
				}
				else {
					extent.log(LogStatus.INFO, "No Records were displayed/Not able to delete Trigger/Screen Name:" + screenName);
					flag = false;
				}
			}
			else {
				extent.log(LogStatus.FAIL, "Trigger is not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean clickActivateChanges(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			By actChangesBtn = By.id(btnActivateChanges);
			Utilities.waitForPageLoad(driver ,actChangesBtn);
			if (driver.findElements(actChangesBtn).size() != 0) {
				driver.findElement(actChangesBtn).click();
				System.out.println("inside activate changes");
				extent.log(LogStatus.INFO, "Clicked on Activate Changes is successful");
				Thread.sleep(3000);
				flag=true;
			} else {
				System.out.println("not inside activatechanges");
				extent.log(LogStatus.FAIL, "Clicked on Activate Changes is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectHighlight(WebDriver driver) {
		boolean flag = false;
		try {
			By highlightCheckbox = By.xpath(chkHighlight);
			Utilities.waitForPageLoad(driver, highlightCheckbox);
			if (driver.findElements(highlightCheckbox).size() != 0) {
				Thread.sleep(2000);
				driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ctl00_MidPanelContentHolder_dockSelectedCriteria_C_rptItemsPanel']/table/tbody/tr[1]/td[6]/span/input[@name='ctl00$MidPanelContentHolder$dockSelectedCriteria$C$rptItems$ctl01$criteria$cbHighlight'][@type='checkbox']")).click();
				Thread.sleep(2000);
				extent.log(LogStatus.PASS, "Highlight checkbox is selected successfully");
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Not able to select Highlight checkbox");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean setCriteriaValue(WebDriver driver, String criteriaValue) {
		boolean flag = false;
		try {
			By valueText = By.id(txtCriteriaValue);
			Utilities.waitForPageLoad(driver, valueText);
			if (driver.findElements(valueText).size() != 0) {
				driver.findElement(valueText).sendKeys(criteriaValue);
				Thread.sleep(2000);
					extent.log(LogStatus.PASS, "Criteria Value: " + criteriaValue + " is entered successfully");
					flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Criteria Value: " + criteriaValue + " is NOT entered");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static void clickSave(WebDriver driver) throws Exception {
		try {
			By saveBtn = By.id(btnSave);
			Utilities.waitForPageLoad(driver, saveBtn);
			if (driver.findElements(saveBtn).size() != 0) {
				driver.findElement(saveBtn).click();
				System.out.println("inside save");
				extent.log(LogStatus.INFO, "Clicked on Save is successful");
				Thread.sleep(3000);
			} else {
				System.out.println("not inside search");
				extent.log(LogStatus.FAIL, "Clicked on Save is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean selectCommandToExecute(WebDriver driver, String command) throws Exception {
		boolean flag = false;
		try {
			By commandList = By.id(lstCommandToExecute);
			Utilities.waitForPageLoad(driver, commandList);
			if (driver.findElements(commandList).size() != 0) {
				System.out.println("inside command dropdown");
				driver.findElement(commandList).click();
				Thread.sleep(2000);				
				int rcCommand = driver.findElements(By.xpath("//div[@id='ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_DropDown']/div/ul/li")).size();
				for (int c=1; c<=rcCommand; c++) {
					WebElement list = driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_DropDown']/div/ul/li[" + c + "]"));
					if (list.getText().trim().contains(command)) {
						System.out.println("list item:"+list.getText());
						list.click();
						Thread.sleep(3000);
						break;
					}
				}
			} else {
				extent.log(LogStatus.FAIL, "Not able to select "+command+ " from Find dropdown");
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setDisplayName(WebDriver driver, String displayName) {
		boolean flag = false;
		try {
			By dispText = By.id(txtDisplayName);
			Utilities.waitForPageLoad(driver, dispText);
			if (driver.findElements(dispText).size() != 0) {
				driver.findElement(dispText).clear();
				driver.findElement(dispText).sendKeys(displayName);
				Thread.sleep(2000);
                extent.log(LogStatus.PASS, "Display Name: " + displayName + " is entered successfully");
                flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Display Name: " + displayName + " is NOT entered");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean setUniqueName(WebDriver driver,String uniqueName) {
		boolean flag = false;
		try {
			By uniqueText = By.id(txtUniqueName);
			Utilities.waitForPageLoad(driver,uniqueText);
			if (driver.findElements(uniqueText).size() != 0) {
				driver.findElement(uniqueText).clear();
				driver.findElement(uniqueText).sendKeys(uniqueName);
				Thread.sleep(2000);
                extent.log(LogStatus.PASS, "Unique Name: " + uniqueName + " is entered successfully");
                flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Unique Name: " + uniqueName + " is NOT entered");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCapturedTrigger(WebDriver driver, String screenName) throws Exception {
		Boolean temp = false;
		String screenNameApp = "";
		try {
			int rcTrigger = driver.findElements(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr")).size();
			System.out.println("rcTrigger:" + rcTrigger);
			if (rcTrigger>0) {
				for (int j=1; j<=rcTrigger; j++) {
					screenNameApp=driver.findElement(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr[1]/td[2]")).getText().trim();
					System.out.println("screenNameApp:" + screenNameApp);
					System.out.println("screenName:" + screenName);
					
					if (screenNameApp.contains(screenName)) {
						System.out.println("match");
						extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Trigger"));
						driver.findElement(By.xpath("//input[@title='Add New Trigger']")).click();
						temp = true;
						break;
					}
				}
				if (temp == true) {
					System.out.println("click trigger - pass");
					extent.log(LogStatus.PASS, "Clicked on Captured Trigger is Successful");
				}
				else {
					extent.log(LogStatus.FAIL, "Not able to click on Captured Trigger." + screenNameApp + " is displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
					return temp = false;
				}
			} else {
				extent.log(LogStatus.FAIL, "Trigger is not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return temp;
	}
	
	public static boolean setSearchByName(WebDriver driver, String uniqueName) {
		Boolean flag = false;
		try {
			By searchNameTxt = By.xpath(txtSearchName);
			Utilities.waitForPageLoad(driver, searchNameTxt);
			if (driver.findElements(searchNameTxt).size() != 0) {
				driver.findElement(searchNameTxt).clear();
				driver.findElement(searchNameTxt).sendKeys(uniqueName);
				Thread.sleep(2000);
				extent.log(LogStatus.PASS, "Search Name: "+uniqueName +" is entered successfully");
				flag=true;
			} else {
				extent.log(LogStatus.FAIL, "Search Name: "+uniqueName +" is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSearch(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			By searchBtn=By.id(btnSearch);
			Utilities.waitForPageLoad(driver,searchBtn);
			if (driver.findElements(searchBtn).size() != 0) {
				driver.findElement(searchBtn).click();
				System.out.println("inside search");
				extent.log(LogStatus.INFO, "Clicked on Search is successful");
				Thread.sleep(3000);
				flag=true;
			} else {
				System.out.println("not inside search");
				extent.log(LogStatus.FAIL, "Clicked on Search is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean selectFind(WebDriver driver, String name) throws Exception {
		boolean flag = false;
		try {
			By findList = By.xpath(lstFind);
			Utilities.waitForPageLoad(driver, findList);
			if (driver.findElements(findList).size()!=0) {
				System.out.println("inside Find dropdown");
				driver.findElement(findList).click();
				Thread.sleep(2000);
				if (name.contains("Screen Name")) {
					driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_lstTriggerNameSearch_lstSearchBy_DropDown']/div/ul/li[3]")).click();
					extent.log(LogStatus.INFO, name + " selected from Find dropdown");
					Thread.sleep(1000);
					flag = true;
				} else {
					extent.log(LogStatus.INFO, " Please select Screen Name and try again");
					return flag = false;
				}
			} else {
				extent.log(LogStatus.FAIL, "Not able to select " + name + " from Find dropdown");
				flag = false;
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static void selectDPAValidatorVersion(WebDriver driver, String version) throws Exception {
		try {
			WebElement validator = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.name("winAddScreen")));
			driver.switchTo().frame(validator);
			By lstVersion = By.xpath(lstDPAValidatorVersion);
			Utilities.waitForPageLoad(driver, lstVersion);
			if (driver.findElements(lstVersion).size() != 0) {
				driver.findElement(lstVersion).click();
				Thread.sleep(2000);
				if (version.contains("32 bit")) {
					driver.findElement(By.xpath("//div[@id='dlVersion_DropDown']/div/ul/li[1]")).click();
				} else if (version.contains("64 bit")) {
					driver.findElement(By.xpath("//div[@id='dlVersion_DropDown']/div/ul/li[2]")).click();
				}
				extent.log(LogStatus.INFO, version + " selected from DPA Validator Version dropdown");
				Thread.sleep(1000);
			} else {
				extent.log(LogStatus.FAIL, "Not able to select " + version + " selected from DPA Validator Version dropdown");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void clickAddNewScreen(WebDriver driver) throws Exception {
		try{
			By addNewScreenBtn = By.xpath(btnAddNewScreen);
			Utilities.waitForPageLoad(driver, addNewScreenBtn);
			if (driver.findElements(addNewScreenBtn).size() != 0) {
				driver.findElement(addNewScreenBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Add New Screen button is successful");
				Thread.sleep(8000);
			} else {
				extent.log(LogStatus.FAIL, "Clicked on Add New Screen button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static String filePathTriggerVersion(WebDriver driver, String path) throws Exception {
		String versionDef = "";
		try {
			FileReader FR = new FileReader(path);
			BufferedReader BR = new BufferedReader(FR);
			String Content = "";
			while ((Content = BR.readLine())!= null) {
				System.out.println("line:" + Content);
				String[] defVersion = Content.split(" ");
				versionDef = defVersion[1].trim();
				System.out.println("def file version:" + versionDef);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return versionDef;
	}
	
	public static String checkTriggerVersion(WebDriver driver) throws Exception {
		String versionNum = "";
		By triggerVersionLabel = By.xpath(labelTriggerVersion);
		Utilities.waitForPageLoad(driver, triggerVersionLabel);
		if (driver.findElements(By.id("ctl00_MidPanelContentHolder_btnActivateChanges")).size() != 0) {
			driver.findElement(By.id("ctl00_MidPanelContentHolder_btnActivateChanges")).click();
			Thread.sleep(3000);
		}
		if (driver.findElements(triggerVersionLabel).size() != 0) {
			String triggerVersion=driver.findElement(triggerVersionLabel).getText();
			String[] version=triggerVersion.split(":");
			if (version.length > 0) {
				versionNum = version[1].trim();
				extent.log(LogStatus.PASS, "Trigger Version:" + versionNum + " is displayed");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				System.out.println("App version:" + versionNum);
			}
		} else {
			extent.log(LogStatus.FAIL, "Trigger Version is not displayed");
		}
		return versionNum;
	}
	
	public static void verifyScreenContentTriggerProperties(WebDriver driver) throws Exception {
		Thread.sleep(5000);
		if (driver.findElements(By.id(txtUniqueName)).size() != 0) {
			extent.log(LogStatus.PASS, "Trigger Properties : Unique Name is displayed as Expected");			
		} else {
			extent.log(LogStatus.FAIL, "Trigger Properties : Unique Name is NOT displayed as Expected");
		}
		Thread.sleep(2000);
		if (driver.findElements(By.id(txtDisplayName)).size() != 0) {
			extent.log(LogStatus.PASS, "Trigger Properties : Display Name is displayed as Expected");			
		} else {
			extent.log(LogStatus.FAIL, "Trigger Properties : Display Name is NOT displayed as Expected");
		}
		Thread.sleep(2000);
		if (driver.findElements(By.id(txtEventCode)).size() != 0) {
			extent.log(LogStatus.PASS, "Trigger Properties : Event Code is displayed as Expected");			
		} else {
			extent.log(LogStatus.FAIL, "Trigger Properties : Event Code is NOT displayed as Expected");
		}
		Thread.sleep(2000);
		if (driver.findElements(By.id(txtAdditionalParameters)).size() != 0) {
			extent.log(LogStatus.PASS, "Trigger Properties : Additional Parameters is displayed as Expected");			
		} else {
            extent.log(LogStatus.FAIL, "Trigger Properties : Additional Parameters is NOT displayed as Expected");
        }
		Thread.sleep(2000);
		String criteria=driver.findElement(By.xpath(labelSelectedCriteria)).getText();
		if (criteria.contains("Selected Criteria")) {
			extent.log(LogStatus.PASS, "Selected Criteria is displayed as Expected");			
		}
		else {
			extent.log(LogStatus.FAIL, "Selected Criteria is NOT displayed as Expected");
		}
	}

	public static void clickGo(WebDriver driver) throws Exception {
		try {
			Thread.sleep(10000);
			By goBtn=By.id(btnGo);
			Utilities.waitForPageLoad(driver,goBtn);
			if (driver.findElements(goBtn).size()!=0) {
				driver.findElement(goBtn).click();
				System.out.println("inside go");
				extent.log(LogStatus.INFO, "Clicked on Go button is successful");
				Thread.sleep(3000);
			} else {
				System.out.println("not inside go");
				extent.log(LogStatus.FAIL, "Clicked on Go button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
