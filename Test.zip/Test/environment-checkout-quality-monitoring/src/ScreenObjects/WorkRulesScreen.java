package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import com.thoughtworks.selenium.webdriven.commands.GetText;

public class WorkRulesScreen {
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String txtfindEmployee = "peopleFilter_find";
	public static String btnAdd = "workPatternToolbar_POPUP_WORKPATTERNLabel";
	public static String btnSave = "toolbar_SAVE_ACTIONLabel";
	
	
	public static boolean findEmployee(WebDriver driver, String employeeName) {
		boolean flag = false;
		try {
			Utilities.selectLeftTreeFrame(driver);
			By txtName = By.name(txtfindEmployee);
			Utilities.waitForPageLoad(driver, txtName);
			if (driver.findElements(txtName).size() != 0) {
				driver.findElement(txtName).clear();
				driver.findElement(txtName).sendKeys(employeeName,Keys.ENTER);
				flag = true;
				extent.log(LogStatus.PASS,employeeName +" is entered sucessfully");
			} else {
				extent.log(LogStatus.FAIL,employeeName + "is not searched");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectEmployee(WebDriver driver, String employeeName) throws Exception {
		boolean flag = false;
		Utilities.selectLeftTreeFrame(driver);
		int numRows = driver.findElements(By.xpath("//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr")).size();
		System.out.println("no of rows are:" + numRows);
		for (int i=1; i<numRows; i++) {
			String empname=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr[" + i + "]//td//div//nobr//a")).getText();
			System.out.println("emp name is:" + empname );
			if (empname.contains(employeeName)) {
				driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr[" + i + "]//td//div//nobr//a")).click();
				Thread.sleep(2000);
				break;
			}
			flag = true;
		}
		if(flag==true) {
			extent.log(LogStatus.PASS, employeeName + "is selected sucessfully");
		}
		else {
			extent.log(LogStatus.FAIL, employeeName + " does not exist");
			return flag = false;
		}
		return flag;
	}
	
	public static boolean clickAdd(WebDriver driver) {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By btnAddwp = By.id(btnAdd);
			Utilities.waitForPageLoad(driver, btnAddwp);
			if (driver.findElements(btnAddwp).size() != 0) {
				driver.findElement(btnAddwp).click();
				extent.log(LogStatus.PASS, "clicked on Add work pattern is sucessfull");
				Thread.sleep(6000);
				flag = true;
			}
			else {
				extent.log(LogStatus.FAIL, "clicked on add work pattren is not sucessfull");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean clickSave(WebDriver driver) {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By saveBtn = By.id(btnSave);
			Utilities.waitForPageLoad(driver, saveBtn);
			if (driver.findElements(saveBtn).size() != 0) {
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS,"clicked on save button is sucessfull");
				flag = true;
			} else {
				extent.log(LogStatus.FAIL,"clicked on save button is not sucessfull");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static  boolean clickAddWorkPattern(WebDriver driver, String workPatternName) {
		boolean flag = false;
		try {
			driver.findElement(By.name("itemToFind")).sendKeys(workPatternName);
	    	driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_FIND_ACTIONLabel']")).click();
	    	Thread.sleep(2000);
	    	List<WebElement> list = driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']"));
			System.out.println(list.size());
			for (WebElement elt:list) {
				System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
				String wname = elt.findElement(By.tagName("td")).getAttribute("innerText");
				if (wname.contains(workPatternName)) {
					elt.findElement(By.tagName("td")).click();
					flag = true;
					break;
				}
			}
			driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addWorkPatternsLabel']")).click();
			flag = true;
		} catch(Exception e) {
			e.printStackTrace();
		} return flag;
	}
	
	public static boolean setHours(WebDriver driver) {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			driver.findElement(By.name("hoursPC__minPaid__input")).sendKeys("8");
			driver.findElement(By.name("hoursPC__maxPaid__input")).sendKeys("40");
			driver.findElement(By.name("hoursPC__otPerDay__input")).sendKeys("4");
			driver.findElement(By.name("hoursPC__otPerWeek__input")).sendKeys("20");
			flag = true;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean workPatternExist(WebDriver driver, String name) throws Exception {
		Utilities.selectRightPaneView(driver);
		boolean temp = false;
		
    	List<WebElement> li = driver.findElements(By.xpath("//table[@id='workPatternTableRef']//tr[@class='tblRow']"));
    	System.out.println("++++" + li.size());
    	if (driver.findElements(By.xpath("//table[@id='workPatternTableRef']//tr[@class='tblRow']//th")).size() != 0) {
    		for(WebElement elt:li) {
        		System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
        		String name2 = elt.findElement(By.tagName("th")).getAttribute("innerText");
        		if (name2.contains(name)) {
        			System.out.println("work pattern name is" + name2);
        			temp=true;
        			break;
        		}
        	}
    	} else {
    		temp = false;
    	}
    	return temp;
	}
}
