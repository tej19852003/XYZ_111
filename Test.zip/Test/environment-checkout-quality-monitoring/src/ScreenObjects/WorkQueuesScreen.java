package ScreenObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WorkQueuesScreen {
	
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String btnCreateworkqueue = "//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtqueueName = "queueName";
	public static String txtqueueDesc = "queueDescription";
	public static String iconlstMedia = "//span[@id='mediaId_0Wrapper']/nobr/img[@id='mediaId_0Button']";
	public static String btnSaveworkqueue = "//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	public static String btnEditworkqueue = "//button[@id='toolbar_EDIT_ACTIONLabel']";
	public static String iconlstAvailableDSG = "//span[@id='datasourceID_0Wrapper']/nobr/img[@id='datasourceID_0Button']";
	public static String btnAssignRight = "//button[@id='workpaneMediator_assignmentbox_tb_ASSIGN_RIGHTLabel']";
	public static String btnSaveMapping = "//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	public static String btnDeleteworkqueue = "//button[@id='toolbar_DELETE_ACTIONLabel']";
	
	public static boolean clickDeleteworkqueue(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By delBtn=By.xpath(btnDeleteworkqueue);
			Utilities.waitForPageLoad(driver, delBtn);
			if (driver.findElements(delBtn).size() != 0) {
				driver.findElement(delBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Delete work queue button is successful");
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Delete_OK.png");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Clicked on Delete work queue button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean validateDSGMapping(WebDriver driver, String workQueueName, String dataSourceGroupName) throws Exception {
		Boolean flag = false;
		try {
			int valrcWq=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("valrcPriv:" + valrcWq);
			for (int j=1; j<=valrcWq; j++) {
				if (j<=15) {
					String workQueueNameApp = driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr[" + j + "]/th/a/span")).getText().trim();
					System.out.println("WqnameAppApp:" + workQueueNameApp);
					System.out.println("WqnameAppCreated:" + workQueueName);
					Thread.sleep(1000);
					if (workQueueNameApp.contains(workQueueName)) {
						String dsgMapping=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr[" + j + "]/td[5]")).getText().trim();
						System.out.println("dsgMapping:"+dsgMapping);
						if (dsgMapping.contains(dataSourceGroupName)) {
							driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr[" + j + "]/td[5]")).click();
							flag = true;
						}
						break;
					}
				}
			}
			if (flag==true) {
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Data Source Group Name: " + dataSourceGroupName + " mapped successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "DataSourceGroup"));				
			} else {
				extent.log(LogStatus.FAIL, "Mapping of Data Source Group Name: " + dataSourceGroupName + " is NOT successful");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "DataSourceGroup"));
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSaveMapping(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By saveMappingBtn=By.xpath(btnSaveMapping);
			Utilities.waitForPageLoad(driver,saveMappingBtn);
			if (driver.findElements(saveMappingBtn).size()!=0) {
				driver.findElement(saveMappingBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save Mapping button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.INFO, "Clicked on Save Mapping button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean selectMappedDSG(WebDriver driver,String dataSourceGroup) throws Exception {
		Boolean flag = false;
		try {
			int dsgMaprc=driver.findElements(By.xpath("//table[@id='workpaneMediator_assignmentbox_dstRef']/tbody/tr")).size();
			System.out.println("dsgMaprc:" + dsgMaprc);
			for (int i=1; i<=dsgMaprc; i++) {
				String dsgApp=driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_dstRef']/tbody/tr[" + i + "]/th/a/span")).getText().trim();
				System.out.println("WqnameAppApp:"+dsgApp);
				System.out.println("DataSourceGroup:" + dataSourceGroup);

				Thread.sleep(1000);
				if (dsgApp.contains(dataSourceGroup)) {
					driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_dstRef']/tbody/tr[" + i + "]/th/a/span")).click();
					flag = true;
					break;
				}
			}
			if (flag==true) {
				System.out.println("pass");
				extent.log(LogStatus.PASS, " Mapped Data Source Group: " + dataSourceGroup + " created/selected successfully");
			}
			else {
				extent.log(LogStatus.INFO, "Mapped Data Source Group: " + dataSourceGroup + " does not exist");
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickAssignRight(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By assignrtBtn = By.xpath(btnAssignRight);
			Utilities.waitForPageLoad(driver, assignrtBtn);
			if (driver.findElements(assignrtBtn).size() != 0) {
				driver.findElement(assignrtBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Assign Right button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.INFO, "Clicked on Assign Right button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectDSGMapped(WebDriver driver, String DataSourceGroup) throws Exception {
		Boolean flag = false;
		try {
			int dsgMaprc = driver.findElements(By.xpath("//table[@id='workpaneMediator_assignmentbox_srcRef']/tbody/tr")).size();
			System.out.println("dsgMaprc:" + dsgMaprc);
			for (int i=1; i<=dsgMaprc; i++) {
				String dsgApp=driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_srcRef']/tbody/tr[" + i + "]/th/a/span")).getText().trim();
				System.out.println("WqnameAppApp:" + dsgApp);
				System.out.println("DataSourceGroup:" + DataSourceGroup);
				String mapped = driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_srcRef']/tbody/tr[" + i + "]/td")).getText().trim();
				System.out.println("mapped:" + mapped);
				Thread.sleep(1000);
				if (dsgApp.contains(DataSourceGroup) & (mapped != "Mapped")) {
					driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_srcRef']/tbody/tr[" + i + "]/th/a/span")).click();
					flag = true;
					break;
				}
			}
			if (flag==true) {
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Data Source Group: " + DataSourceGroup + " created/selected successfully");
			} else {
				extent.log(LogStatus.WARNING, "Data Source Group: " + DataSourceGroup + " does not exist OR already mapped");
				return flag =false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectItemAvailableDSG(WebDriver driver, String Option) throws Exception {
		boolean flag = false;
		try {
			Thread.sleep(3000);
			By lstDSG=By.xpath(iconlstAvailableDSG);
			Utilities.waitForPageLoad(driver, lstDSG);
			if (driver.findElements(lstDSG).size() != 0) {
				driver.findElement(lstDSG).click();
				Thread.sleep(2000);
				driver.findElement(lstDSG).sendKeys(Option);
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				extent.log(LogStatus.INFO, "Work queue Media:" + Option + " is selected");
				flag = true;
				Thread.sleep(4000);
			} else {
				extent.log(LogStatus.FAIL, "Work queue Media:"+Option+ " is Unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickEditworkqueue(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By editwqBtn = By.xpath(btnEditworkqueue);
			Utilities.waitForPageLoad(driver, editwqBtn);
			if (driver.findElements(editwqBtn).size() != 0) {
				driver.findElement(editwqBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Edit work queu button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.INFO, "Clicked on Edit work queue button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectWorkqueue(WebDriver driver, String workQueueName) throws Exception {
		Boolean flag = false;
		try {
			int valrcWq=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("valrcPriv:" + valrcWq);
			for (int i=1; i<=valrcWq; i++) {
				if (i<=15) {
                    String workQueueNameApp = driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr[" + i + "]/th/a/span")).getText().trim();
                    System.out.println("WqnameAppApp:" + workQueueNameApp);
                    System.out.println("WqnameAppCreated:" + workQueueName);
                    Thread.sleep(3000);
                    if (workQueueNameApp.contains(workQueueName)) {
                        driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr[" + i + "]/th")).click();
                        flag = true;
                        break;
                    }
				}
			}
			if (flag==true) {
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Work queue Name: " + workQueueName + " created/selected successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Workqueue"));				
			}
			else {
				extent.log(LogStatus.INFO, "Work queue Name: " + workQueueName+ " does not exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Workqueue"));
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By saveBtn = By.xpath(btnSaveworkqueue);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size() != 0) {					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setWorkqueueDescription(WebDriver driver, String workQueueDesc) throws Exception {
		boolean flag = false;
		try {		
			By workQueueDescriptionTxt = By.id(txtqueueDesc);
			Utilities.waitForPageLoad(driver, workQueueDescriptionTxt);
			if (driver.findElements(workQueueDescriptionTxt).size() != 0) {
				driver.findElement(workQueueDescriptionTxt).clear();
				driver.findElement(workQueueDescriptionTxt).sendKeys(workQueueDesc);
				extent.log(LogStatus.PASS, "Work queue Description : " + workQueueDesc + " is entered successfully");	
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Work queue Description : "+workQueueDesc +" is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setWorkqueueName(WebDriver driver, String workqueueName) throws Exception {
		boolean flag = false;
		try {		
			By wqNametxt=By.id(txtqueueName);
			Utilities.waitForPageLoad(driver, wqNametxt);
			if (driver.findElements(wqNametxt).size() != 0) {
				driver.findElement(wqNametxt).clear();
				driver.findElement(wqNametxt).sendKeys(workqueueName);
				extent.log(LogStatus.PASS, "Work queue Name : "+workqueueName +" is entered successfully");	
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Work queue Name : "+workqueueName +" is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectWorkqueueMedia(WebDriver driver, String Option) throws Exception {
		boolean flag = false;
		try {
			Thread.sleep(3000);
			By lstMedia=By.xpath(iconlstMedia);
			Utilities.waitForPageLoad(driver,lstMedia);
			if (driver.findElements(lstMedia).size()!=0) {
				driver.findElement(lstMedia).click();
				Thread.sleep(2000);
				driver.findElement(lstMedia).sendKeys(Option);
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				extent.log(LogStatus.INFO, "Work queue Media:"+Option+ " is selected");	
				flag = true;			
			} else {
				extent.log(LogStatus.FAIL, "Work queue Media:"+Option+ " is Unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickworkqueue(WebDriver driver) throws Exception {		
		boolean flag = false;
		try {	
			Utilities.selectRightPaneView(driver);
			By wqBtn = By.xpath(btnCreateworkqueue);
			Utilities.waitForPageLoad(driver, wqBtn);
			if (driver.findElements(wqBtn).size() != 0) {
				driver.findElement(wqBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create work queue button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.INFO, "Clicked on Create work queue button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
