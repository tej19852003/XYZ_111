package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.LogStatus;


import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;

public class DPAHomePageScreen {
	public static ExtentReports extent = ExtentReports.get(DPAHomePageScreen.class);
	public static Screen sobj = new Screen ();
	public static String lnkAdministration = "Administration";
	public static String lnkScreenContentTriggers = "Screen Content Triggers";
	public static String lnkScreenName = "Screen Name";

	public static void close_DPA(WebDriver driver, String windowHandle) throws Exception {
		driver.close();
		extent.log(LogStatus.INFO, "DPA window is closed");
		driver.switchTo().window(windowHandle);  // switch back to the original window
	}
	
	public static boolean selectMenuItem(WebDriver driver, String linkText, String menuItem, String triggerType) throws Exception {
		boolean flag = true;
		Thread.sleep(5000);	
		if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\DPA_Error.png") != null) {
			extent.log(LogStatus.FAIL, "Application error is displayed");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
			return flag = false;
		}
		Thread.sleep(1000);	
		WebElement tabName = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.linkText(linkText)));
		Actions action = new Actions(driver);
		action.moveToElement(tabName).build().perform();
		Thread.sleep(1000);	
		if (menuItem.contains("Triggers")) {
			if (sobj.exists(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Menu_Trigger.png") != null) {
				sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Menu_Trigger.png");
			} else {
				return flag = false;
			}
			sobj.click(Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Impact360_Text.png");
			extent.log(LogStatus.INFO, menuItem + " menu item is selected from " + linkText + " tab");
			Thread.sleep(2000);
		}

		if (triggerType.contains("Screen Content Triggers")) {
			if (driver.findElements(By.linkText(lnkScreenContentTriggers)).size() != 0) {
				if ( driver.findElements(By.linkText(lnkScreenName)).size() != 0) {
					extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");
					flag = true;
				} else {
					extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed");
					flag = false;
				}
			}
		}
		if (menuItem.contains("Application Analysis Reports")) {
			driver.manage().window().maximize();
			Thread.sleep(1000);	
			driver.findElement(By.xpath("//div[@id='ctl00_StaticMainMenuControl1_TopLevelMenu']/ul/li[1]/div/ul/li[2]/a")).click();
			extent.log(LogStatus.INFO, menuItem + " menu item is selected from " + linkText + " tab");
			Thread.sleep(6000);
			if (driver.findElements(By.xpath("//input[@id='ctl00_MidPanelContentHolder_btnDisplayReport']")).size() != 0) {
				extent.log(LogStatus.PASS, "Application Analysis Reports page is displayed");
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Application Analysis Reports page is NOT displayed");
				flag = false;
			}
		}
		return flag;		
	}

	public static boolean verifyDPAHomePage(WebDriver driver) throws Exception {
		boolean flag = true;
		try {			
			By home = By.linkText(lnkAdministration);
			Utilities.waitForPageLoad(driver, home);
			Thread.sleep(2000);
			if (driver.findElements(home).size() != 0) {
				extent.log(LogStatus.PASS, "DPA Home page is dispalyed successfully");			
			} else {
				extent.log(LogStatus.FAIL, "DPA Home page is NOT dispalyed");
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
