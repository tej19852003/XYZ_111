
package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.sikuli.script.Screen;

import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ApplicationAnalysisReportsScreen {
	
	public static Screen sobj = new Screen ();
	public static ExtentReports extent = ExtentReports.get(ApplicationAnalysisReportsScreen.class);
	public static String lstReportType = "ctl00_MidPanelContentHolder_lstViewBy_Input";
	public static String lstDateRange = "ctl00_MidPanelContentHolder_ReportDateRange_lstSpecialDate_Input";
	public static String lstFilters = "ctl00_MidPanelContentHolder_ReportFilter_lstFilterItems_Input";
	public static String btnAddFilter = "//input[@id='ctl00_MidPanelContentHolder_ReportFilter_btnAdd']";
	public static String btnDisplayReport = "//input[@id='ctl00_MidPanelContentHolder_btnDisplayReport']";
	public static String labReportName = "//span[@id='ctl00_MidPanelContentHolder_lblReportTitle']";
	
	public static boolean verifyReportName(WebDriver driver, String reportName) throws Exception {
		boolean flag = false;
		try {
			By repNamelab=By.xpath(labReportName);
			Utilities.waitForPageLoad(driver, repNamelab);
			if (driver.findElements(repNamelab).size() != 0) {
				if (driver.findElement(repNamelab).getText().trim().contains(reportName)) {
					extent.log(LogStatus.PASS, "Report Name:" + reportName + " is displayed as Expected");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AppAnalysisReport"));
					flag = true;
				}
				else {
					extent.log(LogStatus.FAIL, "Report Name:" + reportName + " is NOT displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AppAnalysisReport"));
				}
			}
			else {
				extent.log(LogStatus.FAIL, "Report Name:" + reportName + " is NOT displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AppAnalysisReport"));
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickDisplayReport(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			By dispRepBtn = By.xpath(btnDisplayReport);
			Utilities.waitForPageLoad(driver,dispRepBtn);
			if (driver.findElements(dispRepBtn).size() !=0 ) {
				driver.findElement(dispRepBtn).click();
				System.out.println("inside search");
				extent.log(LogStatus.INFO, "Clicked on Display Report is successful");
				Thread.sleep(3000);
				flag = true;
			} else {
				System.out.println("not inside search");
				extent.log(LogStatus.FAIL, "Clicked on Display Report is unsuccessful");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickAddFilter(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			By addFilterBtn=By.xpath(btnAddFilter);
			Utilities.waitForPageLoad(driver, addFilterBtn);
			if (driver.findElements(addFilterBtn).size() !=0 ) {
				driver.findElement(addFilterBtn).click();
				System.out.println("inside search");
				extent.log(LogStatus.INFO, "Clicked on Add Filter is successful");
				Thread.sleep(3000);
				flag = true;
			}else {
				System.out.println("not inside search");
				extent.log(LogStatus.FAIL, "Clicked on Add Filter is unsuccessful");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectFilters(WebDriver driver, String filterOption, String FilterValue) throws Exception {
		boolean flag = false;
		try {
			By filtersLst = By.id(lstFilters);
			Utilities.waitForPageLoad(driver, filtersLst);
			if (driver.findElements(filtersLst).size() != 0) {
				System.out.println("inside command dropdown");
				driver.findElement(filtersLst).click();
				Thread.sleep(1000);				
				int rcCommand=driver.findElements(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ReportFilter_lstFilterItems_DropDown']/div/ul/li")).size();
				for (int c=1; c<=rcCommand; c++) {
					WebElement list = driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ReportFilter_lstFilterItems_DropDown']/div/ul/li["+c+"]"));
					if (list.getText().trim().contains(filterOption)) {
						System.out.println("list item:" + list.getText());
						list.click();
						extent.log(LogStatus.INFO, "Filters:" + filterOption + " is selected");
						Thread.sleep(1000);
						driver.findElement(By.id("ctl00_MidPanelContentHolder_ReportFilter_cbList_Input")).click();
						driver.findElement(By.id("ctl00_MidPanelContentHolder_ReportFilter_cbList_Input")).sendKeys(FilterValue);
						Thread.sleep(2000);
						flag = true;
						break;
					}
				}
			}
			else {
				extent.log(LogStatus.FAIL, "Not able to select "+filterOption+ " from Filters dropdown");
			}			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectDateRange(WebDriver driver, String option) throws Exception {
		boolean flag = false;
		try {
			By dateRangeLst=By.id(lstDateRange);
			Utilities.waitForPageLoad(driver, dateRangeLst);
			if (driver.findElements(dateRangeLst).size() != 0) {
				System.out.println("inside command dropdown");
				driver.findElement(dateRangeLst).click();
				Thread.sleep(2000);				
				int rcCommand=driver.findElements(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ReportDateRange_lstSpecialDate_DropDown']/div/ul/li")).size();
				for (int c=1; c<=rcCommand; c++) {
					WebElement list=driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ReportDateRange_lstSpecialDate_DropDown']/div/ul/li["+c+"]"));
					if (list.getText().trim().contains(option)) {
						System.out.println("list item:" + list.getText());
						list.click();
						extent.log(LogStatus.INFO, "Date Range:" + option + " is selected");
						flag = true;
						break;
					}
				}
			}
			else {
				extent.log(LogStatus.FAIL, "Not able to select "+option+ " from Date Range dropdown");
			}			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean selectReportType(WebDriver driver, String command) throws Exception {
		boolean flag = false;
		try {
			By reportTypeLst=By.id(lstReportType);
			Utilities.waitForPageLoad(driver,reportTypeLst);
			if (driver.findElements(reportTypeLst).size() != 0) {
				System.out.println("inside command dropdown");
				driver.findElement(reportTypeLst).click();
				Thread.sleep(2000);				
				int rcCommand=driver.findElements(By.xpath("//div[@id='ctl00_MidPanelContentHolder_lstViewBy_DropDown']/div/ul/li")).size();
				System.out.println("size:" + rcCommand);
				for (int c=1; c<=rcCommand; c++) {
					WebElement list=driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_lstViewBy_DropDown']/div/ul/li[" + c + "]"));
					System.out.println("item:" + list.getText());
					if (list.getText().trim().contains(command)) {
						System.out.println("list item:" + list.getText());
						list.click();
						flag = true;
						break;
					}
				}
				
			}
			if (flag == false) {
				extent.log(LogStatus.FAIL, "Not able to select " + command + " from Report Type dropdown");
			}
			else {
				extent.log(LogStatus.PASS, "Find Option: " + command +  " is selected");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

}
