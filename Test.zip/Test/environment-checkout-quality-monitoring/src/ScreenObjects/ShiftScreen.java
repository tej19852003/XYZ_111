package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ShiftScreen {
	public static ExtentReports extent = ExtentReports.get(ShiftScreen.class);
	public static String btncreateshift = "//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtshiftname = "shift_name";
	public static String txtdesc = "shift_description";
	public static String strttime = "//table[@id='startTimesMinsSinceMidnight_table']//tbody//tr//td[@col='8']";
	public static String strttime2 = "//table[@id='startTimesMinsSinceMidnight_table']//tbody//tr//td[@col='16']";
	public static String btnsave = "//button[@id='toolbar_CREATE_NEW_ACTIONLabel']";

	public static boolean clickcreateshift(WebDriver driver) {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By createShiftBtn = By.xpath(btncreateshift);
			Utilities.waitForPageLoad(driver, createShiftBtn);
			if(driver.findElements(createShiftBtn).size() != 0) {
				driver.findElement(createShiftBtn).click();
				flag=true;
				extent.log(LogStatus.PASS,"Clcked on create button is sucessfull");
			} else {
				extent.log(LogStatus.FAIL,"Clcked on create button is not sucessfull");
				flag = false;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean setshiftName(WebDriver driver, String shiftName) throws Exception {
		boolean flag = false;
		try {
			By shiftNameText = By.name(txtshiftname);
			Utilities.waitForPageLoad(driver, shiftNameText);
			if (driver.findElements(shiftNameText).size() != 0) {
				driver.findElement(shiftNameText).clear();
				driver.findElement(shiftNameText).sendKeys(shiftName);
				extent.log(LogStatus.PASS, "Work pattern Name" + shiftName + " is entered successfully");
				flag=true;
			} else {
				extent.log(LogStatus.FAIL, "Work pattern Name " + shiftName + " is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean setshiftDescription(WebDriver driver, String shiftDescription) throws Exception {
		boolean flag = false;
		try {
			By shiftDescriptionText = By.name(txtdesc);
			Utilities.waitForPageLoad(driver, shiftDescriptionText);
			if (driver.findElements(shiftDescriptionText).size() != 0) {
				driver.findElement(shiftDescriptionText).clear();
				driver.findElement(shiftDescriptionText).sendKeys(shiftDescription);
				extent.log(LogStatus.PASS, "Work pattern Description " + shiftDescription + " is entered successfully");
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Work pattern Description " + shiftDescription + " is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setshiftstartTime(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			By shiftStartTime = By.xpath(strttime);
			Utilities.waitForPageLoad(driver, shiftStartTime);
			if (driver.findElements(shiftStartTime).size() != 0) {
				driver.findElement(shiftStartTime).click();
				extent.log(LogStatus.PASS, "Shift start time is entered sucessfully");	
				flag=true;
			} else {
				extent.log(LogStatus.FAIL, "Shift start time is not entered sucessfully");	
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean setshiftstartTime2(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			By shiftStartTime = By.xpath(strttime2);
			Utilities.waitForPageLoad(driver, shiftStartTime);
			if (driver.findElements(shiftStartTime).size() != 0) {
				driver.findElement(shiftStartTime).click();
				extent.log(LogStatus.PASS, "Shift start time is entered sucessfully");	
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Shift start time is not entered sucessfully");	
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnsave);
			Utilities.waitForPageLoad(driver, saveBtn);
			if (driver.findElements(saveBtn).size() != 0) {
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean Shiftexist(WebDriver driver, String shiftName) throws Exception {
		Utilities.selectRightPaneView(driver);
		boolean temp = false;
		driver.findElement(By.name("itemToFind")).clear();
    	driver.findElement(By.name("itemToFind")).sendKeys(shiftName);
    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
    	Thread.sleep(2000);
    	List<WebElement> li = driver.findElements(By.xpath("//table[@id='shiftTableRef']//tr[@class='tblRow']"));
    	System.out.println("++++" + li.size());
    	if (driver.findElements(By.xpath("//table[@id='shiftTableRef']//tr[@class='tblRow']//td")).size() != 0) {
    		for (WebElement elt:li) {
        		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
        		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
        		if (wname.contains(shiftName)) {
        			System.out.println("shift name is" + wname);
        			temp = true;
        			break;
        		}
        	}
    	} else {
    		temp = false;
    	}
    	return temp;
	}
	
	public static boolean deleteshift(WebDriver driver,String shiftName) throws Exception {
		boolean flag = false;
		try {
			driver.findElement(By.name("itemToFind")).clear();
	    	driver.findElement(By.name("itemToFind")).sendKeys(shiftName);
	    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
	    	List<WebElement> li = driver.findElements(By.xpath("//table[@id='shiftTableRef']//tr[@class='tblRow']"));
	    	System.out.println(li.size());
	    	if (li.size() > 0) {
	    		for (WebElement elt:li) {
	        		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
	        		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
	        		if (wname.contains(shiftName)) {
	        			elt.findElement(By.tagName("td")).click();
	        			driver.findElement(By.id("toolbar_DELETE_ACTIONLabel")).click();
	        			Utilities.sikuliClick(driver, Utilities.PROPERTIES.getProperty("ImagesPath") + "\\btnok_camp.png");
	        			System.out.println("Shift deleted");
	        			flag = true;
	        			break;
	        		}
	        	}
	    	}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
