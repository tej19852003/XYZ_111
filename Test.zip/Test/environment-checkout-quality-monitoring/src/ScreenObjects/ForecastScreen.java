package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ForecastScreen {
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	//public static String iconCampaign = "//span[@id='campaignSPPeopleFilterBox_listbox_0Wrapper']//nobr//img[@id='campaignSPPeopleFilterBox_listbox_0Button']";
	public static String iconCampaign = "//span[@id='spQueueFilterBox_listbox_0Wrapper']//nobr//img[@id='spQueueFilterBox_listbox_0Button']";
	public static String iconPeriod = "//span[@id='schedulingPeriodID_0Wrapper']//nobr//img[@id='schedulingPeriodID_0Button']";
	public static String iconwqfilter = "//span[@id='applicationMediator_listbox_0Wrapper']//nbor//img[@id='applicationMediator_listbox_0Button']";
	public static String linkqueue = "//div[@id='spQueueTreeWrapper']//table[@id='spQueueTree_id']//tbody//tr//th//a//span//span[contains(text(),'.AutoWFM_WQ')]";
	
	public static boolean setCampaign(WebDriver driver, String campaignName) {
		boolean flag = true;
		try {
			Utilities.selectLeftTreeFrame(driver);
			By iconCamp = By.xpath(iconCampaign);
			Utilities.waitForPageLoad(driver, iconCamp);
			if (driver.findElements(iconCamp).size() != 0) {
				driver.findElement(iconCamp).click();
				Thread.sleep(1000);
				Select sbox1=new Select(driver.findElement(By.id("spQueueFilterBox_listbox")));
				sbox1.selectByVisibleText(campaignName);
				Thread.sleep(3000);
				extent.log(LogStatus.INFO, "campaign:" + campaignName + " is selected from View Listbox for forecast screen");
				flag=true;
			} else {
				extent.log(LogStatus.FAIL, "Not able to select campaign:" + campaignName + " from View Listbox");
				return flag=false;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean selectCampaign(WebDriver driver, String campaignName) throws Exception {
		boolean flag = true;
		try {
			Utilities.selectLeftTreeFrame(driver);
			By iconCampaignList = By.xpath(iconCampaign);
			Utilities.waitForPageLoad(driver, iconCampaignList);
			if (driver.findElements(iconCampaignList).size() != 0) {
				driver.findElement(iconCampaignList).click();
				Thread.sleep(1000);
				driver.findElement(iconCampaignList).sendKeys(campaignName);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Campaign Name:" + campaignName + " is selected from View Listbox");
			} else {
				extent.log(LogStatus.FAIL, "Not able to select Campaign Name:" + campaignName + " from View Listbox");
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean selectPeriod(WebDriver driver, String period) throws Exception {
		boolean flag = true;
		try {
			Utilities.selectLeftTreeFrame(driver);
			By iconPeriodList = By.xpath(iconPeriod);
			Utilities.waitForPageLoad(driver, iconPeriodList);
			if (driver.findElements(iconPeriodList).size() != 0) {
				driver.findElement(iconPeriodList).click();
				Thread.sleep(1000);
				driver.findElement(iconPeriodList).sendKeys(period);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Period:" + period + " is selected from View Listbox");
			} else {
				extent.log(LogStatus.FAIL, "Not able to select Period:" + period + " from View Listbox");
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean setPeriod(WebDriver driver, String period) {
		boolean flag = true;
		try {
			Utilities.selectLeftTreeFrame(driver);
			By iconSchPeriod = By.xpath(iconPeriod);
			Utilities.waitForPageLoad(driver, iconSchPeriod);
			if (driver.findElements(iconSchPeriod).size() != 0) {
				driver.findElement(iconSchPeriod).click();
				Thread.sleep(1000);
				Select sBox = new Select(driver.findElement(By.id("schedulingPeriodID")));
				sBox.selectByVisibleText(period);
				Thread.sleep(3000);
				extent.log(LogStatus.INFO, "Period:" + period + " is selected from View Listbox for forecast screen");
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Not able to select Period:" + period + " from View Listbox");
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setFilter(WebDriver driver,String WkQuFilter) {
		boolean flag = true;
		try {
			Utilities.selectLeftTreeFrame(driver);
			By iconFilter = By.xpath(iconwqfilter);
			Utilities.waitForPageLoad(driver, iconFilter);
			if (driver.findElements(iconFilter).size() != 0) {
				driver.findElement(iconFilter).click();
				Thread.sleep(1000);
				driver.findElement(iconFilter).sendKeys(WkQuFilter);
				extent.log(LogStatus.INFO,"Filter: " + WkQuFilter+" is selected from list box");
			} else {
				extent.log(LogStatus.FAIL,"Not able to  select filter" +WkQuFilter+ "from list box");
				return flag = false;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectworkQueue(WebDriver driver, String workQueue) {
		boolean flag = false;
		try {
			Utilities.selectLeftTreeFrame(driver);
			By linkWorkQueue = By.xpath(linkqueue);
			Utilities.waitForPageLoad(driver, linkWorkQueue);
			if (driver.findElements(linkWorkQueue).size() != 0) {
				String wqueue = driver.findElement(linkWorkQueue).getText();
				if (wqueue.contains(workQueue)) {
					driver.findElement(linkWorkQueue).click();
					extent.log(LogStatus.PASS,"work queue" + workQueue +" is selected sucessfully");
					flag = true;
				}
				flag = true;
			} else {
				extent.log(LogStatus.FAIL,"work queue is not selected");
				flag = false;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
