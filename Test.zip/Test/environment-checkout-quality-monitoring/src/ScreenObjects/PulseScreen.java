package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.python.modules.thread.thread;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class PulseScreen {
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String iconCampaign = "//span[@id='queueFilter_listbox_0Wrapper']//nbor//img[@id='queueFilter_listbox_0Button']";
	
	public static boolean setcampaign(WebDriver driver, String campName) {
		boolean flag = true;
		try {
			Utilities.selectLeftTreeFrame(driver);
			By iconcamp=By.xpath(iconCampaign);
			Utilities.waitForPageLoad(driver, iconcamp);
			if (driver.findElements(iconcamp).size() != 0) {
				driver.findElement(iconcamp).click();
				Thread.sleep(2000);
				driver.findElement(iconcamp).sendKeys(campName);
				Thread.sleep(2000);
				extent.log(LogStatus.INFO,"Campaign Name:" + campName + " is selected from View Listbox");
			} else {
				extent.log(LogStatus.INFO,"Not able to select Campaign Name:" + campName + " from View Listbox");
				return flag = false;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean selectqueue(WebDriver driver, String workQueue) {
		Boolean temp = false;
		try {
			Utilities.selectLeftTreeFrame(driver);
			int rc = driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			System.out.println("rc:" + rc);
			for (int i=1; i<=rc; i++) {
				if (i <= 15) {
					String queuename=driver.findElement(By.xpath("//table[@id='queueTree_id']/tbody/tr[" + i + "]/td/a")).getText();
					System.out.println(workQueue);
					if (queuename.contains(workQueue)) {
						driver.findElement(By.xpath("//table[@id='queueTree_id']/tbody/tr[" + i + "]/td/a")).click();
						Thread.sleep(3000);
						temp = true;
						break;
					}
				}
			} if (temp == true) {
				extent.log(LogStatus.PASS, "work queue:" + workQueue + " is  selected successfully");
			} else {
				extent.log(LogStatus.FAIL, "Work Queue:" + workQueue + " NOT displayed ");
				return temp = false;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return temp;
	}
}
