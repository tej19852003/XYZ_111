package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class RequestsResultsScreen {
	
	public static ExtentReports extent = ExtentReports.get(RequestsResultsScreen.class);	
	public static String txtReportName = "rffName_0";  //input
	public static String txtReportNote = "note";  //textarea
	public static String btnRunNow = "//button[@id='toolbar_RUN_NOW_ACTIONLabel']";
	
	public static boolean clickRunNow(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By runNowBtn=By.xpath(btnRunNow);
			Utilities.waitForPageLoad(driver, runNowBtn);
			if (driver.findElements(runNowBtn).size() != 0) {
				driver.findElement(runNowBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Run Now button is successful");
				Thread.sleep(16000);
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Clicked on Run Now button is unsuccessful");
				flag = false;
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean setReportNote(WebDriver driver, String reportNote) {
		Boolean flag = false;
		try {
			By noteTxt = By.id(txtReportNote);
			Utilities.waitForPageLoad(driver, noteTxt);
			if (driver.findElements(noteTxt).size() != 0) {
				driver.findElement(noteTxt).sendKeys(reportNote);
				extent.log(LogStatus.PASS, "Report Note: " + reportNote + " is entered successfully");
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Report Note: " + reportNote + " is NOT entered");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return flag;	
	}

	public static boolean setReportName(WebDriver driver, String reportName) {
		Boolean flag = false;
		try {
			By nameTxt = By.id(txtReportName);
			Utilities.waitForPageLoad(driver,nameTxt);
			if (driver.findElements(nameTxt).size() != 0) {
				driver.findElement(nameTxt).sendKeys(reportName);
				extent.log(LogStatus.PASS, "Report Name: " + reportName + " is entered successfully");
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Report Name: " + reportName + " is NOT entered");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return flag;	
	}
	
	public static boolean selectReportSelection(WebDriver driver, String reportSelection) throws Exception {
		Boolean flag = false;
		try {
			Utilities.selectLeftTreeFrame(driver);
			Thread.sleep(3000);	
			if (driver.findElements(By.xpath("//div[@id='reportTreer0']")).size() == 0) {
				extent.log(LogStatus.FAIL, "Report Selection data is not displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "WFMReport"));
				return flag = false;
			}
			if (driver.findElements(By.xpath("//div[@id='reportTreer0']/nobr/a/span/span")).size() != 0) {
				driver.findElement(By.xpath("//div[@id='reportTreer0']/nobr/a/span/span")).click();
			}
            for (int i=0; i<=25 ;i++) {
                String reportSelApp = driver.findElement(By.xpath("//div[@id='reportTreer" + i + "Nodes']/div/nobr/a/span/span")).getText();
                System.out.println("reportSelApp:" + reportSelApp);
                if (reportSelApp.contains(reportSelection)) {
                    driver.findElement(By.xpath("//div[@id='reportTreer" + i + "Nodes']/div/nobr/a/span/span")).click();
                    extent.log(LogStatus.PASS, "Report Selection: " + reportSelection + " selected successfully");
                    flag = true;
                    break;
                }
            }
            if (flag == false) {
                extent.log(LogStatus.FAIL, "Unable to select Report Selection: " + reportSelection);
            }
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;			
	}
}
