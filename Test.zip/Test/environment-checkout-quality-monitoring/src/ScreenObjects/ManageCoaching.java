package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ManageCoaching {
	public static ExtentReports extent = ExtentReports.get(ManageCoaching.class);
	public static String btnCreate = "//button[@id='toolbar_COACHING_SESSION_LIST_CREATE_PAGE_ACTIONLabel']";
	public static String txtReason = "REASON_0";
	public static String txtDateTime = "SCHEDULE_DATE_0";
	public static String txtLocation = "LOCATION_0";
	public static String btnSave = "toolbar_COACHING_SESSION_FORM_SAVE_PAGE_ACTIONLabel";
	public static String btnPending = "//table[@id='toolbar_COACHING_SESSION_FORM_CREATE_SAVE_PENDING_PAGE_ACTIONWrapper']/tbody/tr/td/button[@id='toolbar_COACHING_SESSION_FORM_CREATE_SAVE_PENDING_PAGE_ACTIONLabel']";
	public static String icontraining = "//span[@id='TRAINEE_0Wrapper']//nobr//img[@id='TRAINEE_0Button']";
	public static String txttraineename = "//select[@id='TRAINEE']";
	
	public static boolean verifyStatus(WebDriver driver, String dateTime, String status) throws Exception {
		boolean flag = false;
		int rc = driver.findElements(By.xpath("//table[@id='coachingListWrapper']/tbody/tr")).size();
		System.out.println("rc:" + rc);
		if (rc > 0) {
			for (int i=1; i<=rc; i++) {
				if (i <= 15) {
					String datetimeApp = driver.findElement(By.xpath("//table[@id='coachingListWrapper']/tbody/tr[" + i + "]/td[3]/nobr")).getText();
					String[] str=datetimeApp.split(" ");
					String str0 = str[0];
					String str1 = str[1];
					String str2 = str[2];

					if (dateTime.contains(str0) & dateTime.contains(str1) & dateTime.contains(str2)) {
						driver.findElement(By.xpath("//table[@id='coachingListWrapper']/tbody/tr[" + i + "]/td[3]/nobr")).click();
						flag = true;
						extent.log(LogStatus.PASS, "Manage Coaching row has been selected");
						String statusApp=driver.findElement(By.xpath("//table[@id='coachingListWrapper']/tbody/tr[" + i + "]/td[9]/span")).getText();
						if (statusApp.contains(status)) {
							extent.log(LogStatus.PASS, "Status:" + status + " is displayed as Expected");
							extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "CoachingStatus"));
						} else {
							extent.log(LogStatus.FAIL, "Status:"+status+" is NOT displayed as Expected");
							extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "CoachingStatus"));
						}
						break;
					}
				}
			}
		} else {
			extent.log(LogStatus.FAIL, "No rows are displayed under Manage Coaching");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "CoachingStatus"));
			return flag = false;
		} if (flag == false) {
			extent.log(LogStatus.WARNING, "Not able to select Manage Coaching row");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "CoachingStatus"));
			return flag = false;
		}
		return flag;
	}
	
	public static boolean clickPending(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			By pendingBtn = By.xpath(btnPending);
			Utilities.waitForPageLoad(driver, pendingBtn);
			if (driver.findElements(pendingBtn).size() != 0) {
				driver.findElement(pendingBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Pending button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Clicked on Pending button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			By saveBtn = By.id(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size() != 0) {
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void setReason(WebDriver driver, String reason) throws Exception {
		try {
			By reasontxt = By.id(txtReason);
			Utilities.waitForPageLoad(driver, reasontxt);
			if (driver.findElements(reasontxt).size() != 0) {
				driver.findElement(reasontxt).clear();
				driver.findElement(reasontxt).sendKeys(reason);
				extent.log(LogStatus.PASS, "Reason : " + reason + " is entered successfully");
			} else {
				extent.log(LogStatus.FAIL, "Reason : " + reason + " is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void setLocation(WebDriver driver, String location) throws Exception {
		try {
			By loctxt = By.id(txtLocation);
			Utilities.waitForPageLoad(driver, loctxt);
			if (driver.findElements(loctxt).size() != 0) {
				driver.findElement(loctxt).clear();
				driver.findElement(loctxt).sendKeys(location);
				extent.log(LogStatus.PASS, "Location : " + location + " is entered successfully");
			} else {
				extent.log(LogStatus.FAIL, "Location : " + location + " is NOT entered");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void setDateTime(WebDriver driver, String dateTime) throws Exception {
		try {
			By datetime = By.id(txtDateTime);
			Utilities.waitForPageLoad(driver, datetime);
			if (driver.findElements(datetime).size() != 0) {
				driver.findElement(datetime).clear();
				driver.findElement(datetime).sendKeys(dateTime);
				extent.log(LogStatus.PASS, "Date and Time : " + dateTime + " is entered successfully");
			} else {
				extent.log(LogStatus.FAIL, "Date and Time : " + dateTime + " is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean clickCreate(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			By createBtn = By.xpath(btnCreate);
			Utilities.waitForPageLoad(driver, createBtn);
			if (driver.findElements(createBtn).size() != 0) {
				driver.findElement(createBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Manage Coaching - Create button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.INFO, "Clicked on Manage Coaching - Create button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean setemployee(WebDriver driver, String empname) {
		boolean flag = false;
		try {
			By traineeIcon = By.xpath(icontraining);
			Utilities.waitForPageLoad(driver, traineeIcon);
			if (driver.findElements(traineeIcon).size() != 0) {
				driver.findElement(traineeIcon).click();
				Thread.sleep(2000);
				Select sbox=new Select(driver.findElement(By.id("TRAINEE")));
				sbox.selectByVisibleText(empname);
				extent.log(LogStatus.PASS,"Employee Name:" + empname + " is selected from list box");
			} else {
				extent.log(LogStatus.FAIL, "Employee Name is not selected from list box");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
