package ScreenObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class OrganizationSettings {
	public static ExtentReports extent = ExtentReports.get(OrganizationSettings.class);
	public static String btnCreateOrg="//button[@id='workpaneMediator_toolbar_ADD_ACTIONLabel']";
	public static String txtOrganizationName="organizationName_0";
	public static String txtOrganizationDesc="description_0";
	public static String chkis24hours="bChk_is24Hour_true_0";
	public static String btnSave="workpaneMediator_toolbar_SAVE_ACTIONLabel";
	public static String iconlstWeekStartDay="//span[@id='weekStartDay_0Wrapper']/nobr/img[@id='weekStartDay_0Button']";
	public static String btnSaveApplySubOrg="//div[@id='workToolbarWrapper']span/table/tbody/tr[1]/td[2]/table/tbody/tr/td/button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	public static String btnDelete="//button[@id='workpaneMediator_toolbar_DELETE_CONFIRM_DIALOG_ACTIONLabel']";
	public static String btnDeleteOrg="//table[@id='workpaneMediator_toolbar_DELETE_ACTIONWrapper']/tbody/tr/td/button[@id='workpaneMediator_toolbar_DELETE_ACTIONLabel']";
	
	public static boolean verifyOrganizationFromLeftTreeFrame(WebDriver driver, String orgName) throws Exception {
		boolean flag = false;
		Utilities.selectLeftTreeFrame(driver);
		int rc1 = driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
		for (int i=1; i<=rc1; i++) {
			if (i <= 15) {
				String orgNameActual = driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[" + i + "]/td/a")).getText();
				Thread.sleep(1000);
				if (orgNameActual.contains(orgName)) {
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[" + i + "]/td/a")).click();
					flag=true;
					break;
				}
			}
		}
		if (flag == true) {
			extent.log(LogStatus.PASS, "Organization Name: " + orgName + " Created/Selected/verified successfully");
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "CreateOrganization"));
		} else {
			extent.log(LogStatus.INFO, "Organization Name: " + orgName + " does not exist");
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "CreateOrganization"));
			flag=false;
		}
		return flag;
	}

	public static boolean clickDeleteOrg(WebDriver driver) throws Exception {
		Utilities.selectRightPaneView(driver);
		boolean flag = true;
		try {
			By delOrgBtn=By.xpath(btnDeleteOrg);
			Utilities.waitForPageLoad(driver, delOrgBtn);
			if (driver.findElements(delOrgBtn).size() != 0) {
				driver.findElement(delOrgBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Confirmation - Delete button is successful");
				Thread.sleep(6000);
			} else {
				extent.log(LogStatus.INFO, "Clicked on Confirmation - Delete button is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean clickDelete(WebDriver driver) throws Exception {
		Utilities.selectRightPaneView(driver);
		boolean flag = true;
		try {
			By deleteBtn = By.xpath(btnDelete);
			Utilities.waitForPageLoad(driver, deleteBtn);
			if (driver.findElements(deleteBtn).size() != 0) {
				driver.findElement(deleteBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Delete button is successful");
				Thread.sleep(6000);
			} else {
				extent.log(LogStatus.INFO, "Clicked on Delete button is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static void clickSaveApplySubOrg(WebDriver driver) throws Exception {
		try {
			By saveSubOrgBtn = By.id(btnSaveApplySubOrg);
			Utilities.waitForPageLoad(driver, saveSubOrgBtn);
			if (driver.findElements(saveSubOrgBtn).size() != 0) {
				driver.findElement(saveSubOrgBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save and Apply to sub organizations button is successful");
				Thread.sleep(6000);
			} else {
				extent.log(LogStatus.INFO, "Clicked on Save and Apply to sub organizations button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean setWeekStartDay(WebDriver driver, String weekStartDay) throws Exception {
		boolean flag = false;
		try {
			By weekstartlst = By.xpath(iconlstWeekStartDay);
			Utilities.waitForPageLoad(driver,weekstartlst);
			if (driver.findElements(weekstartlst).size() != 0) {
				driver.findElement(weekstartlst).click();
				Thread.sleep(2000);
				driver.findElement(weekstartlst).sendKeys(weekStartDay);
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				extent.log(LogStatus.INFO, "Week Start Day:"+weekStartDay+ " is selected");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDay"));
				flag = true;
				Thread.sleep(4000);				
			} else {
				extent.log(LogStatus.FAIL, "Week Start Day : " + weekStartDay + " is NOT selected");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDay"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			By saveBtn = By.id(btnSave);
			Utilities.waitForPageLoad(driver, saveBtn);
			if (driver.findElements(saveBtn).size() != 0) {
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
			} else {
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static void isSelectedDaysAndHoursOfOperation(WebDriver driver) throws Exception {
		try {
			By is24HoursCheckbox = By.id(chkis24hours);
			Utilities.waitForPageLoad(driver, is24HoursCheckbox);
			if (driver.findElements(is24HoursCheckbox).size() != 0) {
				if (driver.findElement(is24HoursCheckbox).isSelected()) {
                    extent.log(LogStatus.INFO, "Days and Hours of Operation  - is 24hours is checked by default");
                } else {
                    extent.log(LogStatus.INFO, "Days and Hours of Operation  - is 24hours is not checked by default");
                }
			} else {
				extent.log(LogStatus.FAIL, "Days and Hours of Operation  - is 24hours checkbox is not displayed");
			}
			//Under Days and Hours of Operation banner- verifying check boxes 		
			if (driver.findElement(By.id("bChk_HooIsActive1_true_0")).isSelected() &&
                    driver.findElement(By.id("bChk_HooIsActive1_true_0")).isSelected() &&
                    driver.findElement(By.id("bChk_HooIsActive2_true_0")).isSelected() &&
                    driver.findElement(By.id("bChk_HooIsActive3_true_0")).isSelected() &&
                    driver.findElement(By.id("bChk_HooIsActive4_true_0")).isSelected() &&
                    driver.findElement(By.id("bChk_HooIsActive5_true_0")).isSelected() &&
                    driver.findElement(By.id("bChk_HooIsActive6_true_0")).isSelected() &&
                    driver.findElement(By.id("bChk_HooIsActive7_true_0")).isSelected()) {
				extent.log(LogStatus.INFO, "Under Days and Hours of Operation banner, Sunday - Saturday checkboxes are selected");
			} else {
				extent.log(LogStatus.INFO, "Under Days and Hours of Operation banner, Sunday - Saturday some of the checkboxes are NOT selected");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public static void setOrganizationDescription(WebDriver driver, String orgDesc) throws Exception {
		try {
			By orgDesctxt = By.id(txtOrganizationDesc);
			Utilities.waitForPageLoad(driver, orgDesctxt);
			if (driver.findElements(orgDesctxt).size() != 0) {
				driver.findElement(orgDesctxt).clear();
				driver.findElement(orgDesctxt).sendKeys(orgDesc);
				extent.log(LogStatus.PASS, "Organization Description : " + orgDesctxt + " is entered successfully");
			} else {
				extent.log(LogStatus.FAIL, "Organization Description : " + orgDesctxt + " is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void setOrganizationName(WebDriver driver, String orgName) throws Exception {
		try {
			By orgtxt = By.id(txtOrganizationName);
			Utilities.waitForPageLoad(driver, orgtxt);
			if (driver.findElements(orgtxt).size() != 0) {
				driver.findElement(orgtxt).clear();
				driver.findElement(orgtxt).sendKeys(orgName);
				extent.log(LogStatus.PASS, "Organization Name : " + orgName + " is entered successfully");
			} else {
				extent.log(LogStatus.FAIL, "Organization Name : " + orgName + " is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean clickCreateOrganization(WebDriver driver) throws Exception {
		boolean flag = true;
		try {
			By orgBtn = By.xpath(btnCreateOrg);
			Utilities.waitForPageLoad(driver, orgBtn);
			if (driver.findElements(orgBtn).size() != 0) {
				driver.findElement(orgBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create Organization button is successful");
				Thread.sleep(6000);
			} else {
				extent.log(LogStatus.INFO, "Clicked on Create Organization button is unsuccessful");
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectOrganizationFromLeftTreeFrame(WebDriver driver, String orgName) throws Exception {
		boolean flag = false;
		int rc = driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
		for (int i=1; i<=rc; i++) {
			if (orgName.contains("state") || orgName.contains("State")) {
				driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[1]/td/a")).click();
				flag = true;
				break;
			}
			if (i <= 15) {
                String orgNameActual = driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[" + i + "]/td/a")).getText();
                if (orgNameActual.contains(orgName)) {
                    driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[" + i + "]/td/a")).click();
                    flag = true;
                    break;
                }
			}
		}
		if (flag==true) {
			extent.log(LogStatus.PASS, "Organization Name: " + orgName + " Created/Selected successfully");
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "CreateOrganization"));
		} else {
			extent.log(LogStatus.WARNING, "Not able to select Parent Organization Name: " + orgName);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "CreateOrganization"));
			return flag = false;
		}
		return flag;
	}
}
