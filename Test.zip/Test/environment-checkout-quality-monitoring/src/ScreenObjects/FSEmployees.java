package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

//import Library.DPA_Library;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class FSEmployees {
	
	public static ExtentReports extent = ExtentReports.get(FSEmployees.class);
	public static String btnAddEmpToSP="//button[@id='toolbar_OPT_PROFILE_ADD_TO_SPLabel']";
	public static String iconlstCampaign="//span[@id='campaignSPPeopleFilterBox_listbox_0Wrapper']/nobr/img[@id='campaignSPPeopleFilterBox_listbox_0Button']";
	public static String iconlstPeriod="//span[@id='schedulingPeriodID_0Wrapper']/nobr/img[@id='schedulingPeriodID_0Button']";
	public static String btnAdd="//button[@id='workpaneMediator_toolbar_ADD_ACTIONLabel']";
	public static String linkagent="//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr//td[2]//div//nobr//a";
	public static String btnSelectall="//button[@id='workpaneMediator_toolbar_SelectAllRowsLabel']";
	public static String btnSave="//button[@id='toolbar_SAVE_ACTIONLabel']";
	
	public static boolean clickAdd(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			
			By addBtn=By.xpath(btnAdd);
			Utilities.waitForPageLoad(driver,addBtn);
			if (driver.findElements(addBtn).size()!=0)
			{					
				driver.findElement(addBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Add To Scheduling Period - Add button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Add To Scheduling Period - Add button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean addEmployeeToSP(WebDriver driver,String EmpName) throws Exception
	{
		
		Boolean flag=false;
		try {
			int emprc=driver.findElements(By.xpath("//table[@id='tblRef']/tbody/tr")).size();
			System.out.println("valrcPriv:"+emprc);
			for (int i=1;i<=emprc;i++)
			{
				
				String empNameApp=driver.findElement(By.xpath("//table[@id='tblRef']/tbody/tr["+i+"]/td[1]")).getText().trim();
				System.out.println("nameApp:"+empNameApp);
				System.out.println("empname:"+EmpName);
				
				if (empNameApp.contains(EmpName))
				{
					driver.findElement(By.xpath("//table[@id='tblRef']/tbody/tr["+i+"]/td[1]")).click();					
					flag=true;
					break;
				}
			}
			
			if (flag==true)
			{
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Name: "+EmpName+" Selected successfully");
				//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Select Emp Name: "+EmpName);
				//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
				return flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickAddEmployeeToSP(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			Utilities.selectRightPaneView(driver);
			By addEmpSPBtn=By.xpath(btnAddEmpToSP);
			Utilities.waitForPageLoad(driver,addEmpSPBtn);
			if (driver.findElements(addEmpSPBtn).size()!=0)
			{					
				driver.findElement(addEmpSPBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Add Employee To SP button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Add Employee To SP button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectPeriod(WebDriver driver,String Period) throws Exception
	{
		boolean flag=true;
		try{			
			Utilities.selectLeftTreeFrame(driver);
			By iconPeriodlst=By.xpath(iconlstPeriod);
			Utilities.waitForPageLoad(driver,iconPeriodlst);
			if (driver.findElements(iconPeriodlst).size()!=0)
			{					
				driver.findElement(iconPeriodlst).click();
				Thread.sleep(1000);
				driver.findElement(iconPeriodlst).sendKeys(Period);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Period:"+Period+" is selected from View Listbox");				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Period:"+Period+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	/*public static boolean selectCampaign(WebDriver driver,String CampaignName) throws Exception
	{
		boolean flag=true;
		try{
			
			Utilities.selectLeftTreeFrame(driver);
			By iconCamplst=By.xpath(iconlstCampaign);
			Utilities.waitForPageLoad(driver,iconCamplst);
			if (driver.findElements(iconCamplst).size()!=0)
			{					
				driver.findElement(iconCamplst).click();
				Thread.sleep(1000);
				driver.findElement(iconCamplst).sendKeys(CampaignName);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Campaign Name:"+CampaignName+" is selected from View Listbox");				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Campaign Name:"+CampaignName+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}*/
	
	
	public static boolean selectCampaign(WebDriver driver,String CampaignName) throws Exception
	{
		boolean flag=true;
		try{
			
			Utilities.selectLeftTreeFrame(driver);
			By iconCamplst=By.xpath(iconlstCampaign);
			Utilities.waitForPageLoad(driver,iconCamplst);
			if (driver.findElements(iconCamplst).size()!=0)
			{					
				//driver.findElement(iconCamplst).click();
				Thread.sleep(2000);
				//driver.findElement(By.xpath("//input[@id='campaignSPPeopleFilterBox_listbox_0']")).sendKeys(CampaignName);
				Select sbox=new Select(driver.findElement(By.id("campaignSPPeopleFilterBox_listbox")));
				sbox.selectByVisibleText(CampaignName);
				//driver.findElement(iconCamplst).sendKeys(CampaignName);
				Thread.sleep(5000);	
				/*driver.findElement(iconCamplst).click();
				Thread.sleep(2000);*/
//				driver.findElement(iconCamplst).sendKeys(CampaignName);
				extent.log(LogStatus.INFO, "Campaign Name:"+CampaignName+" is selected from View Listbox");				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Campaign Name:"+CampaignName+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean SelectEmployee(WebDriver driver,String EmployeeName) throws Exception
	{
		boolean flag=false;
		Utilities.selectLeftTreeFrame(driver);
		int no= driver.findElements(By.xpath("//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr")).size();
		System.out.println("no of rows are:" + no);
		//String empname=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr[1]//td[2]//div//nobr//a")).getText();
		for(int i=1;i<=no;i++)
		{
			String empname=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr["+i+"]//td//div//nobr//a")).getText();
			System.out.println("emp name is:"+ empname );
			if(empname.contains(EmployeeName))
			{
				driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr["+i+"]//td//div//nobr//a")).click();
				Thread.sleep(2000);
				flag=true;
				break;
				
				
			}
			
		}
		if(flag==true)
		{
			extent.log(LogStatus.PASS,EmployeeName +"is selected sucessfully");
		}
		else
		{
			extent.log(LogStatus.FAIL,EmployeeName + " does not exist");
			return flag=false;
		}
		return flag;
	
	}
	
	public static boolean ClickSave(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By savbtn=By.xpath(btnSave);
			Utilities.waitForPageLoad(driver,savbtn);
			if(driver.findElements(savbtn).size()!=0)
			{
				driver.findElement(savbtn).click();
				flag=true;
				extent.log(LogStatus.PASS,"clicked on ave buttion is sucessfull");
			}
			else
			{
				extent.log( LogStatus.FAIL,"save button is not abe to click");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean Empexist(WebDriver driver,String Empname) throws Exception
	{
		Utilities.selectLeftTreeFrame(driver);
		boolean flag=false;
		int rows1=driver.findElements(By.xpath("//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr")).size();
		System.out.println("row size is"+ rows1);
		if(rows1>0)
		{
			System.out.println("in if condition");
			Utilities.selectLeftTreeFrame(driver);
			for(int k=1;k<=rows1;k++)
			{
				String ename=driver.findElement(By.xpath("//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr["+k+"]//td//div//nobr//a")).getAttribute("innerText");
				System.out.println("emp name is" + ename);
				if(ename.contains(Empname))
				{
					flag=true;
					System.out.println("falg is" + flag);
					break;
					//extent.log(LogStatus.INFO,"Employee:" +Empname+ "is already added to the schedule period");
				}
			}
			
			
		}
		else
		{
			flag=false;
		}
		System.out.println("final value of flag is:" + flag);
		return flag;
		
	}
}

