package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ServiceGoals {
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String iconCampaign="//span[@id='spQueueFilterBox_listbox_0Wrapper']//nobr//img[@id='spQueueFilterBox_listbox_0Button']";
	public static String iconPeriod="//span[@id='schedulingPeriodID_0Wrapper']//nobr//img[@id='schedulingPeriodID_0Button']";
	public static String linkqueue="//div[@id='spQueueTreeWrapper']//table[@id='spQueueTree_id']//tbody//tr//th//a//span//span[@id='r0c0Content']";
	
	public static boolean setCampaign(WebDriver driver, String campaignName) throws Exception {
		boolean flag = true;
		try {
			
			Utilities.selectLeftTreeFrame(driver);
			By iconCampaignList = By.xpath(iconCampaign);
			Utilities.waitForPageLoad(driver, iconCampaignList);
			if (driver.findElements(iconCampaignList).size() != 0) {
				driver.findElement(iconCampaignList).click();
				Thread.sleep(1000);
				driver.findElement(iconCampaignList).sendKeys(campaignName);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Campaign Name:" + campaignName + " is selected from View Listbox");
			} else {
				extent.log(LogStatus.FAIL, "Not able to select Campaign Name:" + campaignName + " from View Listbox");
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectCampaign(WebDriver driver, String campaignName) {
		boolean flag = true;
		try {
			Utilities.selectLeftTreeFrame(driver);
			By iconCampaign = By.xpath(ServiceGoals.iconCampaign);
			Utilities.waitForPageLoad(driver, iconCampaign);
			if (driver.findElements(iconCampaign).size() != 0) {
				driver.findElement(iconCampaign).click();
				Thread.sleep(1000);
				Select sbox1=new Select(driver.findElement(By.id("spQueueFilterBox_listbox")));
				sbox1.selectByVisibleText(campaignName);
				Thread.sleep(3000);
				extent.log(LogStatus.INFO, "campaign:" + campaignName + " is selected from View Listbox for forecast screen");
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Not able to select campaign:" + campaignName + " from View Listbox");
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setPeriod(WebDriver driver, String period) {
		boolean flag = true;
		try {
			Utilities.selectLeftTreeFrame(driver);
			By iconSchPeriod = By.xpath(iconPeriod);
			Utilities.waitForPageLoad(driver, iconSchPeriod);
			if (driver.findElements(iconSchPeriod).size() != 0) {
				driver.findElement(iconSchPeriod).click();
				Thread.sleep(1000);
				driver.findElement(iconSchPeriod).sendKeys(period);
				extent.log(LogStatus.INFO, "Period:" + period + " is selected from View Listbox");
			} else {
				extent.log(LogStatus.FAIL, "Not able to select Period:" + period + " from View Listbox");
				return flag = false;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectworkQueue(WebDriver driver,String workQueue) {
		boolean flag = false;
		try {
			Utilities.selectLeftTreeFrame(driver);
			By linkwq = By.xpath(linkqueue);
			Utilities.waitForPageLoad(driver, linkwq);
			if (driver.findElements(linkwq).size() != 0) {
				String wqueue=driver.findElement(linkwq).getText();
				System.out.println("work quque name in service goal is" +wqueue);
				if (wqueue.contains(workQueue)) {
					driver.findElement(linkwq).click();
					extent.log(LogStatus.PASS,"work queue" + workQueue +" is selected sucessfully");
					flag = true;
				}
				flag = true;
			} else {
				extent.log(LogStatus.FAIL,"work queue is not selected");
				flag = false;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
