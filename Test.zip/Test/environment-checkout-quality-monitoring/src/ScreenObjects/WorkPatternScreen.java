package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WorkPatternScreen {
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String btnCreateworkpattern = "//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtworkpatternName = "workPatternName";
	public static String txtworkpatternDesc = "workPatternDesc";
	public static String txtemployeetype = "employeeType__input_0";
	public static String chkboxsun = "shiftPatternWorkDaysTable_1_occurenceCheckBoxPC_MQ__input_id";
	public static String chkboxmon = "shiftPatternWorkDaysTable_2_occurenceCheckBoxPC_MQ__input_id";
	public static String chkboxtue = "shiftPatternWorkDaysTable_3_occurenceCheckBoxPC_MQ__input_id";
	public static String chkboxwed = "shiftPatternWorkDaysTable_4_occurenceCheckBoxPC_MQ__input_id";
	public static String chkboxthurs = "shiftPatternWorkDaysTable_5_occurenceCheckBoxPC_MQ__input_id";
	public static String chkboxfri = "shiftPatternWorkDaysTable_6_occurenceCheckBoxPC_MQ__input";
	public static String chkboxsat = "shiftPatternWorkDaysTable_7_occurenceCheckBoxPC_MQ__input_id";
	public static String btnAddshift = "workDaysToolbar_POPUP_SHIFTLabel";
	public static String btnSaveworkPattern = "//button[@id='toolbar_CREATE_NEW_ACTIONLabel']";
	
	public static boolean clickworkpattern(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By workPatternBtn = By.xpath(btnCreateworkpattern);
			Utilities.waitForPageLoad(driver, workPatternBtn);
			if (driver.findElements(workPatternBtn).size() != 0) {
				driver.findElement(workPatternBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create work pattern button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.INFO, "Clicked on Create work pattern button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setWorkpatternName(WebDriver driver, String workPatternName) throws Exception {
		boolean flag = false;
		try {
			By workPatternNameTxt = By.name(txtworkpatternName);
			Utilities.waitForPageLoad(driver, workPatternNameTxt);
			if (driver.findElements(workPatternNameTxt).size() != 0) {
				driver.findElement(workPatternNameTxt).clear();
				driver.findElement(workPatternNameTxt).sendKeys(workPatternName);
				extent.log(LogStatus.PASS, "Work pattern Name" + workPatternName + " is entered successfully");
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Work pattern Name " + workPatternName + " is NOT entered");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setWorkpatternDescription(WebDriver driver, String workPatternDesc) throws Exception {
		boolean flag = false;
		try {
			By workPatternDescriptionTxt = By.name(txtworkpatternDesc);
			Utilities.waitForPageLoad(driver, workPatternDescriptionTxt);
			if (driver.findElements(workPatternDescriptionTxt).size() != 0) {
				driver.findElement(workPatternDescriptionTxt).clear();
				driver.findElement(workPatternDescriptionTxt).sendKeys(workPatternDesc);
				extent.log(LogStatus.PASS, "Work pattern Description " + workPatternDesc + " is entered successfully");
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Work pattern Description " + workPatternDesc + " is NOT entered");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setEmployeeType(WebDriver driver, String employeeType) throws Exception {
		boolean flag = false;
		try {
			driver.findElement(By.id("employeeType__input_0Button"));
			By employeeTypeTxt = By.id(txtemployeetype);
			Utilities.waitForPageLoad(driver, employeeTypeTxt);
			if (driver.findElements(employeeTypeTxt).size() != 0) {
				driver.findElement(employeeTypeTxt).clear();
				driver.findElement(employeeTypeTxt).sendKeys(employeeType);
				extent.log(LogStatus.PASS, "Employee Type  " + employeeType + " is entered successfully");
				flag = true;
			} else {
				extent.log(LogStatus.FAIL, "Employee Type  " + employeeType + " is not entered ");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setpossibledaysOff(WebDriver driver)throws Exception {
		boolean temp = false;
		Utilities.selectRightPaneView(driver);
		int rows=driver.findElements(By.xpath("//table[@id='shiftPatternWorkDaysTableRef']//tbody//tr//td")).size();
		System.out.println("no of rows are:" + rows);
		for (int i=3; i<8; i++) {
			if (driver.findElement(By.xpath("//table[@id='shiftPatternWorkDaysTableRef']//tbody//tr//td[contains(@id,'shiftPatternWorkDaysTabler1c" + i + "')]//input[@type='checkbox']")).isSelected()) {
				driver.findElement(By.xpath("//table[@id='shiftPatternWorkDaysTableRef']//tbody//tr//td[contains(@id,'shiftPatternWorkDaysTabler1c" + i + "')]//input[@type='checkbox']")).click();
				extent.log(LogStatus.PASS,"possible days off saturday and sunday is checked");
			}
		}
		return temp = true;
	}

	public static boolean clickAddshift(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			By addShiftBtn = By.id(btnAddshift);
			Utilities.waitForPageLoad(driver, addShiftBtn);
			if (driver.findElements(addShiftBtn).size() != 0) {
				driver.findElement(addShiftBtn).click();
				extent.log(LogStatus.PASS, "Clicked on add shift button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.INFO, "Clicked on add shift button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean clickSave(WebDriver driver) throws Exception {
		boolean flag = false;
		try {
			Utilities.selectRightPaneView(driver);
			By saveBtn = By.xpath(btnSaveworkPattern);
			Utilities.waitForPageLoad(driver, saveBtn);
			if (driver.findElements(saveBtn).size() != 0) {
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
				flag = true;
			} else {
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setshift(WebDriver driver, String ShiftName)throws Exception {
		boolean flag = false;
		try {
			driver.findElement(By.name("itemToFind")).sendKeys(ShiftName);
	    	driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_FIND_ACTIONLabel']")).click();
	    	Thread.sleep(2000);
			List<WebElement> li1 = driver.findElements(By.xpath("//table[@id='shiftTableRef']//tr[@class='tblRow']"));
			System.out.println(li1.size());
			for (WebElement elt:li1) {
				System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
				String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
				if (wname.contains(ShiftName)) {
					Utilities.sikuliClick(driver, Utilities.PROPERTIES.getProperty("ImagesPath") + "\\Scrollbar.png");
					elt.findElement(By.tagName("td")).click();
					flag = true;
					break;
				}
			}
			driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addShiftsLabel']")).click();
			flag = true;
		} catch(Exception e){
			e.printStackTrace();
		}
		return flag;
	}
}
