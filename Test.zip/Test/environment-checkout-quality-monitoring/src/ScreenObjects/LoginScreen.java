package ScreenObjects;

import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.relevantcodes.extentreports.LogStatus;
import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;

public class LoginScreen {

	public static final Properties PROPERTIES = Utilities.PROPERTIES;
	public static ExtentReports extent = ExtentReports.get(LoginScreen.class);
	public static String txtUsername = "username";
	public static String txtPassword = "password";
	public static String btnLogin = "loginToolbar_LOGINLabel";

	public static void launchVerint(WebDriver driver, String url) throws Exception {
		String deleteCookiesPath = PROPERTIES.getProperty("DeleteCookiesPath");
        String deleteCookiesCMD = "wscript " + deleteCookiesPath;
		Runtime.getRuntime().exec( deleteCookiesCMD );
		Thread.sleep(15000);
		driver.get(url);
		extent.log(LogStatus.INFO, "Navigated to " + url);
		Thread.sleep(4000);
		
		Set<String> handles = driver.getWindowHandles();
		for (String handle : handles) {
			if (!driver.equals(handle)) {
				driver.switchTo().window(handle);            
			}
		}   
		Utilities.logout(driver);
		extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "LoginScreen"));
		Thread.sleep(2000);
		driver.manage().window().maximize();
	}
	
	public static boolean verifyLoginPageLaunched(WebDriver driver) throws Exception {
		boolean flag = true;
		try {			
			By uidtxt = By.id(txtUsername);
			Utilities.waitForPageLoad(driver, uidtxt);
			if (driver.findElements(uidtxt).size() != 0) {
				extent.log(LogStatus.INFO, "Verint Login page launched successfully");
			} else {
				extent.log(LogStatus.FAIL, "Verint Login page NOT launched");
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;			
	}

	public static boolean setTextInUsername(WebDriver driver, String username) {
		boolean flag = true;
		try {
			By uidtxt = By.id(txtUsername);
			Utilities.waitForPageLoad(driver, uidtxt);
			if (driver.findElements(uidtxt).size() != 0) {
				driver.findElement(uidtxt).sendKeys(username);
				extent.log(LogStatus.PASS, "User ID: " + username + " is entered successfully");
			} else {
				extent.log(LogStatus.FAIL, "User ID: " + username + " is NOT entered");
				return flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void setTextInPassword(WebDriver driver, String password) throws Exception {
		try {
			By pwd = By.id(txtPassword);
			Utilities.waitForPageLoad(driver, pwd);
			if (driver.findElements(pwd).size() != 0) {
				driver.findElement(pwd).sendKeys(password);
				extent.log(LogStatus.PASS, "Password: ******* is entered successfully");
			} else {
				extent.log(LogStatus.FAIL, "Password: ******* is NOT entered");
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void clickLogin(WebDriver driver) throws Exception {
		try {
			By btn = By.id(btnLogin);
			Utilities.waitForPageLoad(driver, btn);
			if (driver.findElements(btn).size() != 0) {
				driver.findElement(btn).click();
				Thread.sleep(1000);
				extent.log(LogStatus.PASS, "Clicked on Login button is successful");
			} else {
				extent.log(LogStatus.FAIL, "Clicked on Login button is unsuccessful");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
