package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;

import ScreenObjects.VerintHomePageScreen;

import Utilities.Utilities;

public class Delete_DataSourceGroup {
	
	public static ExtentReports extent = ExtentReports.get(Delete_DataSourceGroup.class);
	
	public static boolean DeleteDataSourceGroup() throws Exception {
		boolean flag = true;
		boolean temp = false;
		String HTMLReportName="Delete_DataSourceGroups"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Delete DataSourceGroup");
				
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook wb = Workbook.getWorkbook(fis);
	    Sheet ws = wb.getSheet("BO_TestSet");
	  
	    String dataSourceName = ws.getCell(9, 9).getContents();
	    String dataSourceGroupName = ws.getCell(14, 9).getContents();
		
		try {
			LoginScreen.launchVerint(driver, Utilities.PROPERTIES.getProperty("VerintURL"));
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver, "System Management", "Data Sources")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver, "System Management", "Data Sources"))
				{
					extent.log(LogStatus.WARNING, "Settings section is not displayed. Please try again.");
					return flag = false;
				}
			}			
			Utilities.selectLeftTreeFrame(driver);
			if (!DataSourceScreen.selectDataSourceName(driver, dataSourceName)) {
				return flag=false;
			}	
			//select Data source groups link/tab
			driver.switchTo().defaultContent();			
			if (driver.findElements(By.linkText("Data Source Groups")).size() != 0) {
				driver.findElement(By.linkText("Data Source Groups")).click();
				extent.log(LogStatus.INFO, "Data Source Groups link/tab is selected");				
			}
			else {
				extent.log(LogStatus.FAIL, "Not able to select Data Source Groups link/tab");	
				return flag = false;
			}
			//check whether DSG exist or not.
			Utilities.selectRightPaneView(driver);
			int valrcWq=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("valrcPriv:"+valrcWq);
			for (int j=1; j<=valrcWq; j++) {
				if (j <=15) {
					String dsgnameApp = driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr[" + j + "]/th/a/span")).getText().trim();
					System.out.println("dsgnameApp:" + dsgnameApp);
					System.out.println("DataSourceGroupName:" + dataSourceGroupName);
					Thread.sleep(3000);
					if (dsgnameApp.contains(dataSourceGroupName)) {
						driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr[" + j + "]/th")).click();
						temp = true;
						break;
					}
				}
			}
			if (temp == true) {
				System.out.println("DSG pass");
				extent.log(LogStatus.PASS, "Data Source Group Name: " + dataSourceGroupName + " created/selected successfully");
				//delete DSG
				if (!DataSourceScreen.clickDeleteGroup(driver)) {
					return flag = false;
				}
			}
			else {
				extent.log(LogStatus.FAIL, "Data Source Group Name:" + dataSourceGroupName + " does not exist/not able to delete");
			}
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "BO", HTMLReportName, 4, 9);
		}
		return flag;
	}
}
