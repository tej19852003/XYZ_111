package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Create_Map_Organization {
	public static final Properties PROPERTIES = Utilities.PROPERTIES;
	public static ExtentReports extent = ExtentReports.get(Create_Map_Organization.class);
	public static Screen sobj = new Screen ();

	public static boolean CreateMapOrganization() throws Exception {
		boolean flag = true;
		String HTMLReportName = "CreateMapOrganization" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Create Map Organization");
		
		File file = new File(PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());

		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		WebDriver driver = new InternetExplorerDriver(capabilities);
		
		FileInputStream fis = new FileInputStream(PROPERTIES.getProperty("TestDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	    String organizationName = Ws.getCell(5, 2).getContents();
	    String organizationDesc = Ws.getCell(6, 2).getContents();
	    String organizationParent = Ws.getCell(7, 2).getContents();
	    String subOrganizatioName = Ws.getCell(17, 2).getContents();
	    String weekStartDay = Ws.getCell(18, 2).getContents();

		try {
			LoginScreen.launchVerint(driver, PROPERTIES.getProperty("VerintURL"));
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver, "Organization Management", "Organization Settings")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver, PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver, PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver, "Organization Management", "Organization Settings")) {
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again");
					return flag = false;
				}			
			}
			//1st organization
			if (!mapOrganization(driver, organizationName, organizationParent, organizationDesc, "")) {
				return flag = false;
			}
			//child organization
			if (!mapOrganization(driver, subOrganizatioName, organizationName, organizationDesc, "")) {
				return flag = false;
			}
			//select 1st organization
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver, organizationName)) {
				return flag = false;
			}
			Utilities.selectRightPaneView(driver);
			if (!OrganizationSettings.setWeekStartDay(driver, weekStartDay)) {
				return flag = false;
			}
			if (driver.findElements(By.xpath("//button[@id='dayBoundaryOffset_0BtnWrapper']")).size() != 0) {
				driver.findElement(By.xpath("//button[@id='dayBoundaryOffset_0BtnWrapper']")).click();
			}
			Thread.sleep(1000);
			if (driver.findElements(By.xpath("//input[@id='_timePickertPkrHour']")).size() != 0) {
				driver.findElement(By.xpath("//input[@id='_timePickertPkrHour']")).sendKeys("01");
			}
			Thread.sleep(1000);
			if (driver.findElements(By.xpath("//table[@id='_timePickerSET_BUTTON_WRAPPER_table_id']/tbody/tr/td/button/nobr")).size() != 0) {
				driver.findElement(By.xpath("//table[@id='_timePickerSET_BUTTON_WRAPPER_table_id']/tbody/tr/td/button/nobr")).click();
			}
			Thread.sleep(2000);
			Utilities.sikuliClick(driver, PROPERTIES.getProperty("ImagesPath") + "\\SaveApplyToSuborg.png");
			Utilities.sikuliClick(driver, PROPERTIES.getProperty("ImagesPath") + "\\Delete_OK.png");

			//select child organization
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver, subOrganizatioName)) {
				return flag = false;
			}
			//verify week start day
			Utilities.selectRightPaneView(driver);
			if (driver.findElements(By.xpath("//input[@id='weekStartDay_0']")).size() != 0) {
				if (driver.findElement(By.xpath("//input[@id='weekStartDay_0']")).getText().contains(weekStartDay)) {
					extent.log(LogStatus.PASS, "Parent Organization:" + organizationName + " Week Start Day:" + weekStartDay + "mapped successfully to Sub Organization:"+subOrganizatioName);
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDay"));
				}
				else {
					extent.log(LogStatus.FAIL, "Parent Organization:" + organizationName + " Week Start Day:" + weekStartDay + " NOT mapped to Sub Organization:"+subOrganizatioName);
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDay"));
					flag = false;
				}
			}
			else {
				extent.log(LogStatus.FAIL, "Week Start Day field is NOT displayed");
				return flag = false;
			}
			if (driver.findElements(By.xpath("//input[@id='dayBoundaryOffset_0']")).size() != 0) {
				if (driver.findElement(By.xpath("//input[@id='dayBoundaryOffset_0']")).getText().contains("1:00 AM")) {
					extent.log(LogStatus.PASS, "Parent Organization:" + organizationName + " Day boundary: 1:00 AM mapped successfully to Sub Organization:" + subOrganizatioName);
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDayoundary"));
				}
				else {
					extent.log(LogStatus.FAIL, "Parent Organization:" + organizationName + " Day boundary: 1:00 AM NOT mapped to Sub Organization:" + subOrganizatioName);
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDayoundary"));
					flag = false;
				}
			}
			else {
				extent.log(LogStatus.FAIL, "Day boundary field is NOT displayed");
				flag = false;
			}
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "BO", HTMLReportName, 4, 2);
		}
		return flag;
	}
	
	public static boolean mapOrganization(WebDriver driver, String organizationName, String organizationParent, String organizationDesc, String weekStartDay) throws Exception {
		boolean option = false;
		//verify whether Organization name is already exist or not		
		Utilities.selectLeftTreeFrame(driver);
		Boolean Temp1 = false;
		int rc1 = driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
		System.out.println("rc1:" + rc1);
		for (int i=1; i<=rc1; i++) {
			if (i <= 15) {
                String orgName=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[" + i + "]/td/a")).getText();
                Thread.sleep(1000);
                if (orgName.contains(organizationName)) {
                    driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[" + i + "]/td/a")).click();
                    Temp1 = true;
                    break;
                }
			}
		}
		if (Temp1 == true) {
			System.out.println("org already exist");
			extent.log(LogStatus.INFO, "Organization Name: " + organizationName + " already exists");
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Organization"));
			option = true;
		}
		//end of verify organization

		//create organization
		if (Temp1 == false) {
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver, organizationParent)) {
				return option = false;
			}
			Utilities.selectRightPaneView(driver);
			if (!OrganizationSettings.clickCreateOrganization(driver)) {
				return option = false;
			}
			OrganizationSettings.setOrganizationName(driver, organizationName);
			OrganizationSettings.setOrganizationDescription(driver, organizationDesc);
			if (weekStartDay != "") {
				if (!OrganizationSettings.setWeekStartDay(driver, weekStartDay)) {
					option = false;
				}
			}
			if (!OrganizationSettings.clickSave(driver)) {
				return option = false;
			}
			//validation
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver, organizationName)) {
				option = false;
			}
			else {
				option = true;
			}
		}
		return option;
	}
}
