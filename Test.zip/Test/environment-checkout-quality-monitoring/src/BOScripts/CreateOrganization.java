package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;

import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class CreateOrganization {
	
	public static ExtentReports extent = ExtentReports.get(CreateOrganization.class);

	public static boolean Create_Organization() throws Exception {
		boolean flag = true;
		String HTMLReportName = "CreateOrganization" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Create Organization");
		
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	    String organizationName = Ws.getCell(5, 1).getContents();
	    String organizationDesc = Ws.getCell(6, 1).getContents();
	    String organizationParent = Ws.getCell(7, 1).getContents();
		
		try {
			//launch Verint application
			LoginScreen.launchVerint(driver, Utilities.PROPERTIES.getProperty("VerintURL"));
			//verify verint login page is launched or not
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver, Utilities.getPassword(driver, 0, 1));
			LoginScreen.setTextInPassword(driver, Utilities.getPassword(driver, 1, 1));
			
			LoginScreen.clickLogin(driver); //click on Login button
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag=false;
			}
			//select Organization Settings menu item from Organization Management
			if (!VerintHomePageScreen.selectMenuItem(driver, "Organization Management", "Organization Settings")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.PROPERTIES.getProperty("UserName"));  //set user id in to User Name
				LoginScreen.setTextInPassword(driver,Utilities.PROPERTIES.getProperty("Password"));  //set password in to Password
				LoginScreen.clickLogin(driver); //click on Login button
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver, "Organization Management", "Organization Settings")) {
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again.");
					return flag = false;
				}							
			}			
			//verify Organization exist or not. If not, script will create Organization
			if (!OrganizationSettings.verifyOrganizationFromLeftTreeFrame(driver, organizationName)) {
				Utilities.selectLeftTreeFrame(driver); //select left hand side frame
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver, organizationParent)) { //select Parent Organization{
					return flag = false;
				}
				Utilities.selectRightPaneView(driver);
			    //click on Create Organization button
				if (!OrganizationSettings.clickCreateOrganization(driver)) {
					return flag = false;
				}
				OrganizationSettings.setOrganizationName(driver,organizationName); // enter Organization Name
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc); // enter Organization Description
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				//click on Save button
				if (!OrganizationSettings.clickSave(driver)) {
					return flag = false;
				}
				//validation - organization is created or not
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver, organizationName)) {
					return flag = false;
				}
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
		finally{
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "BO", HTMLReportName, 4, 1);
		}
		return flag;
	}
}
