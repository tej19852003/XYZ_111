package BOScripts;


import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;

import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkQueuesScreen;
import Utilities.Utilities;

public class Create_Map_Workqueue {
	
	public static ExtentReports extent = ExtentReports.get(Create_Map_Workqueue.class);
	public static Screen sobj = new Screen ();
	public static boolean CreateMapWorkqueue() throws Exception {
		boolean flag = true;
		boolean temp = false;
		String HTMLReportName = "Create_Map_Workqueue_" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Create Map Workqueue");
				
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	  
	    String organizatioName = Ws.getCell(5, 3).getContents();
	    String workqueueName = Ws.getCell(11, 3).getContents();
	    String workqueueDesc = Ws.getCell(12, 3).getContents();
	    String workqueueMedia = Ws.getCell(13, 3).getContents();
		
		try {
			LoginScreen.launchVerint(driver,Utilities.PROPERTIES.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver, "Organization Management", "Work Queues Settings")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver, "Organization Management", "Work Queues Settings")) {
					extent.log(LogStatus.WARNING, "Work Queues Settings menu is not selected. Please try again.");
					return flag = false;
				}
			}			
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver, organizatioName)) {
				return flag = false;
			}
			//checking whether exist or not
			Utilities.selectRightPaneView(driver);
			int valrcWq = driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("valrcPriv:" + valrcWq);
			for (int j=1; j<=valrcWq; j++) {
				if (j <= 15) {
					String WqnameApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr[" + j + "]/th/a/span")).getText().trim();
					Thread.sleep(1000);
					if (WqnameApp.contains(workqueueName)) {
						driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr[" + j + "]/th/a/span")).click();
						extent.log(LogStatus.INFO, "Work Queue Name:"+workqueueName+" already exist");
						extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Workqueue"));
						temp=true;
						break;
					}
				}
			}
			
			//end of checking
			Utilities.selectRightPaneView(driver);
			if (temp == false) {
				if (!WorkQueuesScreen.clickworkqueue(driver)) {
					return flag = false;
				}
				if (!WorkQueuesScreen.setWorkqueueName(driver, workqueueName)) {
					return flag = false;
				}
				WorkQueuesScreen.setWorkqueueDescription(driver, workqueueDesc);
				if (!WorkQueuesScreen.selectWorkqueueMedia(driver, workqueueMedia)) {
					return flag = false;
				}
				if (!WorkQueuesScreen.clickSave(driver)) {
					return flag = false;
				}
				if (driver.findElements(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[@id='pageMessages']/div[@Class='stdError']")).size() != 0) {
					String message=driver.findElement(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[@id='pageMessages']/div[@Class='stdError']")).getText();
					if (message.contains("Failed") && (message.contains("already exists"))) {
						extent.log(LogStatus.WARNING, "Workqueue" + workqueueName + " already exists");
						extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "Workqueue"));
					}
					else
					{
						extent.log(LogStatus.INFO, message + " is displayed");
						extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Workqueue"));
					}
				}
				//validation
				if (!WorkQueuesScreen.selectWorkqueue(driver, workqueueName)) {
					return flag=false;
				}	
			}
			
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "BO", HTMLReportName, 4, 3);
		}
		return flag;
	}
}
