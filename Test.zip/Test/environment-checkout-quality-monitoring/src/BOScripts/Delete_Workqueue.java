package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;

import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkQueuesScreen;
import Utilities.Utilities;

public class Delete_Workqueue {
	
	public static ExtentReports extent = ExtentReports.get(Delete_Workqueue.class);
	public static Screen sobj = new Screen ();
	public static boolean DeleteWorkqueue() throws Exception {
		boolean flag = true;
		boolean temp = false;
		String HTMLReportName="Delete_Workqueue_" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Delete Workqueue");
				
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	  
	    String organizatioName = Ws.getCell(5, 11).getContents();
	    String workqueueName = Ws.getCell(11, 11).getContents();
	    		
		try {
			LoginScreen.launchVerint(driver, Utilities.PROPERTIES.getProperty("VerintURL"));
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}
			LoginScreen.setTextInUsername(driver, Utilities.getPassword(driver, 0, 1));
			LoginScreen.setTextInPassword(driver, Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver, "Organization Management", "Work Queues Settings")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver, "Organization Management", "Work Queues Settings")) {
					extent.log(LogStatus.WARNING, "Settings section is not displayed. Please try again.");
					return flag = false;
				}
			}			
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver, organizatioName)) {
				return flag = false;
			}
			//checking whether exist or not
			Utilities.selectRightPaneView(driver);
			int valrcWq = driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("valrcPriv:" + valrcWq);
			for (int j=1; j<=valrcWq; j++) {
				if (j <= 15) {
					String workQueueNameApp = driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr[" + j + "]/th/a/span")).getText().trim();
					System.out.println("WqnameAppApp:" + workQueueNameApp);
					System.out.println("WqnameAppCreated:"+workqueueName);
					Thread.sleep(1000);
					if (workQueueNameApp.contains(workqueueName)) {
						driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr[" + j + "]/th/a/span")).click();
						extent.log(LogStatus.INFO, "Work Queue Name:" + workqueueName + " is selected");
						temp = true;
						break;
					}
				}
			}
						
			//end of checking
			Utilities.selectRightPaneView(driver);
			if (temp == true) {
				if (!WorkQueuesScreen.clickDeleteworkqueue(driver)) {
					return flag=false;
				}					
			}
			else {
				extent.log(LogStatus.FAIL, "Work Queue Name:" + workqueueName + " does not exist/not able to delete");
				return flag = false;
			}
		} catch(Exception e) {
			System.out.println(e);
		} finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "BO", HTMLReportName, 4, 11);
		}
		return flag;
	}
}
