package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.IntegrationServersScreen;
import ScreenObjects.LoginScreen;

import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

public class Adaptors_Settings {
	
	public static ExtentReports extent = ExtentReports.get(Adaptors_Settings.class);
	
	public static boolean AdaptorsSettings() throws Exception {
		boolean flag = true;
		String HTMLReportName = "Adaptors_Settings" + new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testCaseSetup(HTMLReportName, "Adaptors Settings");
				
		File file = new File(Utilities.PROPERTIES.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.PROPERTIES.getProperty("TestDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	  
	    String IntegrationServerName = Ws.getCell(23, 7).getContents();
	    String IntegrationPackageName = Ws.getCell(24, 7).getContents();
	    String SelectedComponent = Ws.getCell(25, 7).getContents();
		
		try {
			LoginScreen.launchVerint(driver,Utilities.PROPERTIES.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver)) {
				return flag = false;
			}

			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
				return flag = false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver, "System Management", "Integration Servers")) {
				Utilities.logout(driver);
				LoginScreen.setTextInUsername(driver, Utilities.PROPERTIES.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver, Utilities.PROPERTIES.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver)) {
					return flag = false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver, "System Management", "Integration Servers")) {
					extent.log(LogStatus.WARNING, "Not able to select Integration Servers. Please try again.");
					return flag = false;
				}
			}			
			if (!IntegrationServersScreen.selectIntegrationServerName(driver, IntegrationServerName)) {
				return flag = false;
			}
			if (!IntegrationServersScreen.clickEditConfiguration(driver)) {
				return flag = false;
			}
			if (!IntegrationServersScreen.selectIntegrationPackageName(driver, IntegrationPackageName)) {
				return flag = false;
			}
			driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Workflow")).size() != 0) {
				driver.findElement(By.linkText("Workflow")).click();
				extent.log(LogStatus.INFO, "Workflow tab is selected");
			}		
			else {
				extent.log(LogStatus.FAIL, "Not able to select Workflow tab");
				return flag = false;
			}			
			
			String[] comp=SelectedComponent.split(";");
			for (int c=0; c<comp.length; c++) {
				System.out.println("comp" + comp[c]);
				if (!IntegrationServersScreen.verifySelectedComponents(driver, comp[c])) {
					if (!IntegrationServersScreen.selectAvailableComponents(driver, comp[c])) {
						return flag = false;
					}
					if (!IntegrationServersScreen.clickAssignRight(driver)) {
						return flag = false;
					}
					if (!IntegrationServersScreen.selectSelectedComponents(driver, comp[c])) {
						return flag = false;
					}
				}
			}	
			if (!IntegrationServersScreen.clickSave(driver)) {
				return flag=false;
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		finally {
			Utilities.logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag, "BO", HTMLReportName, 4, 7);
		}
		return flag;
	}
}
