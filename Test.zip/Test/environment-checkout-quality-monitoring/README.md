Verint Automation
=================

| **Test Suite**       | Back Office                                                                                                                                                                                                                                                                       | Desktop Processing Analytics                                                                                                                                                                                                                                                                                        | Quality Monitoring                                                                                                                                                                                                                                                                              | Workforce Management                                                                                                                                                                                                                                                                                |
|----------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Shakedown            | [![Build Status](http://lt00nxam0090000.opr.statefarm.org/jenkins/buildStatus/icon?job=customer-care-center/verint/shakedown-back-office)](http://lt00nxam0090000.opr.statefarm.org/jenkins/job/customer-care-center/job/verint/job/shakedown-back-office/)                       | [![Build Status](http://lt00nxam0090000.opr.statefarm.org/jenkins/buildStatus/icon?job=customer-care-center/verint/shakedown-desktop-processing-analytics)](http://lt00nxam0090000.opr.statefarm.org/jenkins/job/customer-care-center/job/verint/job/shakedown-desktop-processing-analytics/)                       | [![Build Status](http://lt00nxam0090000.opr.statefarm.org/jenkins/buildStatus/icon?job=customer-care-center/verint/shakedown-quality-monitoring)](http://lt00nxam0090000.opr.statefarm.org/jenkins/job/customer-care-center/job/verint/job/shakedown-quality-monitoring/)                       | [![Build Status](http://lt00nxam0090000.opr.statefarm.org/jenkins/buildStatus/icon?job=customer-care-center/verint/shakedown-workforce-management)](http://lt00nxam0090000.opr.statefarm.org/jenkins/job/customer-care-center/job/verint/job/shakedown-workforce-management/)                       |
| Environment Checkout | [![Build Status](http://lt00nxam0090000.opr.statefarm.org/jenkins/buildStatus/icon?job=customer-care-center/verint/environment-checkout-back-office)](http://lt00nxam0090000.opr.statefarm.org/jenkins/job/customer-care-center/job/verint/job/environment-checkout-back-office/) | [![Build Status](http://lt00nxam0090000.opr.statefarm.org/jenkins/buildStatus/icon?job=customer-care-center/verint/environment-checkout-desktop-processing-analytics)](http://lt00nxam0090000.opr.statefarm.org/jenkins/job/customer-care-center/job/verint/job/environment-checkout-desktop-processing-analytics/) | [![Build Status](http://lt00nxam0090000.opr.statefarm.org/jenkins/buildStatus/icon?job=customer-care-center/verint/environment-checkout-quality-monitoring)](http://lt00nxam0090000.opr.statefarm.org/jenkins/job/customer-care-center/job/verint/job/environment-checkout-quality-monitoring/) | [![Build Status](http://lt00nxam0090000.opr.statefarm.org/jenkins/buildStatus/icon?job=customer-care-center/verint/environment-checkout-workforce-management)](http://lt00nxam0090000.opr.statefarm.org/jenkins/job/customer-care-center/job/verint/job/environment-checkout-workforce-management/) |
  
###### *Shakedown* = A sub-set of the environment checkout, run by test team as needed.  
###### *Environment Checkout* = Full test suite run by TAEs during... environment checkout.  
###### [Link to Jenkins Jobs](http://lt00nxam0090000.opr.statefarm.org/jenkins/job/customer-care-center/job/Verint/)

---

#### Sikuli installation

1.	Create `Software` folder in the C drive
2.	Copy `sikuli-install` folder to the C drive
3.	Double click on *runSetup*. Click on *Yes* until you get a *Success* message

-----

#### System variables set up for Sikuli
1.	**CLASSPATH** &rarr; `C:\Softwares\sikuli-install\sikuli-ide.jar;C:\Softwares\sikuli-install\sikuli-script.jar;`
2.	**PATH** &rarr; `C:\Softwares\sikuli-install\libs`. (Append to existing PATH variable, Do NOT just delete your path variable...)
3.	**SIKULI_HOME** &rarr; `C:\Softwares\sikuli-install\`

-----

#### System variables set up for Eclipse

**JAVA_HOME** &rarr; `C:\Program Files\Java\jre7`  
**Path** &rarr; `C:\Program Files\Java\jre7\bin; C:\Program Files\Java\jdk1.7.0_67\bin;`

-----

#### Steps to Execute Shakedown Scripts

1. Clone gitlab project to test worstations C drive.
2. Install Eclipse / Spring Tool Suite (STS),  Sikuli
4. Go to `C:\DEV\VerintAutomation\Verint_Shakedown_Automation\src\TestData` and then open TestIds sheet --> update Admin,QM Supervisor,Evaluator,Agent and WFM Agent test id’s
5. Go to `C:\DEV\VerintAutomation\Verint_Shakedown_Automation\src\TestData` and then open excel sheet (i.e. BO_TestData). Update ‘D’ column (column Name: “Run”) to Y (corresponding to Test case name)
6. Go to `C:\DEV\VerintAutomation\Verint_Shakedown_Automation\src\Properties` folder and then open `global-variables.properties` file (open with notepad) and update VerintURL and Issuance versions
7. Open Eclipse / STS and then select workspace as `C:\DEV\VerintAutomation`. Then click on OK button.
8. After opening Eclipse/STS, following snapshot will appear
9. Select and double click on (*Select one:* `BO_Driver`, `DPA_Driver`, `WFM_Driver`, `QM_Driver` module) 
10. click on Run icon (top left hand side of the page)
11.	After completion of execution, open excel file `C:\DEV\VerintAutomation\Verint_Shakedown_Automation\src\TestData\.xls` and click on a PASS/FAIL hyperlink to open a html report.

-----

#### Steps to Execute System Test Scripts

1. Clone gitlab project to test worstations C drive.
2. Install Eclipse/Spring Tool Suite, Sikuli.
4. Go to `C:\DEVSystem\Verint\Verint_System_Automation\src\TestData` and then open excel sheet (i.e. BO_TestData.xls). Update `D` column (column Name: “Run”) to Y (corresponding to Test case name)
5. Go to `C:\DEVSystem\Verint\Verint_System_Automation\src \Properties` folder and then open `global-variables.properties` file (open with notepad) and update VerintURL, Admin,DPA Testid, QM CCA, Evaluator,Supervisor,QM Analyst and WFM Forecaster
6. Open Eclipse/STS ( Starteclipse) and then select workspace as “C:\DEVSystem\Verint”. Then click on OK button.
7. Select and double click on (*Select one:* `BO_Driver`, `DPA_Driver`, `WFM_Driver`, `QM_Driver` module).
8. Click on  Run icon (top left hand side of the page)
9. After completion of execution, open excel file (C:\DEVSystem\Verint\Verint_System_Automation\src\TestData\.xls) and click on hyper link of PASS/FAIL then it will open html report.

---
